package studio.blackcat.client.hud;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.util.Mth;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.util.Gfx;
import studio.blackcat.client.util.Smooth;

/** In-game overlay: small glass pills + keystrokes. */
public final class HudRenderer {
    private HudRenderer() {}

    private static final int PILL_BG = 0x70101016;
    private static final int PILL_EDGE = 0x26FFFFFF;
    private static final Smooth[] KEY_ANIM = {
            new Smooth(0), new Smooth(0), new Smooth(0), new Smooth(0), new Smooth(0), new Smooth(0)
    };
    private static long lastNanos = System.nanoTime();

    // own FPS counter (frames drawn per second)
    private static int frames;
    private static long fpsWindowStart = System.nanoTime();
    private static int fps;

    public static void render(GuiGraphicsExtractor g, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        long now = System.nanoTime();
        float dt = Math.min((now - lastNanos) / 1_000_000_000f, 0.1f);
        lastNanos = now;

        frames++;
        if (now - fpsWindowStart >= 1_000_000_000L) {
            fps = frames;
            frames = 0;
            fpsWindowStart = now;
        }

        if (mc.player == null) return;
        Cps.poll(mc.options.keyAttack.isDown(), mc.options.keyUse.isDown());
        if (mc.gui.hud.isHidden()) return;
        Font font = mc.font;

        int x = 6;
        int y = 6;

        if (Modules.isEnabled(Module.FPS)) {
            y = pill(g, font, x, y, fps + " FPS");
        }
        if (Modules.isEnabled(Module.CPS)) {
            y = pill(g, font, x, y, Cps.left() + " | " + Cps.right() + " CPS");
        }
        if (Modules.isEnabled(Module.COORDS)) {
            y = pill(g, font, x, y, String.format("XYZ  %d  %d  %d",
                    Mth.floor(mc.player.getX()),
                    Mth.floor(mc.player.getY()),
                    Mth.floor(mc.player.getZ())));
        }
        if (Modules.isEnabled(Module.PING)) {
            String ping = "-- ms";
            if (mc.getConnection() != null) {
                PlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                if (info != null) ping = info.getLatency() + " ms";
            }
            y = pill(g, font, x, y, ping);
        }
        if (Modules.isEnabled(Module.KEYSTROKES)) {
            keystrokes(g, font, mc, x, y + 3, dt);
        }
    }

    private static int pill(GuiGraphicsExtractor g, Font font, int x, int y, String text) {
        int w = Gfx.width(font, text) + 12;
        Gfx.roundRect(g, x, y, w, 15, 5, PILL_BG);
        Gfx.roundOutline(g, x, y, w, 15, 5, PILL_EDGE);
        Gfx.text(g, font, text, x + 6, y + 4, 0xFFFFFFFF);
        return y + 19;
    }

    private static void keystrokes(GuiGraphicsExtractor g, Font font, Minecraft mc, int x, int y, float dt) {
        var o = mc.options;
        key(g, font, 0, o.keyUp, "W", x + 23, y, 20, dt);
        key(g, font, 1, o.keyLeft, "A", x, y + 23, 20, dt);
        key(g, font, 2, o.keyDown, "S", x + 23, y + 23, 20, dt);
        key(g, font, 3, o.keyRight, "D", x + 46, y + 23, 20, dt);
        key(g, font, 4, o.keyAttack, "LMB", x, y + 46, 31, dt);
        key(g, font, 5, o.keyUse, "RMB", x + 35, y + 46, 31, dt);
    }

    private static void key(GuiGraphicsExtractor g, Font font, int i, KeyMapping binding,
                            String label, int x, int y, int w, float dt) {
        float s = KEY_ANIM[i].update(binding.isDown() ? 1f : 0f, dt, 22f);
        int bg = Gfx.lerpColor(PILL_BG, 0xC8FFFFFF, s);
        int fg = Gfx.lerpColor(0xFFFFFFFF, 0xFF101016, s);
        Gfx.roundRect(g, x, y, w, 20, 5, bg);
        Gfx.roundOutline(g, x, y, w, 20, 5, PILL_EDGE);
        Gfx.text(g, font, label, x + (w - Gfx.width(font, label)) / 2, y + 6, fg);
    }
}
