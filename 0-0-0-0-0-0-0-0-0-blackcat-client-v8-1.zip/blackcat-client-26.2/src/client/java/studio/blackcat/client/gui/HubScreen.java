package studio.blackcat.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.Music;
import studio.blackcat.client.hud.Stats;
import studio.blackcat.client.hud.Style;
import studio.blackcat.client.util.Cat;
import studio.blackcat.client.util.Gfx;
import studio.blackcat.client.util.Smooth;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.DoubleConsumer;

/**
 * The Black Cat Hub: a sidebar shell with Home, Modules, Appearance, Music and Tools pages.
 * Everything is drawn with the current look (matte / monochrome / frosted / liquid glass / obsidian).
 */
public class HubScreen extends Screen {
    private enum Page {
        HOME("Home", "Overview"), MODULES("Modules", "Switch features on and off"),
        LOOK("Appearance", "Variants, colours and motion"), MUSIC("Music", "Synced lyrics"),
        TOOLS("Tools", "Editor, profiles and keys");
        final String title, sub;
        Page(String t, String s) { title = t; sub = s; }
    }

    private static final class Hit {
        final int x, y, w, h;
        final Runnable click;
        final DoubleConsumer drag;
        Hit(int x, int y, int w, int h, Runnable click, DoubleConsumer drag) {
            this.x = x; this.y = y; this.w = w; this.h = h; this.click = click; this.drag = drag;
        }
        boolean contains(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private static Page lastPage = Page.HOME;

    private Page page = lastPage;
    private float openT;
    private float pageT = 1f;
    private final Smooth pill = new Smooth(-1f);
    private final Smooth[] navHover = new Smooth[Page.values().length];
    private final Map<Module, Smooth> sw = new EnumMap<>(Module.class);
    private final Smooth[] lookHover = new Smooth[Style.LOOK_NAMES.length];
    private final List<Hit> hits = new ArrayList<>();
    private Hit slider;
    private long lastNanos = System.nanoTime();
    private float time;
    private int mx, my;
    private boolean closing;

    private int focus;             // 0 none, 1 module search, 2 song field
    private String search = "";
    private String songBuf = Modules.text("music_query");
    private Modules.Category cat;
    private boolean favOnly;
    private float scroll, scrollTarget, contentH, viewH;

    private int px, py, pw, ph;

    public HubScreen() {
        super(Component.literal("Black Cat"));
        for (int i = 0; i < navHover.length; i++) navHover[i] = new Smooth(0f);
        for (int i = 0; i < lookHover.length; i++) lookHover[i] = new Smooth(0f);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        closing = true;
    }

    // ---------- small helpers ----------

    private float anim() {
        return (float) Math.max(0.0, Math.min(3.0, Modules.textNum("anim", 1)));
    }

    private float alpha;

    private int c(int col) {
        return Gfx.mulAlpha(col, alpha);
    }

    private boolean over(int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void hit(int x, int y, int w, int h, Runnable r) {
        hits.add(new Hit(x, y, w, h, r, null));
    }

    private void hitDrag(int x, int y, int w, int h, DoubleConsumer d) {
        hits.add(new Hit(x, y, w, h, null, d));
    }

    private int cardFill() {
        return switch (Style.look()) {
            case Style.LOOK_LIQUID -> 0x26FFFFFF;
            case Style.LOOK_FROSTED -> 0x1CFFFFFF;
            case Style.LOOK_MONO -> 0xFF0A0A0A;
            case Style.LOOK_OBSIDIAN -> 0xFF08080B;
            default -> 0xFF141418;
        };
    }

    private int cardEdge() {
        return switch (Style.look()) {
            case Style.LOOK_LIQUID -> 0x55FFFFFF;
            case Style.LOOK_FROSTED -> 0x3CFFFFFF;
            case Style.LOOK_MONO -> 0xFF303034;
            case Style.LOOK_OBSIDIAN -> Gfx.mulAlpha(Style.accent(), 0.35f);
            default -> 0xFF26262C;
        };
    }

    private int radius() {
        return (int) Math.max(2, Math.min(10, Modules.textNum("radius", 4)));
    }

    private void card(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        int r = radius();
        Gfx.roundRect(g, x, y, w, h, r, c(cardFill()));
        Gfx.roundOutline(g, x, y, w, h, r, c(cardEdge()));
        if (Style.look() == Style.LOOK_LIQUID && w > 12) g.fill(x + r, y + 1, x + w - r, y + 2, c(0x40FFFFFF));
    }

    private int dim() {
        return Style.DIM;
    }

    private void text(GuiGraphicsExtractor g, String s, int x, int y, int col) {
        Gfx.text(g, this.font, s, x, y, c(col));
    }

    private int button(GuiGraphicsExtractor g, int x, int y, String label, boolean sel, Runnable r) {
        int w = Gfx.width(this.font, label) + 16;
        boolean hov = over(x, y, w, 16);
        int r2 = radius();
        Gfx.roundRect(g, x, y, w, 16, r2, c(sel ? 0xFF26262E : hov ? 0xFF1E1E24 : cardFill()));
        Gfx.roundOutline(g, x, y, w, 16, r2, c(sel ? Style.accent() : cardEdge()));
        text(g, label, x + 8, y + 4, sel ? Style.WHITE : 0xFFC8C8CE);
        hit(x, y, w, 16, r);
        return w;
    }

    private void slider(GuiGraphicsExtractor g, int x, int y, int w, float frac, DoubleConsumer onFrac) {
        Gfx.roundRect(g, x, y + 4, w, 4, 2, c(0xFF2A2A30));
        int fw = Math.round(w * Gfx.clamp01(frac));
        if (fw > 1) Gfx.roundRect(g, x, y + 4, fw, 4, 2, c(Style.accent()));
        Gfx.roundRect(g, x + fw - 4, y + 1, 8, 10, 3, c(0xFFF2F2F5));
        final int fx = x, fwid = w;
        hitDrag(x - 4, y - 2, w + 8, 16, mouse -> onFrac.accept(Gfx.clamp01((float) ((mouse - fx) / fwid))));
    }

    private void toggle(GuiGraphicsExtractor g, int x, int y, boolean on, float t) {
        int col = Gfx.lerpColor(0xFF2A2A30, Style.accent(), t);
        Gfx.roundRect(g, x, y, 22, 11, 5, c(col));
        int kx = x + 1 + Math.round(11 * t);
        Gfx.roundRect(g, kx, y + 1, 9, 9, 4, c(0xFFF2F2F5));
    }

    private void pageTo(Page p) {
        if (p == page) return;
        page = p;
        lastPage = p;
        pageT = 0f;
        scroll = scrollTarget = 0f;
        focus = 0;
    }

    private void go(Screen s) {
        if (this.minecraft != null) this.minecraft.gui.setScreen(s);
    }

    // ---------- frame ----------

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min((now - lastNanos) / 1_000_000_000f, 0.1f);
        lastNanos = now;
        float speed = anim();
        float step = speed <= 0f ? 1f : dt * 6f * speed;
        time += dt;
        mx = mouseX;
        my = mouseY;
        hits.clear();

        openT = closing ? Math.max(0f, openT - step * 1.4f) : Math.min(1f, openT + step);
        if (closing && openT <= 0f) {
            if (this.minecraft != null) this.minecraft.gui.setScreen(null);
            return;
        }
        pageT = Math.min(1f, pageT + step * 1.3f);
        float eo = Gfx.easeOutCubic(openT);
        float ep = Gfx.easeOutCubic(pageT);
        alpha = eo;

        pw = Math.min(540, this.width - 16);
        ph = Math.min(310, this.height - 16);
        px = (this.width - pw) / 2;
        py = (this.height - ph) / 2;

        g.fill(0, 0, this.width, this.height, Gfx.mulAlpha(0xFF000000, 0.42f * eo));

        float sc = 0.94f + 0.06f * eo;
        g.pose().pushMatrix();
        g.pose().translate(this.width / 2f, this.height / 2f);
        g.pose().scale(sc, sc);
        g.pose().translate(-this.width / 2f, -this.height / 2f);

        int r = radius() + 4;
        Gfx.roundRectV(g, px, py, pw, ph, r, c(Style.panelTop()), c(Style.panelBottom()));
        Gfx.roundOutline(g, px, py, pw, ph, r, c(Style.panelEdge()));
        if (Style.glass()) g.fill(px + r, py + 1, px + pw - r, py + 2, c(Style.look() == Style.LOOK_LIQUID ? 0x66FFFFFF : 0x38FFFFFF));

        drawSidebar(g);

        int cx = px + 120;
        int cw = pw - 128;
        int top = py + 12;
        // page title + subtitle
        alpha = eo * ep;
        text(g, page.title, cx, top, Style.WHITE);
        text(g, page.sub, cx, top + 12, dim());
        g.fill(cx, top + 25, cx + cw, top + 26, c(0xFF2A2A30));
        int bodyY = top + 32;
        int bodyH = py + ph - 10 - bodyY;
        int yOff = Math.round((1f - ep) * 6f);

        g.enableScissor(cx - 2, bodyY - 2, cx + cw + 2, bodyY + bodyH + 2);
        switch (page) {
            case HOME -> drawHome(g, cx, bodyY + yOff, cw, bodyH);
            case MODULES -> drawModules(g, cx, bodyY + yOff, cw, bodyH);
            case LOOK -> drawLook(g, cx, bodyY + yOff, cw, bodyH);
            case MUSIC -> drawMusic(g, cx, bodyY + yOff, cw, bodyH);
            case TOOLS -> drawTools(g, cx, bodyY + yOff, cw, bodyH);
        }
        g.disableScissor();
        g.pose().popMatrix();
    }

    private void drawSidebar(GuiGraphicsExtractor g) {
        int sx = px + 8;
        int sw = 104;
        // cat + wordmark
        float bob = (float) Math.sin(time * 1.6f) * 1.2f;
        Cat.draw(g, sx + 4, py + 12 + Math.round(bob), 34, Cat.blink(time));
        Gfx.spaced(g, this.font, "BLACK", sx + 44, py + 16, c(Style.WHITE), 1);
        Gfx.spaced(g, this.font, "CAT", sx + 44, py + 27, c(Style.accent()), 1);

        int y0 = py + 56;
        Page[] pages = Page.values();
        float target = y0 + page.ordinal() * 24;
        if (pill.value < 0) pill.value = target;
        pill.update(target, 0.016f * 1f, 20f * Math.max(0.2f, anim()));
        int pr = radius();
        Gfx.roundRect(g, sx, Math.round(pill.value), sw, 20, pr, c(cardFill() == 0xFF141418 ? 0xFF1F1F26 : 0x30FFFFFF));
        Gfx.roundOutline(g, sx, Math.round(pill.value), sw, 20, pr, c(cardEdge()));
        g.fill(sx + 3, Math.round(pill.value) + 5, sx + 5, Math.round(pill.value) + 15, c(Style.accent()));
        for (int i = 0; i < pages.length; i++) {
            int y = y0 + i * 24;
            Page p = pages[i];
            boolean hov = over(sx, y, sw, 20);
            float hv = navHover[i].update(hov || p == page ? 1f : 0f, 0.016f, 14f);
            text(g, p.title, sx + 14, y + 6, Gfx.lerpColor(0xFF8C8C95, 0xFFF2F2F5, hv));
            hit(sx, y, sw, 20, () -> pageTo(p));
        }
        // footer credit
        text(g, "Claude x Aaju", sx + 4, py + ph - 22, 0xFF6C6C75);
        text(g, "v" + "0.8", sx + 4, py + ph - 12, 0xFF4C4C55);
        g.fill(px + 116, py + 12, px + 117, py + ph - 12, c(0xFF22222A));
    }

    // ---------- Home ----------

    private void drawHome(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        long sec = (System.currentTimeMillis() - Stats.SESSION_START) / 1000;
        int active = 0;
        for (Module m : Module.values()) if (Modules.isEnabled(m)) active++;
        int cwid = (w - 16) / 3;
        String[][] stats = {
                {"Profile", Modules.profileName()},
                {"Modules on", active + " / " + Module.values().length},
                {"Session", (sec / 60) + "m " + String.format("%02d", sec % 60) + "s"},
        };
        for (int i = 0; i < 3; i++) {
            int cx = x + i * (cwid + 8);
            card(g, cx, y, cwid, 38);
            text(g, stats[i][0], cx + 8, y + 7, dim());
            text(g, Gfx.fit(this.font, stats[i][1], cwid - 16), cx + 8, y + 21, Style.WHITE);
        }
        // quick toggles
        text(g, "QUICK TOGGLES", x, y + 48, dim());
        Module[] quick = {Module.FPS, Module.CPS, Module.KEYSTROKES, Module.COORDS, Module.ARMOR, Module.POTIONS,
                Module.TARGET, Module.CROSSHAIR, Module.MUSIC, Module.CAT};
        int bx = x, by = y + 62;
        for (Module m : quick) {
            int bw = Gfx.width(this.font, m.title) + 16;
            if (bx + bw > x + w) {
                bx = x;
                by += 20;
            }
            final Module mm = m;
            button(g, bx, by, m.title, Modules.isEnabled(m), () -> Modules.toggle(mm));
            bx += bw + 5;
        }
        // now playing
        int ny = by + 28;
        card(g, x, ny, w, 40);
        if (Music.status() == Music.Status.IDLE) {
            text(g, "Nothing playing", x + 10, ny + 8, Style.WHITE);
            text(g, "Open Music to pick a song for synced lyrics", x + 10, ny + 22, dim());
        } else {
            String head = Music.artist().isEmpty() ? Music.title() : Music.title() + " - " + Music.artist();
            text(g, Gfx.fit(this.font, head, w - 20), x + 10, ny + 8, Style.WHITE);
            int idx = Music.indexAt(Music.positionMs());
            String line = idx >= 0 ? Music.lines().get(idx).text() : "";
            text(g, Gfx.fit(this.font, line.isEmpty() ? "..." : line, w - 20), x + 10, ny + 22, 0xFFC8C8CE);
        }
    }

    // ---------- Modules ----------

    private Smooth swFor(Module m) {
        return sw.computeIfAbsent(m, k -> new Smooth(Modules.isEnabled(k) ? 1f : 0f));
    }

    private void drawModules(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        // search + chips (fixed, above the scrolling list)
        int sw2 = 120;
        Gfx.roundRect(g, x, y, sw2, 15, radius(), c(focus == 1 ? 0xFF26262C : cardFill()));
        Gfx.roundOutline(g, x, y, sw2, 15, radius(), c(focus == 1 ? Style.accent() : cardEdge()));
        boolean caret = focus == 1 && (System.currentTimeMillis() / 500) % 2 == 0;
        String shown = search.isEmpty() && focus != 1 ? "Search..." : search + (caret ? "_" : "");
        text(g, Gfx.fit(this.font, shown, sw2 - 12), x + 6, y + 4, search.isEmpty() && focus != 1 ? dim() : Style.WHITE);
        hit(x, y, sw2, 15, () -> focus = 1);
        int cx = x + sw2 + 6;
        cx += button(g, cx, y - 1, "All", cat == null && !favOnly, () -> {
            cat = null;
            favOnly = false;
            scrollTarget = 0;
        }) + 4;
        cx += button(g, cx, y - 1, "Favs", favOnly, () -> {
            favOnly = !favOnly;
            scrollTarget = 0;
        }) + 4;
        for (Modules.Category k : Modules.Category.values()) {
            int bw = Gfx.width(this.font, k.title) + 16;
            if (cx + bw > x + w) break;
            final Modules.Category kk = k;
            cx += button(g, cx, y - 1, k.title, cat == k, () -> {
                cat = cat == kk ? null : kk;
                scrollTarget = 0;
            }) + 4;
        }

        int listY = y + 22;
        viewH = h - 22;
        List<Module> list = new ArrayList<>();
        String q = search.toLowerCase(Locale.ROOT).trim();
        for (int pass = 0; pass < 2; pass++) {
            for (Module m : Module.values()) {
                if (Modules.isFavModule(m) != (pass == 0)) continue;
                if (cat != null && m.category != cat) continue;
                if (favOnly && !Modules.isFavModule(m)) continue;
                if (!q.isEmpty() && !m.title.toLowerCase(Locale.ROOT).contains(q)
                        && !m.description.toLowerCase(Locale.ROOT).contains(q)) continue;
                list.add(m);
            }
        }
        int colW = (w - 6) / 2;
        int rowH = 34;
        int rows = (list.size() + 1) / 2;
        contentH = rows * (rowH + 4);
        scrollTarget = Math.max(0, Math.min(Math.max(0, contentH - viewH), scrollTarget));
        scroll += (scrollTarget - scroll) * (1f - (float) Math.exp(-0.016f * 16f * Math.max(0.2f, anim())));
        g.enableScissor(x - 2, listY, x + w + 2, listY + (int) viewH);
        if (list.isEmpty()) text(g, "No modules match.", x + 4, listY + 6, dim());
        for (int i = 0; i < list.size(); i++) {
            Module m = list.get(i);
            int cxx = x + (i % 2) * (colW + 6);
            int cy = listY + (i / 2) * (rowH + 4) - Math.round(scroll);
            if (cy + rowH < listY || cy > listY + viewH) continue;
            boolean visible = my >= listY && my < listY + viewH;
            boolean hov = visible && over(cxx, cy, colW, rowH);
            float t = swFor(m).update(Modules.isEnabled(m) ? 1f : 0f, 0.016f, 14f * Math.max(0.2f, anim()));
            Gfx.roundRect(g, cxx, cy, colW, rowH, radius(), c(hov ? 0xFF1C1C22 : cardFill()));
            Gfx.roundOutline(g, cxx, cy, colW, rowH, radius(), c(Gfx.lerpColor(cardEdge(), Style.accent(), t * 0.55f)));
            text(g, Gfx.fit(this.font, m.title, colW - 62), cxx + 8, cy + 6, Style.WHITE);
            text(g, Gfx.fit(this.font, m.description, colW - 20), cxx + 8, cy + 19, dim());
            toggle(g, cxx + colW - 30, cy + 6, Modules.isEnabled(m), t);
            boolean fav = Modules.isFavModule(m);
            int fx = cxx + colW - 44;
            text(g, fav ? "*" : "+", fx, cy + 6, fav ? 0xFFE8B84A : 0xFF55555E);
            if (visible) {
                hit(cxx, cy, colW, rowH, () -> Modules.toggle(m));
                hit(fx - 3, cy + 2, 12, 16, () -> Modules.toggleFavModule(m)); // added last, so it wins over the card
            }
        }
        g.disableScissor();
    }

    // ---------- Appearance ----------

    private void drawLook(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        viewH = h;
        scrollTarget = Math.max(0, Math.min(Math.max(0, contentH - viewH), scrollTarget));
        scroll += (scrollTarget - scroll) * (1f - (float) Math.exp(-0.016f * 16f * Math.max(0.2f, anim())));
        int oy = y - Math.round(scroll);
        int yy = oy;

        text(g, "VARIANT", x, yy, dim());
        yy += 12;
        int n = Style.LOOK_NAMES.length;
        int cw = (w - (n - 1) * 5) / n;
        for (int i = 0; i < n; i++) {
            int cx = x + i * (cw + 5);
            boolean sel = Modules.look() == i;
            boolean hov = over(cx, yy, cw, 44);
            float hv = lookHover[i].update(hov || sel ? 1f : 0f, 0.016f, 14f);
            drawVariantPreview(g, i, cx, yy, cw, 44, hv);
            Gfx.roundOutline(g, cx, yy, cw, 44, radius(), c(sel ? Style.accent() : cardEdge()));
            String nm = Style.LOOK_NAMES[i];
            text(g, Gfx.fit(this.font, nm, cw - 6), cx + (cw - Gfx.width(this.font, Gfx.fit(this.font, nm, cw - 6))) / 2, yy + 48,
                    sel ? Style.WHITE : 0xFF8C8C95);
            final int li = i;
            hit(cx, yy, cw, 60, () -> Modules.setLook(li));
        }
        yy += 66;

        text(g, "PRESETS", x, yy, dim());
        yy += 12;
        int bx = x;
        for (int i = 0; i < Modules.PRESET_NAMES.length; i++) {
            final int pi = i;
            bx += button(g, bx, yy, Modules.PRESET_NAMES[i], false, () -> Modules.applyPreset(pi)) + 5;
        }
        yy += 26;

        text(g, "ACCENT", x, yy, dim());
        yy += 12;
        for (int i = 0; i < Modules.ACCENT_COLORS.length; i++) {
            final int ai = i;
            int sx = x + i * 20;
            Gfx.roundRect(g, sx, yy, 16, 16, 4, c(Modules.ACCENT_COLORS[i]));
            if (Modules.accent() == Modules.ACCENT_COLORS[i]) Gfx.roundOutline(g, sx - 2, yy - 2, 20, 20, 5, c(Style.WHITE));
            hit(sx, yy, 16, 16, () -> Modules.setAccent(ai));
        }
        int gx = x + Modules.ACCENT_COLORS.length * 20 + 10;
        button(g, gx, yy, Modules.gradient() ? "Gradient: on" : "Gradient: off", Modules.gradient(), Modules::toggleGradient);
        yy += 26;

        // RGB
        int col = Modules.accent();
        int[] rgb = {(col >> 16) & 255, (col >> 8) & 255, col & 255};
        String[] rn = {"R", "G", "B"};
        for (int k = 0; k < 3; k++) {
            final int kk = k;
            text(g, rn[k], x, yy + 2, dim());
            slider(g, x + 14, yy, Math.min(150, w - 60), rgb[k] / 255f, f -> {
                int[] cur = {(Modules.accent() >> 16) & 255, (Modules.accent() >> 8) & 255, Modules.accent() & 255};
                cur[kk] = Math.round((float) f * 255f);
                Modules.setCustomAccent(cur[0], cur[1], cur[2]);
            });
            text(g, String.valueOf(rgb[k]), x + 14 + Math.min(150, w - 60) + 10, yy + 2, 0xFFC8C8CE);
            yy += 16;
        }
        yy += 8;

        text(g, "SHAPE AND MOTION", x, yy, dim());
        yy += 14;
        int sw0 = Math.min(150, w - 150);
        text(g, "Opacity", x, yy + 2, 0xFFC8C8CE);
        slider(g, x + 100, yy, sw0, (Modules.opacity() - 0.2f) / 0.8f, f -> Modules.setOpacity(0.2f + (float) f * 0.8f));
        text(g, Math.round(Modules.opacity() * 100) + "%", x + 110 + sw0, yy + 2, dim());
        yy += 18;
        float rad = (float) Modules.textNum("radius", 4);
        text(g, "Corner radius", x, yy + 2, 0xFFC8C8CE);
        slider(g, x + 100, yy, sw0, (rad - 2f) / 8f, f -> Modules.setText("radius", String.valueOf(Math.round(2 + f * 8))));
        text(g, Math.round(rad) + " px", x + 110 + sw0, yy + 2, dim());
        yy += 18;
        float an = (float) Modules.textNum("anim", 1);
        text(g, "Animation speed", x, yy + 2, 0xFFC8C8CE);
        slider(g, x + 100, yy, sw0, an / 3f, f -> Modules.setText("anim", String.format(Locale.ROOT, "%.1f", f * 3f)));
        text(g, an <= 0f ? "off" : String.format(Locale.ROOT, "%.1fx", an), x + 110 + sw0, yy + 2, dim());
        yy += 22;

        text(g, "CAT", x, yy, dim());
        yy += 12;
        int cx2 = x;
        for (String st : new String[]{"auto", "awake", "sleepy"}) {
            final String s2 = st;
            cx2 += button(g, cx2, yy, st, Modules.text("cat_style").equals(st), () -> Modules.setText("cat_style", s2)) + 5;
        }
        button(g, cx2 + 6, yy, Modules.nameBadge() ? "Name badge: on" : "Name badge: off", Modules.nameBadge(), Modules::toggleNameBadge);
        yy += 24;
        contentH = yy - oy + 4;
    }

    /** A little sample panel drawn in a given look, whatever the current one is. */
    private void drawVariantPreview(GuiGraphicsExtractor g, int look, int x, int y, int w, int h, float hv) {
        int top, bot, edge;
        switch (look) {
            case Style.LOOK_MONO -> { top = bot = 0xFF000000; edge = 0xFF4A4A4F; }
            case Style.LOOK_FROSTED -> { top = 0xB84C5C78; bot = 0xCC1C2332; edge = 0x66FFFFFF; }
            case Style.LOOK_LIQUID -> { top = 0x8C6E8CB4; bot = 0xA0101828; edge = 0x99FFFFFF; }
            case Style.LOOK_OBSIDIAN -> { top = bot = 0xFA030305; edge = Gfx.mulAlpha(Style.accent(), 0.7f); }
            default -> { top = bot = 0xFF0B0B0D; edge = 0xFF26262C; }
        }
        // a checker-ish backdrop so the see-through looks read as glass
        Gfx.roundRect(g, x, y, w, h, radius(), c(0xFF2A3A55));
        g.fill(x + w / 2, y + 2, x + w - 2, y + h - 2, c(0xFF55406A));
        Gfx.roundRectV(g, x, y, w, h, radius(), c(top), c(bot));
        Gfx.roundOutline(g, x, y, w, h, radius(), c(edge));
        if (look == Style.LOOK_FROSTED || look == Style.LOOK_LIQUID) g.fill(x + 4, y + 1, x + w - 4, y + 2, c(look == Style.LOOK_LIQUID ? 0x66FFFFFF : 0x38FFFFFF));
        int acc = look == Style.LOOK_MONO ? 0xFFF2F2F5 : Style.accent();
        g.fill(x + 6, y + 10, x + w / 2, y + 12, c(acc));
        g.fill(x + 6, y + 18, x + w - 10, y + 19, c(0x66FFFFFF));
        g.fill(x + 6, y + 24, x + w - 18, y + 25, c(0x44FFFFFF));
    }

    // ---------- Music ----------

    private void drawMusic(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        text(g, "SONG (Artist - Title)", x, y, dim());
        int fw = w - 70;
        Gfx.roundRect(g, x, y + 12, fw, 16, radius(), c(focus == 2 ? 0xFF26262C : cardFill()));
        Gfx.roundOutline(g, x, y + 12, fw, 16, radius(), c(focus == 2 ? Style.accent() : cardEdge()));
        boolean caret = focus == 2 && (System.currentTimeMillis() / 500) % 2 == 0;
        String shown = songBuf.isEmpty() && focus != 2 ? "M83 - Midnight City" : songBuf + (caret ? "_" : "");
        text(g, Gfx.fit(this.font, shown, fw - 12), x + 6, y + 16, songBuf.isEmpty() && focus != 2 ? dim() : Style.WHITE);
        hit(x, y + 12, fw, 16, () -> focus = 2);
        button(g, x + fw + 6, y + 12, "Start", false, this::startSong);

        int yy = y + 38;
        card(g, x, yy, w, 64);
        Music.Status st = Music.status();
        String line1 = st == Music.Status.IDLE ? "No song selected" : Music.title();
        String line2 = switch (st) {
            case IDLE -> "Type a song above and press Start";
            case LOADING -> "Finding lyrics...";
            case NOT_FOUND -> "No lyrics found for that song";
            case ERROR -> "Lookup failed (offline?)";
            case PLAIN -> "Lyrics found, but they are not timed";
            case SYNCED -> (Music.artist().isEmpty() ? "" : Music.artist() + "  |  ") + (Music.isPlaying() ? "playing" : "paused");
        };
        text(g, Gfx.fit(this.font, line1, w - 20), x + 10, yy + 8, Style.WHITE);
        text(g, Gfx.fit(this.font, line2, w - 20), x + 10, yy + 22, dim());
        long pos = Music.positionMs();
        long dur = Music.durationMs();
        int bx = x + 10, bw = w - 20, by = yy + 42;
        g.fill(bx, by, bx + bw, by + 3, c(0xFF2A2A30));
        if (dur > 0) {
            int f = Math.round(bw * Math.min(1f, pos / (float) dur));
            if (f > 0) g.fill(bx, by, bx + f, by + 3, c(Style.accent()));
        }
        text(g, (pos / 60000) + ":" + String.format("%02d", pos / 1000 % 60)
                + (dur > 0 ? " / " + (dur / 60000) + ":" + String.format("%02d", dur / 1000 % 60) : ""), bx, by + 7, dim());

        yy += 74;
        int bx2 = x;
        bx2 += button(g, bx2, yy, Music.isPlaying() ? "Pause" : "Play", false, Music::toggle) + 5;
        bx2 += button(g, bx2, yy, "Restart", false, Music::restart) + 5;
        bx2 += button(g, bx2, yy, "-5s", false, () -> Music.seek(-5000)) + 5;
        bx2 += button(g, bx2, yy, "+5s", false, () -> Music.seek(5000)) + 5;
        yy += 22;
        text(g, "Lyric timing", x, yy + 4, 0xFFC8C8CE);
        int tx = x + 78;
        tx += button(g, tx, yy, "Sooner", false, () -> Music.nudge(500)) + 5;
        tx += button(g, tx, yy, "Later", false, () -> Music.nudge(-500)) + 5;
        text(g, String.format(Locale.ROOT, "%+.1fs", Music.offsetMs() / 1000f), tx + 4, yy + 4, dim());
        yy += 26;
        button(g, x, yy, Modules.isEnabled(Module.MUSIC) ? "HUD widget: on" : "HUD widget: off", Modules.isEnabled(Module.MUSIC),
                () -> Modules.toggle(Module.MUSIC));
        text(g, "Start the song in your music app at the same moment.", x, yy + 24, dim());
    }

    private void startSong() {
        Modules.setText("music_query", songBuf);
        Music.setTrack(songBuf);
        if (!songBuf.isBlank() && !Modules.isEnabled(Module.MUSIC)) Modules.toggle(Module.MUSIC);
        focus = 0;
    }

    // ---------- Tools ----------

    private void drawTools(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        String[][] items = {
                {"Edit HUD layout", "Drag, resize, group and undo"},
                {"Command Palette", "Search and run anything"},
                {"Profiles and backups", "Save, import, export, auto-switch"},
                {"Keybinds", "Rebind the client keys"},
                {"Text settings", "Auto GG, filter, quick commands, crosshair"},
                {"Reset all HUD positions", "Puts every widget back"},
        };
        int colW = (w - 6) / 2;
        for (int i = 0; i < items.length; i++) {
            int cx = x + (i % 2) * (colW + 6);
            int cy = y + (i / 2) * 44;
            boolean hov = over(cx, cy, colW, 38);
            Gfx.roundRect(g, cx, cy, colW, 38, radius(), c(hov ? 0xFF1C1C22 : cardFill()));
            Gfx.roundOutline(g, cx, cy, colW, 38, radius(), c(hov ? Style.accent() : cardEdge()));
            text(g, items[i][0], cx + 10, cy + 8, Style.WHITE);
            text(g, Gfx.fit(this.font, items[i][1], colW - 20), cx + 10, cy + 22, dim());
            final int idx = i;
            hit(cx, cy, colW, 38, () -> {
                switch (idx) {
                    case 0 -> go(new HudEditorScreen());
                    case 1 -> go(new PaletteScreen());
                    case 2 -> go(new GlassMenuScreen(2));
                    case 3 -> go(new GlassMenuScreen(3));
                    case 4 -> go(new TextSettingsScreen());
                    default -> Modules.resetAllPos();
                }
            });
        }
        text(g, "Classic menu", x, y + 140, dim());
        button(g, x, y + 152, "Open the classic menu", false, () -> go(new GlassMenuScreen()));
    }

    // ---------- input ----------

    private Hit hitAt(double x, double y) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            if (hits.get(i).contains(x, y)) return hits.get(i);
        }
        return null;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (closing) return false;
        slider = null;
        Hit h = hitAt(mx, my);
        if (h == null) {
            focus = 0;
            if (mx < px || mx > px + pw || my < py || my > py + ph) closing = true;
            return true;
        }
        if (h.drag != null) {
            slider = h;
            h.drag.accept(mx);
            return true;
        }
        int before = focus;
        focus = 0;
        if (h.click != null) h.click.run();
        if (focus == 0 && before != 0) focus = 0;
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (slider != null && slider.drag != null) {
            slider.drag.accept(mx);
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        slider = null;
        return true;
    }

    @Override
    public boolean mouseScrolled(double x, double y, double sx, double sy) {
        scrollTarget -= (float) sy * 28f;
        scrollTarget = Math.max(0f, Math.min(Math.max(0f, contentH - viewH), scrollTarget));
        return true;
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (focus == 1 && search.length() < 24) {
            search += event.codepointAsString();
            scrollTarget = 0;
            return true;
        }
        if (focus == 2 && songBuf.length() < 80) {
            songBuf += event.codepointAsString();
            return true;
        }
        return super.charTyped(event);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int code = InputConstants.getKey(event).getValue();
        if (focus != 0) {
            if (event.isEscape()) {
                focus = 0;
                return true;
            }
            if (code == GLFW.GLFW_KEY_BACKSPACE) {
                if (focus == 1 && !search.isEmpty()) search = search.substring(0, search.length() - 1);
                if (focus == 2 && !songBuf.isEmpty()) songBuf = songBuf.substring(0, songBuf.length() - 1);
                return true;
            }
            if (code == GLFW.GLFW_KEY_ENTER || code == GLFW.GLFW_KEY_KP_ENTER) {
                if (focus == 2) startSong();
                focus = 0;
                return true;
            }
            return true; // swallow other keys while typing
        }
        return super.keyPressed(event);
    }
}
