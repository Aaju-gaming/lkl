package studio.blackcat.client.hud;
/** Test stand-in. */
public final class Notify { public static void push(String s) {} }
