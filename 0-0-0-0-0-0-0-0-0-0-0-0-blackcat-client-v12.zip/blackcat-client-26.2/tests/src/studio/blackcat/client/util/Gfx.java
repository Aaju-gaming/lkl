package studio.blackcat.client.util;
public final class Gfx {
    public static int argb(int a, int r, int g, int b) { return (a << 24) | (r << 16) | (g << 8) | b; }
    public static int mulAlpha(int c, float m) { int a = Math.round(((c >>> 24) & 255) * m); return (Math.max(0, Math.min(255, a)) << 24) | (c & 0xFFFFFF); }
    public static int lerpColor(int a, int b, float t) {
        int r = 0;
        for (int s = 24; s >= 0; s -= 8) {
            int x = (a >>> s) & 255, y = (b >>> s) & 255;
            r |= (Math.round(x + (y - x) * t) & 255) << s;
        }
        return r;
    }
}
