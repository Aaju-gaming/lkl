package studio.blackcat.client;

import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.hud.Style;

import java.nio.file.*;
import java.util.*;

public class H {
    static int fails = 0;
    static void check(String name, boolean ok) { System.out.println((ok ? "PASS " : "FAIL ") + name); if (!ok) fails++; }
    static Path cfg() { return Path.of(System.getProperty("bc.cfg")); }
    static void write(Path p, String s) throws Exception { Files.createDirectories(p.getParent()); Files.writeString(p, s); }

    public static void main(String[] a) throws Exception {
        switch (a[0]) {
            case "import" -> imports();
            case "backup" -> backup();
            case "auto" -> auto();
            case "opacity" -> opacity();
            case "favs1" -> { Modules.load(); Modules.toggleFavModule(Module.KEYSTROKES); Modules.toggleFavModule(Module.PING);
                Modules.saveProfile("Alpha"); Modules.saveProfile("Beta"); Modules.toggleFavProfile("Beta"); Modules.saveTheme(); }
            case "favs2" -> { Modules.load();
                check("fav module survives restart", Modules.isFavModule(Module.KEYSTROKES) && Modules.isFavModule(Module.PING) && !Modules.isFavModule(Module.FPS));
                check("fav profile survives restart", Modules.isFavProfile("Beta") && !Modules.isFavProfile("Alpha"));
                check("favourite profile sorts first", Modules.profileNames().get(0).equals("Beta"));
                check("saved theme survives restart", Modules.themes().size() == 1);
                check("active profile name survives restart", Modules.profileName().equals("Beta"));
                Modules.deleteProfile("Beta");
                check("deleting a profile drops its favourite", !Modules.isFavProfile("Beta")); }
            case "favs3" -> { Modules.load(); check("deleted favourite stays gone after restart", !Modules.isFavProfile("Beta")); }
            case "corrupt" -> corrupt();
            case "badmain" -> {
                write(cfg().resolve("blackcat.json"), "{\"enabled\":\"oops\",\"opts\":5,\"themes\":[1,2],\"favModules\":7,\"favProfiles\":{\"a\":1}}");
                check("damaged main config does not throw", safe(Modules::load));
                check("falls back to defaults", Modules.isEnabled(Module.FPS));
                write(cfg().resolve("blackcat.json"), "\u0000\u0001 not json at all");
                check("binary garbage does not throw", safe(Modules::load));
                write(cfg().resolve("blackcat.json"), "");
                check("empty main config does not throw", safe(Modules::load));
                write(cfg().resolve("blackcat.json"), "{\"enabled\":[\"FPS\"],\"pos\":{\"FPS\":[NaN,2]},\"opacity\":\"high\"}");
                check("bad number types do not throw", safe(Modules::load));
                check("game can still save afterwards", safe(Modules::save));
            }
            default -> throw new IllegalArgumentException(a[0]);
        }
        System.out.println(fails == 0 ? "ALL PASS" : fails + " FAILED");
        if (fails > 0) System.exit(1);
    }

    static void imports() throws Exception {
        Path in = cfg().resolve("blackcat/import");
        write(in.resolve("good.json"), "{\"cfg\":4,\"enabled\":[\"FPS\"],\"accent\":2}");
        write(in.resolve("good2.json"), "{\"enabled\":[\"CPS\"]}");
        write(in.resolve("broken.json"), "{ not json");
        write(in.resolve("empty.json"), "");
        write(in.resolve("array.json"), "[1,2,3]");
        write(in.resolve("future.json"), "{\"cfg\":99,\"enabled\":[]}");
        write(in.resolve("huge.json"), "{\"enabled\":[\"" + "A".repeat(200_000) + "\"]}");
        write(in.resolve("notes.txt"), "ignored");
        write(in.resolve("../evil.json"), "{\"enabled\":[\"FPS\"]}");
        String r = Modules.importProfiles();
        System.out.println("report: " + r);
        List<String> names = Modules.profileNames();
        check("only the 2 good files imported", names.size() == 2 && names.contains("good") && names.contains("good2"));
        check("report mentions skipped", r.contains("skipped 5"));
        check("nothing escaped the import folder", !names.contains("evil") && !Files.exists(cfg().resolve("blackcat/profiles/evil.json")));
        // importing the same file again must not overwrite: gets (2)
        String r2 = Modules.importProfiles();
        check("duplicate names get a suffix", Modules.profileNames().contains("good (2)") && Modules.profileNames().contains("good2 (2)"));
        check("existing profile untouched", Modules.profileNames().contains("good"));
        // empty folder message
        for (var p : Files.list(in).toList()) if (Files.isRegularFile(p)) Files.delete(p);
        check("empty folder message", Modules.importProfiles().startsWith("Nothing found"));
    }

    static void corrupt() throws Exception {
        Modules.saveProfile("Good");
        write(cfg().resolve("blackcat/profiles/Bad.json"), "{\"enabled\":\"oops\",\"accent\":\"x\"}");
        write(cfg().resolve("blackcat/profiles/Worse.json"), "garbage");
        check("one broken profile does not hide the others", Modules.profileNames().contains("Good"));
        check("loading a corrupt profile fails safely", !Modules.loadProfile("Worse"));
        check("a half-broken profile does not crash loading", safe(() -> Modules.loadProfile("Bad")));
    }
    static boolean safe(Runnable r) { try { r.run(); return true; } catch (Throwable t) { System.out.println(t); return false; } }

    static void backup() throws Exception {
        Modules.load();
        // baseline state
        if (!Modules.isEnabled(Module.CLOCK)) Modules.toggle(Module.CLOCK);
        Modules.setPos(Module.CLOCK, 0.25f, 0.5f);
        Modules.setOpacity(0.6f);
        Modules.setLook(2);
        Modules.toggleFavModule(Module.ARMOR);
        Modules.saveTheme();
        Modules.saveProfile("One");
        Modules.saveProfile("Two");
        int n = Modules.backup();
        check("backup wrote files", n == 3); // main + 2 profiles
        int n2 = Modules.backup();
        check("second backup in the same second works", n2 == 3);
        // change several things
        Modules.toggle(Module.CLOCK);
        Modules.setPos(Module.CLOCK, 0.9f, 0.9f);
        Modules.setOpacity(0.95f);
        Modules.setLook(1);
        Modules.toggleFavModule(Module.ARMOR);
        Modules.deleteTheme(Modules.themes().get(0));
        Modules.deleteProfile("One");
        Modules.saveProfile("Two"); // overwrite Two with the changed state
        check("changes applied", !Modules.isEnabled(Module.CLOCK) && Modules.look() == 1 && Modules.themes().isEmpty()
                && !Modules.profileNames().contains("One"));
        String r = Modules.restoreLatest();
        System.out.println("report: " + r);
        check("module switch restored", Modules.isEnabled(Module.CLOCK));
        check("position restored", Modules.pos(Module.CLOCK) != null && Modules.pos(Module.CLOCK)[0] == 0.25f && Modules.pos(Module.CLOCK)[1] == 0.5f);
        check("opacity restored", Math.abs(Modules.opacity() - 0.6f) < 1e-6);
        check("look restored", Modules.look() == 2);
        check("favourite restored", Modules.isFavModule(Module.ARMOR));
        check("saved theme restored", Modules.themes().size() == 1);
        check("deleted profile restored", Modules.profileNames().contains("One"));
        // overwritten profile has the baseline back
        check("overwritten profile restored", Modules.loadProfile("Two") && Modules.look() == 2 && Modules.isEnabled(Module.CLOCK));
        // survives a restart
        write(cfg().resolve("marker"), "x");
    }

    static void auto() throws Exception {
        Modules.load();
        Modules.saveProfile("Hyp");
        Modules.saveProfile("Sub");
        Modules.saveProfile("Other");
        Modules.setProfileServer("Hyp", "hypixel.net");
        Modules.setProfileServer("Sub", "mc.hypixel.net:25565"); // more specific, with a port
        check("host normalised", Modules.normalizeHost("Play.Example.COM:25565.").equals("play.example.com"));
        check("ipv4 port stripped", Modules.normalizeHost("1.2.3.4:25565").equals("1.2.3.4"));
        check("ipv6 kept", Modules.normalizeHost("[::1]:25565").equals("::1"));
        check("bare ipv6 kept", Modules.normalizeHost("::1").equals("::1"));
        check("exact match", "Hyp".equals(Modules.profileForServer("hypixel.net")));
        check("port ignored", "Hyp".equals(Modules.profileForServer("HYPIXEL.NET:25565")));
        check("most specific wins", "Sub".equals(Modules.profileForServer("mc.hypixel.net")));
        check("unrelated subdomain falls back to parent", "Hyp".equals(Modules.profileForServer("eu.hypixel.net")));
        check("lookalike domain does not match", Modules.profileForServer("nothypixel.net") == null);
        check("suffix trick does not match", Modules.profileForServer("hypixel.net.evil.com") == null);
        check("unknown server -> none", Modules.profileForServer("example.org") == null);
        check("empty/null address -> none", Modules.profileForServer("") == null && Modules.profileForServer(null) == null);
        // same server bound to a second profile: the binding moves
        Modules.setProfileServer("Other", "hypixel.net");
        check("binding moved to the newest profile", "Other".equals(Modules.profileForServer("hypixel.net")));
        check("old profile lost the binding", Modules.profileServer("Hyp").isEmpty());
        // identical profile names (case) differ only in case -> unique
        check("same name different case gets suffix", ProfileCodec.uniqueName("other", Modules.profileNames()).equals("other (2)"));
        // duplicate must not inherit the binding
        String copy = Modules.duplicateProfile("Other");
        check("duplicate has no server binding", Modules.profileServer(copy).isEmpty());
        check("duplicate does not steal the server", "Other".equals(Modules.profileForServer("hypixel.net")));
        // autoSwitch loads it only when different
        Modules.loadProfile("Sub");
        Modules.autoSwitch("hypixel.net");
        check("autoSwitch switches profile", Modules.profileName().equals("Other"));
        Modules.autoSwitch("example.org");
        check("autoSwitch leaves profile alone when nothing matches", Modules.profileName().equals("Other"));
        // export must not leak the binding
        Modules.exportProfile("Other");
        check("export strips server", !Files.readString(cfg().resolve("blackcat/export/Other.json")).contains("server"));
    }

    static void opacity() {
        Modules.load();
        float[] ops = {0.3f, 0.5f, 0.85f, 1.0f};
        for (int look = 0; look < 3; look++) {
            Modules.setLook(look);
            for (float o : ops) {
                Modules.setOpacity(o);
                int expect = Math.round(255f * o);
                boolean allOk = true;
                for (Module m : Module.values()) {
                    Style.begin(m);
                    int a = Style.bg() >>> 24;
                    int top = Style.bgTop() >>> 24;
                    Style.end();
                    if (a != expect) allOk = false;
                    if (top > a) allOk = false; // never more solid at the top than the bottom
                }
                check("look " + look + " opacity " + o + " -> every widget alpha " + expect, allOk);
            }
        }
        // per-widget override beats global, others unaffected
        Modules.setLook(0);
        Modules.setOpacity(0.9f);
        Modules.opts(Module.PING).opacity = 0.4f;
        Style.begin(Module.PING);  int ping = Style.bg() >>> 24; Style.end();
        Style.begin(Module.FPS);   int fps = Style.bg() >>> 24;  Style.end();
        check("per-widget opacity applies only to that widget", ping == Math.round(255 * 0.4f) && fps == Math.round(255 * 0.9f));
        Modules.opts(Module.PING).bg = false;
        Style.begin(Module.PING);  boolean gone = Style.bg() == 0 && Style.edge() == 0 && Style.bgTop() == 0; Style.end();
        check("background off removes fill and edge", gone);
        Style.begin(Module.PING); Style.end();
        check("no leftover style after end()", Style.bg() >>> 24 == Math.round(255 * 0.9f));
        Modules.setOpacity(0.01f);
        check("global opacity floor", Modules.opacity() == Modules.MIN_OPACITY);
        Modules.setOpacity(5f);
        check("global opacity ceiling", Modules.opacity() == 1f);
        // mono always white accent
        Modules.setLook(1);
        Modules.setAccent(3);
        check("monochrome ignores accent", Style.accent() == 0xFFF2F2F5);
        Modules.setLook(0);
        check("matte uses accent", Style.accent() == Modules.ACCENT_COLORS[3]);
    }
}
