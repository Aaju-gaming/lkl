Logic tests for profiles, backups, server auto-switch, opacity and favourites (no Minecraft needed).
Needs a JDK and the gson jar. From this folder:
  javac -cp gson.jar -d out $(find src -name "*.java") ../src/client/java/studio/blackcat/client/{Modules,ProfileCodec}.java ../src/client/java/studio/blackcat/client/hud/Style.java
  java -Dbc.cfg=/some/empty/dir -cp out:gson.jar studio.blackcat.client.H <import|backup|auto|opacity|corrupt|badmain|favs1 then favs2>
(src/ holds tiny stand-ins for FabricLoader and Gfx; the game itself is not involved.)
