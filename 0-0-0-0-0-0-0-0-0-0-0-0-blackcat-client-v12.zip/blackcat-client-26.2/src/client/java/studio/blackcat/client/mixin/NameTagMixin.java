package studio.blackcat.client.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;

/**
 * Shows your own name tag above your head in third person (F5), like other players'.
 * Non-fatal (require = 0): if Mojang renames the method, only this feature stops working.
 */
@Mixin(targets = "net.minecraft.client.renderer.entity.LivingEntityRenderer")
public abstract class NameTagMixin {
    @Inject(method = "shouldShowName", at = @At("HEAD"), cancellable = true, require = 0)
    private void blackcat$ownName(LivingEntity entity, double distanceSq, CallbackInfoReturnable<Boolean> cir) {
        Minecraft mc = Minecraft.getInstance();
        if (entity == mc.player && Modules.isEnabled(Module.NAME) && !mc.options.getCameraType().isFirstPerson()) {
            cir.setReturnValue(true);
        }
    }
}
