package studio.blackcat.client.hud;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.gui.LogoBadge;
import studio.blackcat.client.util.Cat;
import studio.blackcat.client.util.Gfx;
import studio.blackcat.client.util.Smooth;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

/** Every HUD element. Flat matte black panels, thin edges, white text. */
public final class Widgets {
    private Widgets() {}

    private static final DateTimeFormatter CLOCK_FMT = DateTimeFormatter.ofPattern("h:mm a");
    private static final String[] ROMAN = {"", "", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final String[] ARMOR_LETTER = {"H", "C", "L", "B"};
    private static final int NAME_CAT_W = 20;

    // ---- the elements, in default stacking order (top of the left column first) ----
    public static final HudWidget FPS = new Pill(Module.FPS, "FPS",
            c -> HudRenderer.fps() + "  avg " + HudRenderer.avgFps());
    public static final HudWidget CPS = new Pill(Module.CPS, "CPS",
            c -> Cps.left() + " | " + Cps.right());
    public static final HudWidget PING = new Pill(Module.PING, "PING", c -> {
        int p = HudRenderer.ping(c.mc);
        return p < 0 ? "--" : p + " ms";
    });
    public static final HudWidget COORDS = new Pill(Module.COORDS, "XYZ", c -> {
        if (c.mc.player == null) return "--";
        return Mth.floor(c.mc.player.getX()) + "  " + Mth.floor(c.mc.player.getY()) + "  " + Mth.floor(c.mc.player.getZ());
    });
    public static final HudWidget CLOCK = new Pill(Module.CLOCK, "TIME",
            c -> LocalTime.now().format(CLOCK_FMT).toUpperCase());
    public static final HudWidget BIOME = new Pill(Module.BIOME, "BIOME", Widgets::biome);
    public static final HudWidget DIRECTION = new Compass();
    public static final HudWidget CPS_GRAPH = new Graph(Module.CPS_GRAPH, "CPS",
            c -> Cps.left() + " | " + Cps.right(), HudRenderer.CPS_L, HudRenderer.CPS_R, 12f, 0);
    public static final HudWidget PING_GRAPH = new Graph(Module.PING_GRAPH, "PING", c -> {
        int p = HudRenderer.ping(c.mc);
        return p < 0 ? "--" : p + " ms";
    }, HudRenderer.PING_HIST, null, 100f, 1);
    public static final HudWidget FPS_GRAPH = new Graph(Module.FPS_GRAPH, "FPS",
            c -> HudRenderer.fps() + "", HudRenderer.FPS_SAMPLES, null, 60f, 0);
    public static final HudWidget TARGET = new Target();
    public static final HudWidget NAME = new Name();
    public static final HudWidget KEYSTROKES = new Keystrokes();
    public static final HudWidget POTIONS = new Potions();
    public static final HudWidget ARMOR = new Armor();
    public static final HudWidget ITEM = new HeldItem();
    public static final HudWidget LOGO = new Logo();

    public static final List<HudWidget> ALL = List.of(
            FPS, CPS, PING, COORDS, CLOCK, BIOME, DIRECTION, CPS_GRAPH, PING_GRAPH, FPS_GRAPH,
            NAME, TARGET, KEYSTROKES, POTIONS, ARMOR, ITEM, LOGO);

    /** Every widget, including the v0.6 ones (see Extra). */
    public static List<HudWidget> all() {
        return ALL_V6;
    }
    private static final List<HudWidget> ALL_V6 = buildAll();

    private static List<HudWidget> buildAll() {
        List<HudWidget> l = new java.util.ArrayList<>(ALL);
        l.addAll(Extra.widgets());
        return java.util.Collections.unmodifiableList(l);
    }

    // ================= shared drawing bits =================

    static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        int r = (int) Math.max(2, Math.min(10, Modules.textNum("radius", 4)));
        Gfx.roundRectV(g, x, y, w, h, r, Style.bgTop(), Style.bg());
        Gfx.roundOutline(g, x, y, w, h, r, Style.edge());
        if (Style.glass() && Style.edge() != 0 && w > 10) {
            boolean liquid = Style.look() == Style.LOOK_LIQUID;
            g.fill(x + r, y + 1, x + w - r, y + 2, liquid ? 0x55FFFFFF : 0x30FFFFFF); // glass highlight along the top
            if (liquid && h > 12) {
                g.fill(x + r + 2, y + 2, x + w - r - 2, y + 3, 0x1CFFFFFF);                     // soft second sheen
                g.fill(x + r, y + h - 2, x + w - r, y + h - 1, 0x22FFFFFF);                     // light caught on the lower rim
            }
        }
    }

    /** Horizontal line coloured along the accent gradient. */
    static void gradLine(GuiGraphicsExtractor g, int x1, int x2, int y, float alpha) {
        int n = Math.max(1, x2 - x1);
        for (int i = 0; i < n; i += 3) {
            int seg = Math.min(3, n - i);
            g.fill(x1 + i, y, x1 + i + seg, y + 1, Gfx.mulAlpha(Style.accentAt(i / (float) n), alpha));
        }
    }

    private static void bar(GuiGraphicsExtractor g, int x, int baseY, int areaH, float frac, int color) {
        if (frac <= 0f) return;
        int bh = Math.max(1, Math.round(Mth.clamp(frac, 0f, 1f) * areaH));
        g.fill(x, baseY - bh, x + 2, baseY, color);
    }

    private static String biome(HudCtx c) {
        Minecraft mc = c.mc;
        if (mc.level == null || mc.player == null) return "--";
        try {
            String path = mc.level.getBiome(mc.player.blockPosition())
                    .unwrapKey().map(k -> k.identifier().getPath()).orElse("unknown");
            StringBuilder sb = new StringBuilder();
            for (String part : path.split("_")) {
                if (part.isEmpty()) continue;
                if (sb.length() > 0) sb.append(' ');
                sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
            }
            return sb.toString();
        } catch (Throwable t) {
            return "--";
        }
    }

    /** Durability number + a 3px bar (white > amber > red as it wears down). */
    private static void durability(GuiGraphicsExtractor g, HudCtx c, ItemStack st, int x, int y, int w) {
        if (!st.isDamageableItem()) {
            Gfx.text(g, c.font, "-", x, y + 2, Style.DIM);
            g.fill(x, y + 12, x + w, y + 15, Style.FAINT);
            return;
        }
        int max = st.getMaxDamage();
        int left = max - st.getDamageValue();
        float frac = Mth.clamp(left / (float) max, 0f, 1f);
        int col = frac > 0.5f ? Style.accentAt(frac) : (frac > 0.2f ? Style.AMBER : Style.RED);
        Gfx.text(g, c.font, String.valueOf(left), x, y + 2, frac > 0.5f ? 0xFFE8E8EC : col);
        g.fill(x, y + 12, x + w, y + 15, Style.TRACK);
        g.fill(x, y + 12, x + Math.max(1, Math.round(w * frac)), y + 15, col);
    }

    // ================= "LABEL value" pill =================

    private static final class Pill extends HudWidget {
        private final String label;
        private final Function<HudCtx, String> value;
        private String text = "";

        Pill(Module m, String label, Function<HudCtx, String> value) {
            super(m);
            this.label = label;
            this.value = value;
        }

        @Override
        public void layout(HudCtx c) {
            text = value.apply(c);
            w = Gfx.width(c.font, label) + 6 + Gfx.width(c.font, text) + 14;
            h = 16;
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            panel(g, x, y, w, h);
            Gfx.text(g, c.font, label, x + 7, y + 4, Style.DIM);
            Gfx.text(g, c.font, text, x + 7 + Gfx.width(c.font, label) + 6, y + 4, Style.WHITE);
        }
    }

    // ================= name tag =================

    private static final class Name extends HudWidget {
        private String name = "Player";
        private boolean badge;

        Name() {
            super(Module.NAME);
        }

        @Override
        public void layout(HudCtx c) {
            name = c.mc.player == null ? "Player" : c.mc.player.getName().getString();
            badge = Modules.nameBadge();
            int tw = Gfx.width(c.font, name);
            w = (badge ? 6 + NAME_CAT_W + 5 : 9) + tw + 9;
            h = 18;
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            panel(g, x, y, w, h);
            int tx = x + 9;
            if (badge) {
                int ch = Cat.heightFor(NAME_CAT_W);
                Cat.draw(g, x + 6, y + (h - ch) / 2, NAME_CAT_W, Cat.blink(c.time));
                tx = x + 6 + NAME_CAT_W + 5;
            }
            Gfx.text(g, c.font, name, tx, y + 5, Style.WHITE);
            gradLine(g, tx, tx + Gfx.width(c.font, name), y + h - 3, 0.8f);
        }
    }

    // ================= logo =================

    private static final class Logo extends HudWidget {
        Logo() {
            super(Module.LOGO);
        }

        @Override
        public void layout(HudCtx c) {
            w = LogoBadge.W;
            h = LogoBadge.H;
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            LogoBadge.draw(g, x, y, 1f, c.time);
        }
    }

    // ================= direction compass =================

    private static final class Compass extends HudWidget {
        private static final String[] NAMES = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

        Compass() {
            super(Module.DIRECTION);
        }

        @Override
        public void layout(HudCtx c) {
            w = 132;
            h = 20;
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            panel(g, x, y, w, h);
            float yaw = Freelook.active() ? Freelook.yaw() : (c.mc.player == null ? 0f : c.mc.player.getYRot());
            float heading = Mth.wrapDegrees(yaw + 180f); // 0 = north, 90 = east
            float cx = x + w / 2f;
            float pxPerDeg = 1.15f;

            for (int deg = 0; deg < 360; deg += 15) {
                float diff = Mth.wrapDegrees(deg - heading);
                float px = cx + diff * pxPerDeg;
                if (px < x + 6 || px > x + w - 6) continue;
                if (deg % 45 != 0) {
                    g.fill(Math.round(px), y + h - 6, Math.round(px) + 1, y + h - 3, Style.FAINT);
                    continue;
                }
                String s = NAMES[deg / 45];
                int tw = Gfx.width(c.font, s);
                int tx = Math.round(px - tw / 2f);
                if (tx < x + 4 || tx + tw > x + w - 4) continue;
                Gfx.text(g, c.font, s, tx, y + 4, deg % 90 == 0 ? Style.WHITE : Style.DIM);
            }
            g.fill(Math.round(cx), y + h - 4, Math.round(cx) + 1, y + h - 1, Style.accent());
        }
    }

    // ================= graphs (CPS, FPS, ping) =================

    private static final class Graph extends HudWidget {
        private static final int SAMPLES = 46;

        private final String title;
        private final Function<HudCtx, String> value;
        private final ArrayDeque<Float> a;
        private final ArrayDeque<Float> b;
        private final float minScale;
        /** 0 = plain, 1 = latency (colours by ms, shows min / avg / max). */
        private final int mode;
        private String text = "";
        private int cachedVersion = -1;
        private float cMax;
        private float cLo;
        private float cHi;
        private float cAvg;

        Graph(Module m, String title, Function<HudCtx, String> value, ArrayDeque<Float> a, ArrayDeque<Float> b,
              float minScale, int mode) {
            super(m);
            this.title = title;
            this.value = value;
            this.a = a;
            this.b = b;
            this.minScale = minScale;
            this.mode = mode;
        }

        @Override
        public void layout(HudCtx c) {
            text = value.apply(c);
            w = 108;
            h = mode == 1 ? 52 : 42;
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            panel(g, x, y, w, h);
            Gfx.text(g, c.font, title, x + 7, y + 4, Style.DIM);
            Gfx.text(g, c.font, text, x + w - 7 - Gfx.width(c.font, text), y + 4, Style.WHITE);

            int baseY = y + (mode == 1 ? h - 15 : h - 5);
            int areaH = 20;
            int left = x + 7;

            if (cachedVersion != HudRenderer.version) { // numbers only change when a sample arrives
                cachedVersion = HudRenderer.version;
                cMax = minScale;
                cLo = Float.MAX_VALUE;
                cHi = 0f;
                float total = 0f;
                for (float v : a) {
                    cMax = Math.max(cMax, v);
                    cLo = Math.min(cLo, v);
                    cHi = Math.max(cHi, v);
                    total += v;
                }
                cAvg = a.isEmpty() ? 0f : total / a.size();
                if (b != null) for (float v : b) cMax = Math.max(cMax, v);
            }
            float max = cMax;

            g.fill(left, baseY - areaH / 2, left + SAMPLES * 2, baseY - areaH / 2 + 1, Style.TRACK);

            if (b != null) {
                int i = 0;
                for (float v : b) {
                    bar(g, left + i * 2, baseY, areaH, v / max, 0xFF55555D);
                    i++;
                }
            }
            int i = 0;
            for (float v : a) {
                int col = Style.accentAt(i / (float) SAMPLES);
                if (mode == 1) col = v > 150 ? Style.RED : (v > 80 ? Style.AMBER : col);
                bar(g, left + i * 2, baseY, areaH, v / max, col);
                i++;
            }
            if (mode == 1) {
                String st = a.isEmpty() ? "min -   avg -   max -"
                        : "min " + Math.round(cLo) + "   avg " + Math.round(cAvg) + "   max " + Math.round(cHi);
                Gfx.text(g, c.font, st, x + 7, y + h - 11, Style.DIM);
            }
        }
    }

    // ================= keystrokes 2.0 =================

    private static final class Keystrokes extends HudWidget {
        private final Smooth[] anim = new Smooth[7];

        Keystrokes() {
            super(Module.KEYSTROKES);
            for (int i = 0; i < anim.length; i++) anim[i] = new Smooth(0f);
        }

        @Override
        public void layout(HudCtx c) {
            w = 66;
            h = 85;
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            var o = c.mc.options;
            key(g, c, 0, o.keyUp, "W", x + 23, y, 20, 20, null);
            key(g, c, 1, o.keyLeft, "A", x, y + 23, 20, 20, null);
            key(g, c, 2, o.keyDown, "S", x + 23, y + 23, 20, 20, null);
            key(g, c, 3, o.keyRight, "D", x + 46, y + 23, 20, 20, null);
            key(g, c, 4, o.keyAttack, "LMB", x, y + 46, 31, 24, String.valueOf(Cps.left()));
            key(g, c, 5, o.keyUse, "RMB", x + 35, y + 46, 31, 24, String.valueOf(Cps.right()));
            key(g, c, 6, o.keyJump, null, x, y + 73, 66, 12, null);
        }

        private void key(GuiGraphicsExtractor g, HudCtx c, int i, KeyMapping binding, String label,
                         int x, int y, int kw, int kh, String sub) {
            float s = anim[i].update(binding.isDown() ? 1f : 0f, c.dt, 24f);
            int bg = Gfx.lerpColor(Style.bg(), Style.accent(), s);
            int edge = Gfx.lerpColor(Style.edge(), Style.accent(), s);
            int fg = Gfx.lerpColor(Style.WHITE, 0xFF0B0B0D, s);
            int subCol = Gfx.lerpColor(Style.DIM, 0xFF55555D, s);

            float scale = 1f - 0.07f * s; // a tiny press-in
            float cx = x + kw / 2f;
            float cy = y + kh / 2f;
            g.pose().pushMatrix();
            g.pose().translate(cx, cy);
            g.pose().scale(scale, scale);
            g.pose().translate(-cx, -cy);

            Gfx.roundRect(g, x, y, kw, kh, 4, bg);
            Gfx.roundOutline(g, x, y, kw, kh, 4, edge);
            if (label != null) {
                int ty = sub != null ? y + 4 : y + (kh - 8) / 2;
                Gfx.text(g, c.font, label, x + (kw - Gfx.width(c.font, label)) / 2, ty, fg);
            } else {
                int lw = 20; // space bar: a small line
                g.fill(x + (kw - lw) / 2, y + kh / 2, x + (kw + lw) / 2, y + kh / 2 + 1, fg);
            }
            if (sub != null) {
                Gfx.text(g, c.font, sub, x + (kw - Gfx.width(c.font, sub)) / 2, y + 14, subCol);
            }
            g.pose().popMatrix();
        }
    }

    // ================= armor =================

    private static final class Armor extends HudWidget {
        Armor() {
            super(Module.ARMOR);
        }

        @Override
        public void layout(HudCtx c) {
            w = 74;
            h = 4 * 20 + 6;
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            panel(g, x, y, w, h);
            for (int i = 0; i < 4; i++) {
                int ry = y + 3 + i * 20;
                ItemStack st = c.mc.player == null ? ItemStack.EMPTY : c.mc.player.getItemBySlot(ARMOR_SLOTS[i]);
                if (st.isEmpty()) {
                    Gfx.text(g, c.font, ARMOR_LETTER[i], x + 9, ry + 6, Style.FAINT);
                    g.fill(x + 24, ry + 9, x + w - 8, ry + 10, Style.TRACK);
                    continue;
                }
                if (!Gfx.item(g, st, x + 4, ry + 1)) {
                    Gfx.text(g, c.font, ARMOR_LETTER[i], x + 9, ry + 6, Style.WHITE);
                }
                durability(g, c, st, x + 24, ry, w - 24 - 7);
            }
        }
    }

    // ================= held item =================

    private static final class HeldItem extends HudWidget {
        private ItemStack st = ItemStack.EMPTY;
        private boolean sample;
        private String name = "";

        HeldItem() {
            super(Module.ITEM);
        }

        @Override
        public void layout(HudCtx c) {
            st = c.mc.player == null ? ItemStack.EMPTY : c.mc.player.getMainHandItem();
            sample = st.isEmpty();
            visible = !sample || c.preview;
            if (!visible) {
                w = 0;
                h = 0;
                return;
            }
            name = sample ? "Held item" : st.getHoverName().getString();
            if (!sample && st.getCount() > 1) name += "  x" + st.getCount();
            w = 118;
            h = 32;
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            panel(g, x, y, w, h);
            boolean icon = !sample && Gfx.item(g, st, x + 5, y + 5);
            if (!icon) Gfx.text(g, c.font, "I", x + 10, y + 9, sample ? Style.FAINT : Style.WHITE);
            Gfx.text(g, c.font, Gfx.fit(c.font, name, w - 32), x + 26, y + 4, sample ? Style.DIM : Style.WHITE);
            if (sample) {
                Gfx.text(g, c.font, "durability shows here", x + 26, y + 14, Style.FAINT);
            } else if (st.isDamageableItem()) {
                int left = st.getMaxDamage() - st.getDamageValue();
                float frac = Mth.clamp(left / (float) st.getMaxDamage(), 0f, 1f);
                Gfx.text(g, c.font, left + " / " + st.getMaxDamage(), x + 26, y + 14, Style.DIM);
                g.fill(x + 5, y + h - 6, x + w - 5, y + h - 3, Style.TRACK);
                g.fill(x + 5, y + h - 6, x + 5 + Math.max(1, Math.round((w - 10) * frac)), y + h - 3,
                        frac > 0.5f ? Style.accentAt(frac) : (frac > 0.2f ? Style.AMBER : Style.RED));
            } else {
                Gfx.text(g, c.font, "no durability", x + 26, y + 14, Style.FAINT);
            }
        }
    }

    // ================= target info =================

    private static final class Target extends HudWidget {
        private net.minecraft.world.entity.LivingEntity target;
        private long lastSeen;
        private final Smooth hp = new Smooth(1f);
        private String name = "";
        private String hpText = "";
        private String dist = "";
        private float frac = 1f;

        Target() {
            super(Module.TARGET);
        }

        @Override
        public void layout(HudCtx c) {
            Minecraft mc = c.mc;
            long now = System.currentTimeMillis();
            if (mc.hitResult instanceof net.minecraft.world.phys.EntityHitResult hit
                    && hit.getEntity() instanceof net.minecraft.world.entity.LivingEntity le) {
                target = le;
                lastSeen = now;
            }
            boolean sample = false;
            if (mc.level == null || (target != null && target.isRemoved())) target = null; // world changed / target gone
            if (target == null || !target.isAlive() || now - lastSeen > 3000) {
                target = null;
                sample = c.preview;
                if (!sample) {
                    visible = false;
                    w = 0;
                    h = 0;
                    return;
                }
            }
            visible = true;
            if (sample) {
                name = "Target";
                frac = 0.7f;
                hpText = "14 / 20  8 AR";
                dist = "3.2 m";
            } else {
                name = target.getName().getString();
                float max = Math.max(1f, target.getMaxHealth());
                frac = Mth.clamp(target.getHealth() / max, 0f, 1f);
                hpText = Math.round(target.getHealth()) + " / " + Math.round(max) + "  " + target.getArmorValue() + " AR";
                dist = mc.player == null ? "" : String.format("%.1f m", mc.player.distanceTo(target));
            }
            w = Math.max(104, Gfx.width(c.font, name) + 20);
            h = 30;
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            panel(g, x, y, w, h);
            Gfx.text(g, c.font, Gfx.fit(c.font, name, w - 14), x + 7, y + 4, Style.WHITE);
            hp.update(frac, c.dt, 10f);
            int bw = w - 14;
            g.fill(x + 7, y + 15, x + 7 + bw, y + 18, Style.TRACK);
            int col = frac > 0.5f ? Style.accentAt(frac) : (frac > 0.25f ? Style.AMBER : Style.RED);
            g.fill(x + 7, y + 15, x + 7 + Math.max(1, Math.round(bw * Mth.clamp(hp.value, 0f, 1f))), y + 18, col);
            Gfx.text(g, c.font, hpText, x + 7, y + 20, Style.DIM);
            Gfx.text(g, c.font, dist, x + w - 7 - Gfx.width(c.font, dist), y + 20, Style.DIM);
        }
    }

    // ================= potion effects =================

    private static final class Potions extends HudWidget {
        private final List<String> names = new ArrayList<>();
        private final List<String> times = new ArrayList<>();
        private final List<Integer> durations = new ArrayList<>();
        private final List<Integer> maxes = new ArrayList<>();
        /** Longest duration seen per effect, so the bar can show how much is left. */
        private final java.util.Map<String, Integer> longest = new java.util.HashMap<>();

        Potions() {
            super(Module.POTIONS);
        }

        private static String effectName(MobEffectInstance e) {
            String raw = e.getEffect().unwrapKey().map(k -> k.identifier().getPath()).orElse("effect");
            StringBuilder sb = new StringBuilder();
            for (String part : raw.split("_")) {
                if (part.isEmpty()) continue;
                if (sb.length() > 0) sb.append(' ');
                sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
            }
            return sb.toString();
        }

        @Override
        public void layout(HudCtx c) {
            names.clear();
            times.clear();
            durations.clear();
            maxes.clear();
            if (c.mc.player != null) {
                List<MobEffectInstance> list = new ArrayList<>(c.mc.player.getActiveEffects());
                list.sort((p, q) -> Integer.compare(q.getDuration(), p.getDuration()));
                for (MobEffectInstance e : list) {
                    String n = effectName(e);
                    int amp = e.getAmplifier() + 1;
                    if (amp > 1) n += " " + (amp < ROMAN.length ? ROMAN[amp] : String.valueOf(amp));
                    add(n, e.getDuration());
                }
            }
            if (names.isEmpty() && c.preview) {
                add("Speed II", 1800);
                add("Strength", 4800);
            }
            visible = !names.isEmpty();
            if (!visible) {
                w = 0;
                h = 0;
                return;
            }
            int width = 80;
            for (int i = 0; i < names.size(); i++) {
                width = Math.max(width, Gfx.width(c.font, names.get(i)) + Gfx.width(c.font, times.get(i)) + 26);
            }
            w = width;
            h = names.size() * 18 + 6;
        }

        private void add(String name, int ticks) {
            int mx = longest.merge(name, Math.max(ticks, 1), Math::max);
            if (ticks > mx) mx = ticks;
            maxes.add(mx);
            names.add(name);
            times.add(ticks < 0 ? "inf" : (ticks / 20 / 60) + ":" + String.format("%02d", (ticks / 20) % 60));
            durations.add(ticks);
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            panel(g, x, y, w, h);
            for (int i = 0; i < names.size(); i++) {
                int ry = y + 3 + i * 18;
                int d = durations.get(i);
                int col = (d >= 0 && d < 200) ? ((System.currentTimeMillis() / 300) % 2 == 0 ? Style.RED : Style.DIM) : Style.WHITE;
                Gfx.text(g, c.font, names.get(i), x + 8, ry + 3, Style.TEXT);
                Gfx.text(g, c.font, times.get(i), x + w - 8 - Gfx.width(c.font, times.get(i)), ry + 3, col);
                int bw = w - 16;
                g.fill(x + 8, ry + 13, x + 8 + bw, ry + 15, Style.TRACK);
                float frac = d < 0 ? 1f : Mth.clamp(d / (float) Math.max(1, maxes.get(i)), 0f, 1f);
                int fillW = Math.max(1, Math.round(bw * frac));
                int bc = (d >= 0 && d < 200) ? Style.RED : Style.accentAt(frac);
                g.fill(x + 8, ry + 13, x + 8 + fillW, ry + 15, bc);
            }
        }
    }
}
