package studio.blackcat.client.hud;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;

/** Custom crosshair (styles) that flashes a colour on a successful hit. Falls back to the vanilla one when off. */
public final class Crosshair {
    private Crosshair() {}

    public static HudElement wrap(HudElement vanilla) {
        return (GuiGraphicsExtractor g, DeltaTracker dt) -> {
            if (!Modules.isEnabled(Module.CROSSHAIR)) {
                vanilla.extractRenderState(g, dt);
                return;
            }
            try {
                draw(g);
            } catch (Throwable t) {
                vanilla.extractRenderState(g, dt);
            }
        };
    }

    private static void draw(GuiGraphicsExtractor g) {
        var mc = net.minecraft.client.Minecraft.getInstance();
        if (mc.player == null || !mc.options.getCameraType().isFirstPerson()) return;
        int cx = g.guiWidth() / 2;
        int cy = g.guiHeight() / 2;
        boolean hit = System.currentTimeMillis() < Stats.hitFlashUntil;
        int col = hit ? 0xFFFF4D4D : parse(Modules.text("xh_color"), 0xFFFFFFFF);
        String style = Modules.text("xh_style");
        int size = (int) Math.max(2, Math.min(12, Modules.textNum("xh_size", 5)));
        int gap = (int) Math.max(0, Math.min(8, Modules.textNum("xh_gap", 2)));
        switch (style) {
            case "dot" -> g.fill(cx - 1, cy - 1, cx + 1, cy + 1, col);
            case "circle" -> {
                int r = size;
                for (int a = 0; a < 360; a += 12) {
                    int px = cx + (int) Math.round(Math.cos(Math.toRadians(a)) * r);
                    int py = cy + (int) Math.round(Math.sin(Math.toRadians(a)) * r);
                    g.fill(px, py, px + 1, py + 1, col);
                }
            }
            case "cross" -> {
                g.fill(cx - size - gap, cy, cx - gap, cy + 1, col);
                g.fill(cx + gap + 1, cy, cx + gap + size + 1, cy + 1, col);
                g.fill(cx, cy - size - gap, cx + 1, cy - gap, col);
                g.fill(cx, cy + gap + 1, cx + 1, cy + gap + size + 1, col);
            }
            default -> { // plus
                g.fill(cx - size, cy, cx + size + 1, cy + 1, col);
                g.fill(cx, cy - size, cx + 1, cy + size + 1, col);
            }
        }
    }

    private static int parse(String s, int def) {
        try {
            String t = s.trim();
            if (t.startsWith("#")) t = t.substring(1);
            return 0xFF000000 | Integer.parseInt(t, 16);
        } catch (Exception e) {
            return def;
        }
    }
}
