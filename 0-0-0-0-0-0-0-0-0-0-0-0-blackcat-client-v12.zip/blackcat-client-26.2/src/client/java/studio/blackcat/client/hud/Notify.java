package studio.blackcat.client.hud;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.util.Mth;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.util.Cat;
import studio.blackcat.client.util.Gfx;

import java.util.ArrayList;
import java.util.List;

/** Smart notifications, the cat companion and the dashboard widget. */
public final class Notify {
    private Notify() {}

    private static final long LIFE_MS = 4000;
    private static final List<long[]> TIMES = new ArrayList<>();
    private static final List<String> TEXTS = new ArrayList<>();
    public static long lastEventMs;
    public static String lastEvent = "";

    private static boolean warnedGear;
    private static String warnedEffect = "";

    /** Shows a small pop-up (when Notifications is on) and makes the cat react (when Cat Companion is on). */
    public static void push(String text) {
        long now = System.currentTimeMillis();
        lastEventMs = now;
        lastEvent = text;
        if (!Modules.isEnabled(Module.NOTIFY)) return;
        TIMES.add(new long[]{now});
        TEXTS.add(text);
        while (TEXTS.size() > 4) {
            TEXTS.remove(0);
            TIMES.remove(0);
        }
    }

    /** Checks durability and effects about once a second. */
    public static void tick(net.minecraft.client.Minecraft mc, int tickCount) {
        if (mc.player == null || tickCount % 20 != 0) return;
        HudCtx c = new HudCtx(mc, 0f, false);
        String gear = Extra.lowGear(c);
        if (!gear.isEmpty() && !warnedGear) push("Low durability: " + gear);
        warnedGear = !gear.isEmpty();
        String fx = "";
        for (var e : mc.player.getActiveEffects()) {
            if (!e.isInfiniteDuration() && e.getDuration() <= 200) {
                fx = e.getEffect().unwrapKey().map(k -> k.identifier().getPath()).orElse("effect");
                break;
            }
        }
        if (!fx.isEmpty() && !fx.equals(warnedEffect)) push("Effect running out: " + fx.replace('_', ' '));
        warnedEffect = fx;
    }

    // ---------- widgets ----------

    static final class Toasts extends HudWidget {
        private final List<String> live = new ArrayList<>();

        Toasts() {
            super(Module.NOTIFY);
        }

        @Override
        public void layout(HudCtx c) {
            live.clear();
            long now = System.currentTimeMillis();
            for (int i = 0; i < TEXTS.size(); i++) {
                if (now - TIMES.get(i)[0] < LIFE_MS) live.add(TEXTS.get(i));
            }
            if (live.isEmpty() && c.preview) live.add("Notifications look like this");
            visible = !live.isEmpty();
            int mw = 0;
            for (String s : live) mw = Math.max(mw, Gfx.width(c.font, s));
            w = mw + 16;
            h = live.size() * 18 - 2;
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            for (int i = 0; i < live.size(); i++) {
                int yy = y + i * 18;
                Widgets.panel(g, x, yy, w, 16);
                g.fill(x + 2, yy + 3, x + 3, yy + 13, Style.accent());
                Gfx.text(g, c.font, live.get(i), x + 8, yy + 4, Style.WHITE);
            }
        }
    }

    static final class Companion extends HudWidget {
        Companion() {
            super(Module.CAT);
        }

        @Override
        public void layout(HudCtx c) {
            int size = (int) Mth.clamp(Modules.textNum("cat_size", 40), 24, 80);
            w = size + 6;
            h = Cat.heightFor(size) + 6;
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            int size = w - 6;
            long since = System.currentTimeMillis() - lastEventMs;
            boolean excited = lastEventMs != 0 && since < 2500;
            float t = c.time;
            float bob = excited ? (float) Math.sin(t * 14f) * 2f : (float) Math.sin(t * 2f) * 1f;
            String style = Modules.text("cat_style");
            float eyes;
            if (style.equals("awake")) eyes = 1f;
            else if (style.equals("sleepy")) eyes = 0f;
            else if (excited) eyes = 1f;
            else eyes = Cat.blink(t);
            Cat.draw(g, x + 3, y + 3 + Math.round(bob), size, eyes);
            if (excited && !lastEvent.isEmpty()) {
                String s = Gfx.fit(c.font, lastEvent, 140);
                int bw = Gfx.width(c.font, s) + 10;
                int bx = x + w + 2;
                Widgets.panel(g, bx, y + 2, bw, 16);
                Gfx.text(g, c.font, s, bx + 5, y + 6, Style.WHITE);
            }
        }
    }

    static final class Dashboard extends HudWidget {
        Dashboard() {
            super(Module.DASHBOARD);
        }

        @Override
        public void layout(HudCtx c) {
            w = 150;
            h = 68;
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            Widgets.panel(g, x, y, w, h);
            Gfx.text(g, c.font, "BLACK CAT", x + 8, y + 6, Style.WHITE);
            Widgets.gradLine(g, x + 8, x + w - 8, y + 17, 0.8f);
            int active = 0;
            for (Module m : Module.values()) if (Modules.isEnabled(m)) active++;
            long sec = (System.currentTimeMillis() - Stats.SESSION_START) / 1000;
            row(g, c, x, y + 22, "Profile", Modules.profileName());
            row(g, c, x, y + 33, "Modules", active + " active");
            row(g, c, x, y + 44, "Session", (sec / 60) + "m " + String.format("%02d", sec % 60) + "s");
            row(g, c, x, y + 55, "Fights", Stats.hits + " hits, best combo " + Math.max(Stats.combo, 0));
        }

        private void row(GuiGraphicsExtractor g, HudCtx c, int x, int y, String k, String v) {
            Gfx.text(g, c.font, k, x + 8, y, Style.DIM);
            String s = Gfx.fit(c.font, v, w - 62);
            Gfx.text(g, c.font, s, x + 54, y, Style.WHITE);
        }
    }
}
