package studio.blackcat.client.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import studio.blackcat.client.BlackCatClient;
import studio.blackcat.client.util.Cat;
import studio.blackcat.client.util.Gfx;

/**
 * Replaces the Minecraft logo on the title screen: the Black Cat (blinking), the wordmark and a small credit line.
 * The vanilla logo itself is switched off by TitleLogoMixin.
 */
public final class TitleBrand {
    private TitleBrand() {}

    private static final int WORD_TEX_W = 960, WORD_TEX_H = 96;
    private static final int WORD_W = 220;
    private static final int WORD_H = WORD_W * WORD_TEX_H / WORD_TEX_W;
    private static final int CAT_W = 64;
    public static final String CREDIT = "Claude x Aaju";

    public static void render(GuiGraphicsExtractor g, Font font, int screenW) {
        int cx = screenW / 2;
        int y = 8;
        int catH = Cat.heightFor(CAT_W);
        Cat.draw(g, cx - CAT_W / 2, y, CAT_W, Cat.blink(Cat.time()));
        y += catH + 4;
        Gfx.textureFit(g, BlackCatClient.WORDMARK, cx - WORD_W / 2, y, WORD_W, WORD_H, WORD_TEX_W, WORD_TEX_H);
        y += WORD_H + 5;
        Gfx.text(g, font, CREDIT, cx - Gfx.width(font, CREDIT) / 2, y, 0xFF8C8C95);
    }
}
