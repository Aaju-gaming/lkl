package studio.blackcat.client;

import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import studio.blackcat.client.Modules.Module;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Auto GG, Quick Commands, Chat Timestamps and Chat Filter. Every handler is wrapped so chat can never break. */
public final class ChatFeatures {
    private ChatFeatures() {}

    private static long lastGg;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("HH:mm");

    public static void register() {
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> allow(message, overlay));
        ClientReceiveMessageEvents.ALLOW_CHAT.register((message, signed, sender, type, ts) -> allow(message, false));

        ClientReceiveMessageEvents.MODIFY_GAME.register((message, overlay) -> {
            try {
                if (!overlay && Modules.isEnabled(Module.TIMESTAMPS)) {
                    return Component.literal("[" + LocalTime.now().format(FMT) + "] ").append(message);
                }
            } catch (Throwable ignored) {
                // leave the message alone
            }
            return message;
        });

        ClientSendMessageEvents.ALLOW_COMMAND.register(command -> {
            try {
                if (!Modules.isEnabled(Module.QUICK_CMD)) return true;
                String word = command.trim();
                for (String pair : Modules.text("quick").split(";")) {
                    int eq = pair.indexOf('=');
                    if (eq <= 0) continue;
                    String alias = pair.substring(0, eq).trim();
                    String target = pair.substring(eq + 1).trim();
                    if (alias.isEmpty() || target.isEmpty()) continue;
                    if (word.equalsIgnoreCase(alias) || word.toLowerCase(Locale.ROOT).startsWith(alias.toLowerCase(Locale.ROOT) + " ")) {
                        String rest = word.length() > alias.length() ? word.substring(alias.length()) : "";
                        String full = (target.startsWith("/") ? target.substring(1) : target) + rest;
                        if (full.equalsIgnoreCase(word)) return true; // would loop
                        Minecraft mc = Minecraft.getInstance();
                        if (mc.getConnection() != null) mc.getConnection().sendCommand(full);
                        return false;
                    }
                }
            } catch (Throwable ignored) {
                // send as typed
            }
            return true;
        });
    }

    private static boolean allow(Component message, boolean overlay) {
        try {
            if (overlay) return true;
            String text = message.getString();
            String low = text.toLowerCase(Locale.ROOT);

            if (Modules.isEnabled(Module.CHAT_FILTER)) {
                for (String w : Modules.text("filter").split(",")) {
                    w = w.trim().toLowerCase(Locale.ROOT);
                    if (!w.isEmpty() && low.contains(w)) return false;
                }
            }
            if (Modules.isEnabled(Module.AUTO_GG)) {
                long now = System.currentTimeMillis();
                if (now - lastGg > 15000) {
                    for (String t : Modules.text("autogg_trigger").split(",")) {
                        t = t.trim().toLowerCase(Locale.ROOT);
                        if (!t.isEmpty() && low.contains(t)) {
                            lastGg = now;
                            String msg = Modules.text("autogg");
                            Minecraft mc = Minecraft.getInstance();
                            if (!msg.isEmpty() && mc.getConnection() != null) mc.getConnection().sendChat(msg);
                            break;
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
            // never block chat because of a bug here
        }
        return true;
    }
}
