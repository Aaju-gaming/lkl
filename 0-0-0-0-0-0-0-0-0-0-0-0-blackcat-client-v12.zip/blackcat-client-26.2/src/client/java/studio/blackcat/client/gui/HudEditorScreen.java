package studio.blackcat.client.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.hud.HudCtx;
import studio.blackcat.client.hud.HudRenderer;
import studio.blackcat.client.hud.HudRenderer.Placed;
import studio.blackcat.client.hud.Style;
import studio.blackcat.client.util.Gfx;
import studio.blackcat.client.util.Smooth;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.input.KeyEvent;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * The HUD editor. Every switched-on element is shown where it sits; press and drag to move it, or select one
 * to change its size, background, opacity and colour, and to nudge it pixel by pixel (also with the arrow keys).
 * Elements snap to the screen edges, the centre lines and each other (a thin guide line shows what
 * they snapped to). Positions are saved as soon as you let go. Works with a mouse and with touch.
 */
public class HudEditorScreen extends Screen {
    private static final float SNAP = 4f;

    private static final int BTN_H = 16;
    private static final int BTN_GAP = 4;
    private static final int PROPS_H = 74;

    private final Smooth open = new Smooth(0f);
    private final Smooth[] glow = new Smooth[Module.values().length];

    private List<Placed> placed = new ArrayList<>();
    private Module selected;
    private Module dragging;
    private float dragX;
    private float dragY;
    private boolean moved;
    private float guideX = -1f;
    private float guideY = -1f;

    private int lastMouseX = -1;
    private int lastMouseY = -1;
    private long lastNanos = System.nanoTime();

    /** A clickable button, rebuilt every frame (immediate mode). */
    private record Btn(int x, int y, int w, int h, Runnable action) {
        boolean hit(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private final List<Btn> buttons = new ArrayList<>();
    private final java.util.ArrayDeque<String> undo = new java.util.ArrayDeque<>();
    private final java.util.ArrayDeque<String> redo = new java.util.ArrayDeque<>();
    private Btn undoBtn;
    private Btn redoBtn;
    private boolean linkMode;
    private final java.util.List<Module> linkSel = new ArrayList<>();
    private boolean resizing;
    private float resizeStartX;
    private float resizeStartScale;
    private float lastFx;
    private float lastFy;
    private Btn pressedBtn;

    public HudEditorScreen() {
        super(Component.literal("Edit HUD"));
        for (int i = 0; i < glow.length; i++) glow[i] = new Smooth(0f);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** No blur here: you need to see the game to place things relative to it. */
    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float a) {
    }

    // ---------- small UI helpers ----------

    private void button(GuiGraphicsExtractor g, int x, int y, int w, int h, String label, boolean primary,
                        boolean enabled, boolean active, float t, Runnable action) {
        boolean hov = enabled && lastMouseX >= x && lastMouseX < x + w && lastMouseY >= y && lastMouseY < y + h;
        int accent = Style.accent();
        int bg = primary ? Gfx.lerpColor(accent, 0xFFFFFFFF, hov ? 0.35f : 0f)
                : active ? 0xFF2A2A31 : (hov ? 0xFF212127 : 0xFF141418);
        int edge = primary ? bg : (active ? accent : (hov ? 0xFF8C8C95 : Style.EDGE));
        int fg = primary ? 0xFF0B0B0D : (enabled ? Style.WHITE : Style.FAINT);
        Gfx.roundRect(g, x, y, w, h, 4, Gfx.mulAlpha(bg, t));
        Gfx.roundOutline(g, x, y, w, h, 4, Gfx.mulAlpha(edge, t));
        Gfx.text(g, this.font, label, x + (w - Gfx.width(this.font, label)) / 2, y + (h - 8) / 2 + 1, Gfx.mulAlpha(fg, t));
        if (enabled && action != null) buttons.add(new Btn(x, y, w, h, action));
    }

    private int bw(String label) {
        return Gfx.width(this.font, label) + 12;
    }

    private Placed placedOf(Module m) {
        for (Placed p : placed) if (p.widget.module == m) return p;
        return null;
    }

    private void nudge(int dx, int dy) {
        Placed p = selected == null ? null : placedOf(selected);
        if (p == null) return;
        int nx = Math.max(0, Math.min(Math.max(0, width - p.ew()), p.x + dx));
        int ny = Math.max(0, Math.min(Math.max(0, height - p.eh()), p.y + dy));
        Modules.setPos(selected, nx / (float) width, ny / (float) height);
        Modules.save();
    }

    private void pushUndo() {
        String snap = Modules.snapshot();
        if (undo.isEmpty() || !undo.peek().equals(snap)) {
            undo.push(snap);
            while (undo.size() > 50) undo.removeLast();
        }
        redo.clear();
    }

    private void doUndo() {
        String cur = Modules.snapshot();
        while (!undo.isEmpty() && undo.peek().equals(cur)) undo.pop();
        if (undo.isEmpty()) return;
        redo.push(cur);
        Modules.restoreSnapshot(undo.pop());
    }

    private void doRedo() {
        if (redo.isEmpty()) return;
        undo.push(Modules.snapshot());
        Modules.restoreSnapshot(redo.pop());
    }

    private void toggleLink() {
        if (linkMode && linkSel.size() >= 2) Modules.group(new ArrayList<>(linkSel));
        linkMode = !linkMode;
        linkSel.clear();
    }

    private void cycleLayout() {
        java.util.List<String> names = Modules.profileNames();
        if (names.isEmpty()) return;
        int i = names.indexOf(Modules.profileName());
        Modules.loadProfile(names.get((i + 1) % names.size()));
    }

    // ---------- drawing ----------

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        lastMouseX = mouseX;
        lastMouseY = mouseY;
        buttons.clear();

        long now = System.nanoTime();
        float dt = Math.min((now - lastNanos) / 1_000_000_000f, 0.1f);
        lastNanos = now;
        open.update(1f, dt, 10f);
        float t = Gfx.easeOutCubic(open.value);
        Font font = this.font;
        int accent = Modules.accent();

        // soft dim so the outlines read well
        g.fill(0, 0, width, height, Gfx.argb(Math.round(60 * t), 0, 0, 0));

        // faint centre lines while dragging
        if (dragging != null) {
            g.fill(width / 2, 0, width / 2 + 1, height, Gfx.argb(24, 255, 255, 255));
            g.fill(0, height / 2, width, height / 2 + 1, Gfx.argb(24, 255, 255, 255));
        }

        HudCtx ctx = new HudCtx(this.minecraft, dt, true);
        placed = HudRenderer.place(ctx, width, height);
        if (selected != null && placedOf(selected) == null) selected = null;

        for (Placed p : placed) HudRenderer.drawPlaced(g, ctx, p);

        // outlines + names
        Placed top = null;
        for (int i = placed.size() - 1; i >= 0 && dragging == null; i--) {
            if (placed.get(i).contains(mouseX, mouseY)) {
                top = placed.get(i);
                break;
            }
        }
        for (Placed p : placed) {
            Module m = p.widget.module;
            boolean hot = m == dragging || m == selected || p == top || linkSel.contains(m)
                    || (selected != null && selected != m && Modules.groupOf(selected).contains(m));
            float k = glow[m.ordinal()].update(hot ? 1f : 0f, dt, 16f);
            int edge = Gfx.lerpColor(Gfx.argb(70, 255, 255, 255), accent, m == dragging ? 1f : k * 0.9f);
            Gfx.roundOutline(g, p.x - 2, p.y - 2, p.ew() + 4, p.eh() + 4, 5, Gfx.mulAlpha(edge, t));
            if (k > 0.05f) {
                String name = p.widget.title();
                int ly = p.y - 13 >= 1 ? p.y - 13 : p.y + p.eh() + 5;
                Gfx.text(g, font, name, p.x, ly, Gfx.mulAlpha(Style.WHITE, k));
            }
        }

        // resize handle on the selected element
        if (selected != null && !linkMode) {
            Placed sp = placedOf(selected);
            if (sp != null) {
                int hx = sp.x + sp.ew() - 3;
                int hy = sp.y + sp.eh() - 3;
                Gfx.roundRect(g, hx, hy, 7, 7, 2, Gfx.mulAlpha(resizing ? Style.WHITE : accent, t));
            }
        }

        // snap guides
        if (dragging != null) {
            int ga = Gfx.mulAlpha(accent, 0.8f);
            if (guideX >= 0f) g.fill(Math.round(guideX), 0, Math.round(guideX) + 1, height, ga);
            if (guideY >= 0f) g.fill(0, Math.round(guideY), width, Math.round(guideY) + 1, ga);
        }

        drawToolbar(g, font, t);
        if (selected != null) drawProps(g, font, t);

        if (placed.isEmpty()) {
            String msg = "No HUD modules are switched on. Turn some on in the menu first.";
            Gfx.text(g, font, msg, (width - Gfx.width(font, msg)) / 2, height / 2, Style.DIM);
        }
    }

    private void drawToolbar(GuiGraphicsExtractor g, Font font, float t) {
        String layout = "Layout: " + Gfx.fit(font, Modules.profileName(), 70);
        String[] row1 = {layout, "Save", "Reset all", "Done"};
        String linkLabel = linkMode ? (linkSel.size() >= 2 ? "Group them" : "Pick widgets") : "Link";
        String[] row2 = {"Undo", "Redo", linkLabel, "Ungroup"};
        int total1 = BTN_GAP * (row1.length - 1);
        for (String l : row1) total1 += bw(l);
        int total2 = BTN_GAP * (row2.length - 1);
        for (String l : row2) total2 += bw(l);
        int barW = Math.max(total1, total2) + 24;
        int barH = 66;
        int barX = (width - barW) / 2;
        int barY = 30;

        Gfx.roundRect(g, barX, barY, barW, barH, 6, Gfx.mulAlpha(0xF20B0B0D, t));
        Gfx.roundOutline(g, barX, barY, barW, barH, 6, Gfx.mulAlpha(Style.EDGE, t));
        String title = "EDIT HUD";
        Gfx.text(g, font, title, barX + 12, barY + 7, Gfx.mulAlpha(Style.WHITE, t));
        String hint = linkMode ? "tap widgets to link them" : "drag, tap to select, Z / Y undo / redo";
        Gfx.text(g, font, Gfx.fit(font, hint, barW - 30 - Gfx.width(font, title)), barX + 12 + Gfx.width(font, title) + 8, barY + 7,
                Gfx.mulAlpha(Style.DIM, t));

        int x = barX + 12;
        int y = barY + 24;
        for (int i = 0; i < row1.length; i++) {
            int w = bw(row1[i]);
            final int idx = i;
            button(g, x, y, w, BTN_H, row1[i], i == row1.length - 1, true, false, t, () -> {
                switch (idx) {
                    case 0 -> cycleLayout();
                    case 1 -> Modules.saveProfile(Modules.profileName());
                    case 2 -> {
                        Modules.resetAllPos();
                        Modules.save();
                    }
                    default -> this.minecraft.gui.setScreen(new HubScreen());
                }
            });
            x += w + BTN_GAP;
        }
        x = barX + 12;
        y = barY + 44;
        for (int i = 0; i < row2.length; i++) {
            int w = bw(row2[i]);
            final int idx = i;
            boolean enabled = idx != 0 || !undo.isEmpty();
            if (idx == 1) enabled = !redo.isEmpty();
            int before = buttons.size();
            button(g, x, y, w, BTN_H, row2[i], false, enabled, idx == 2 && linkMode, t, () -> {
                switch (idx) {
                    case 0 -> doUndo();
                    case 1 -> doRedo();
                    case 2 -> toggleLink();
                    default -> {
                        if (selected != null) Modules.ungroup(selected);
                    }
                }
            });
            Btn made = buttons.size() > before ? buttons.get(before) : null;
            if (idx == 0) undoBtn = made;
            if (idx == 1) redoBtn = made;
            x += w + BTN_GAP;
        }
    }

    /** Settings of the selected element: size, background, opacity, colour, fine movement, reset. */
    private void drawProps(GuiGraphicsExtractor g, Font font, float t) {
        Module m = selected;
        Modules.Opts o = Modules.opts(m);
        int pw = Math.min(width - 8, 312);
        int px = (width - pw) / 2;
        int py = height - PROPS_H - 8;

        Gfx.roundRect(g, px, py, pw, PROPS_H, 6, Gfx.mulAlpha(0xF20B0B0D, t));
        Gfx.roundOutline(g, px, py, pw, PROPS_H, 6, Gfx.mulAlpha(Style.EDGE, t));

        // row 1
        int y1 = py + 6;
        int x = px + 8;
        Gfx.text(g, font, m.title, x, y1 + 4, Gfx.mulAlpha(Style.WHITE, t));
        x += Gfx.width(font, m.title) + 10;

        button(g, x, y1, 14, BTN_H, "-", false, true, false, t, () -> {
            o.scale = Math.max(0.5f, Math.round((o.scale - 0.1f) * 10f) / 10f);
            Modules.save();
        });
        String sc = String.format("%.1fx", o.scale);
        Gfx.text(g, font, sc, x + 14 + 4, y1 + 5, Gfx.mulAlpha(Style.TEXT, t));
        x += 14 + 4 + Gfx.width(font, "2.5x") + 4;
        button(g, x, y1, 14, BTN_H, "+", false, true, false, t, () -> {
            o.scale = Math.min(2.5f, Math.round((o.scale + 0.1f) * 10f) / 10f);
            Modules.save();
        });
        x += 14 + 8;

        button(g, x, y1, bw("BG ON"), BTN_H, o.bg ? "BG ON" : "BG OFF", false, true, o.bg, t, () -> {
            o.bg = !o.bg;
            Modules.save();
        });
        x += bw("BG OFF") + 6;

        final float cur = o.opacity >= 0f ? o.opacity : Modules.opacity();
        button(g, x, y1, 14, BTN_H, "-", false, true, false, t, () -> {
            o.opacity = Math.max(0.1f, Math.round((cur - 0.1f) * 10f) / 10f);
            Modules.save();
        });
        String op = o.opacity >= 0f ? Math.round(o.opacity * 100f) + "%" : "auto";
        int opW = Gfx.width(font, "100%") + 4;
        int opX = x + 14 + 2;
        Gfx.text(g, font, op, opX, y1 + 5, Gfx.mulAlpha(o.opacity >= 0f ? Style.TEXT : Style.DIM, t));
        buttons.add(new Btn(opX, y1, opW, BTN_H, () -> {
            o.opacity = -1f; // back to the global opacity
            Modules.save();
        }));
        x += 14 + 2 + opW + 2;
        button(g, x, y1, 14, BTN_H, "+", false, true, false, t, () -> {
            o.opacity = Math.min(1f, Math.round((cur + 0.1f) * 10f) / 10f);
            Modules.save();
        });

        // row 2
        int y2 = py + 30;
        x = px + 8;
        Gfx.text(g, font, "Color", x, y2 + 5, Gfx.mulAlpha(Style.DIM, t));
        x += Gfx.width(font, "Color") + 6;
        // "theme" swatch (follow the global accent) + the presets
        for (int i = -1; i < Modules.ACCENT_COLORS.length; i++) {
            final int idx = i;
            int col = i < 0 ? Modules.accent() : Modules.ACCENT_COLORS[i];
            boolean on = i < 0 ? o.accent == 0 : o.accent == Modules.ACCENT_COLORS[i];
            Gfx.roundRect(g, x, y2 + 1, 12, 12, 3, Gfx.mulAlpha(col, t));
            if (i < 0) Gfx.text(g, font, "T", x + 3, y2 + 3, Gfx.mulAlpha(0xFF0B0B0D, t));
            if (on) Gfx.roundOutline(g, x - 2, y2 - 1, 16, 16, 4, Gfx.mulAlpha(Style.WHITE, t));
            buttons.add(new Btn(x - 1, y2, 14, 14, () -> {
                o.accent = idx < 0 ? 0 : Modules.ACCENT_COLORS[idx];
                Modules.save();
            }));
            x += 16;
        }
        x += 6;
        Gfx.text(g, font, "Move", x, y2 + 5, Gfx.mulAlpha(Style.DIM, t));
        x += Gfx.width(font, "Move") + 6;
        String[] arrows = {"<", ">", "^", "v"};
        int[][] d = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        for (int i = 0; i < 4; i++) {
            final int[] dd = d[i];
            button(g, x, y2, 14, BTN_H, arrows[i], false, true, false, t, () -> nudge(dd[0], dd[1]));
            x += 16;
        }
        x += 6;
        button(g, x, y2, bw("Reset"), BTN_H, "Reset", false, true, false, t, () -> Modules.resetModule(m));

        // row 3: this element's own gradient
        int y3 = py + 52;
        x = px + 8;
        String gl = "Gradient: " + (o.grad == 0 ? "theme" : o.grad == 1 ? "on" : "off");
        button(g, x, y3, bw(gl) + 8, BTN_H, gl, false, true, o.grad == 1, t, () -> {
            o.grad = (o.grad + 1) % 3;
            Modules.save();
        });
        x += bw(gl) + 8 + 10;
        Gfx.text(g, font, "2nd colour", x, y3 + 5, Gfx.mulAlpha(Style.DIM, t));
        x += Gfx.width(font, "2nd colour") + 6;
        for (int i = -1; i < Modules.ACCENT_COLORS.length; i++) {
            final int idx = i;
            int col = i < 0 ? Modules.accent2() : Modules.ACCENT_COLORS[i];
            boolean on = i < 0 ? o.accent2 == 0 : o.accent2 == Modules.ACCENT_COLORS[i];
            Gfx.roundRect(g, x, y3 + 1, 12, 12, 3, Gfx.mulAlpha(col, t));
            if (i < 0) Gfx.text(g, font, "T", x + 3, y3 + 3, Gfx.mulAlpha(0xFF0B0B0D, t));
            if (on) Gfx.roundOutline(g, x - 2, y3 - 1, 16, 16, 4, Gfx.mulAlpha(Style.WHITE, t));
            buttons.add(new Btn(x - 1, y3, 14, 14, () -> {
                o.accent2 = idx < 0 ? 0 : Modules.ACCENT_COLORS[idx];
                if (o.grad == 0 && idx >= 0) o.grad = 1;
                Modules.save();
            }));
            x += 16;
        }
    }

    // ---------- snapping ----------

    /** Finds the nearest snap target for one axis (top-left coordinate v of something `size` long). */
    private static final class Snap {
        final float v;
        float best = SNAP + 0.001f;
        float out;
        float line = -1f;

        Snap(float v) {
            this.v = v;
            this.out = v;
        }

        void target(float target, float lineAt) {
            float d = Math.abs(v - target);
            if (d < best) {
                best = d;
                out = target;
                line = lineAt;
            }
        }
    }

    // ---------- input ----------

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        moved = false;
        pressedBtn = null;
        resizing = false;
        for (int i = buttons.size() - 1; i >= 0; i--) {
            Btn b = buttons.get(i);
            if (b.hit(lastMouseX, lastMouseY)) {
                pressedBtn = b;
                if (b != undoBtn && b != redoBtn) pushUndo();
                return true;
            }
        }
        if (selected != null && !linkMode) {
            Placed sp = placedOf(selected);
            if (sp != null && lastMouseX >= sp.x + sp.ew() - 5 && lastMouseX <= sp.x + sp.ew() + 6
                    && lastMouseY >= sp.y + sp.eh() - 5 && lastMouseY <= sp.y + sp.eh() + 6) {
                pushUndo();
                resizing = true;
                resizeStartX = lastMouseX;
                resizeStartScale = Modules.opts(selected).scale;
                return true;
            }
        }
        for (int i = placed.size() - 1; i >= 0; i--) {
            Placed p = placed.get(i);
            if (p.contains(lastMouseX, lastMouseY)) {
                Module pm = p.widget.module;
                if (linkMode) {
                    if (!linkSel.remove(pm)) linkSel.add(pm);
                    return true;
                }
                pushUndo();
                dragging = pm;
                selected = dragging;
                dragX = p.x;
                dragY = p.y;
                lastFx = p.x;
                lastFy = p.y;
                return true;
            }
        }
        selected = null;
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = InputConstants.getKey(event).getValue();
        if (key == GLFW.GLFW_KEY_Z) { doUndo(); return true; }
        if (key == GLFW.GLFW_KEY_Y) { doRedo(); return true; }
        if (selected != null) {
            if (key == GLFW.GLFW_KEY_LEFT) { nudge(-1, 0); return true; }
            if (key == GLFW.GLFW_KEY_RIGHT) { nudge(1, 0); return true; }
            if (key == GLFW.GLFW_KEY_UP) { nudge(0, -1); return true; }
            if (key == GLFW.GLFW_KEY_DOWN) { nudge(0, 1); return true; }
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double deltaX, double deltaY) {
        if (resizing && selected != null) {
            Placed rp = placedOf(selected);
            if (rp != null) {
                float base = Math.max(20f, rp.widget.w);
                float ns = resizeStartScale + (lastMouseX - resizeStartX) / base;
                Modules.opts(selected).scale = Math.max(0.5f, Math.min(2.5f, Math.round(ns * 20f) / 20f));
            }
            return true;
        }
        if (dragging == null) return true;
        Placed me = placedOf(dragging);
        if (me == null) return true;

        dragX += (float) deltaX;
        dragY += (float) deltaY;
        moved = true;

        int w = me.ew();
        int h = me.eh();
        float nx = Math.max(0f, Math.min(Math.max(0, width - w), dragX));
        float ny = Math.max(0f, Math.min(Math.max(0, height - h), dragY));

        Snap sx = new Snap(nx);
        sx.target(HudRenderer.MARGIN, -1f);
        sx.target((width - w) / 2f, width / 2f);
        sx.target(width - w - HudRenderer.MARGIN, -1f);

        Snap sy = new Snap(ny);
        sy.target(HudRenderer.MARGIN, -1f);
        sy.target((height - h) / 2f, height / 2f);
        sy.target(height - h - HudRenderer.MARGIN, -1f);

        for (Placed o : placed) {
            if (o.widget.module == dragging) continue;
            int ow = o.ew();
            int oh = o.eh();
            sx.target(o.x, o.x);
            sx.target(o.x + ow - w, o.x + ow);
            sx.target(o.x + (ow - w) / 2f, o.x + ow / 2f);
            sx.target(o.x + ow + HudRenderer.GAP, -1f);
            sx.target(o.x - w - HudRenderer.GAP, -1f);

            sy.target(o.y, o.y);
            sy.target(o.y + oh - h, o.y + oh);
            sy.target(o.y + (oh - h) / 2f, o.y + oh / 2f);
            sy.target(o.y + oh + HudRenderer.GAP, -1f);
            sy.target(o.y - h - HudRenderer.GAP, -1f);
        }
        guideX = sx.line;
        guideY = sy.line;

        float fx = Math.max(0f, Math.min(Math.max(0, width - w), sx.out));
        float fy = Math.max(0f, Math.min(Math.max(0, height - h), sy.out));
        Modules.setPos(dragging, fx / width, fy / height);

        // widgets grouped with this one move by the same amount
        float ddx = fx - lastFx;
        float ddy = fy - lastFy;
        lastFx = fx;
        lastFy = fy;
        for (Module gm : Modules.groupOf(dragging)) {
            if (gm == dragging) continue;
            Placed gp = placedOf(gm);
            if (gp == null) continue;
            float[] cur = Modules.pos(gm);
            float cx = cur != null ? cur[0] * width : gp.x;
            float cy = cur != null ? cur[1] * height : gp.y;
            cx = Math.max(0f, Math.min(Math.max(0, width - gp.ew()), cx + ddx));
            cy = Math.max(0f, Math.min(Math.max(0, height - gp.eh()), cy + ddy));
            Modules.setPos(gm, cx / width, cy / height);
        }
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (pressedBtn != null) {
            Btn b = pressedBtn;
            pressedBtn = null;
            if (b.hit(lastMouseX, lastMouseY)) b.action().run();
            return true;
        }
        if (resizing) {
            resizing = false;
            Modules.save();
            return true;
        }
        if (dragging != null) {
            dragging = null;
            guideX = -1f;
            guideY = -1f;
            if (moved) Modules.save();
        }
        return true;
    }
}
