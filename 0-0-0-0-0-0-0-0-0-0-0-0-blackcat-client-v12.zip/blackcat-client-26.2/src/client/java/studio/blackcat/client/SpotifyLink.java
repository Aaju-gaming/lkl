package studio.blackcat.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
 * Links your own Spotify account (with your own free Spotify developer app) so the client can see what
 * you are playing and show synced lyrics. Spotify does not allow other programs to stream its audio, so the
 * music keeps playing in the Spotify app; the client only reads the "currently playing" information.
 * Sign-in uses PKCE (no secret is stored) and the refresh token is kept in config/blackcat/spotify.json.
 */
public final class SpotifyLink {
    private SpotifyLink() {}

    public static final String REDIRECT = "http://127.0.0.1:8888/callback";
    private static final String SCOPE = "user-read-currently-playing user-read-playback-state";
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
    private static final SecureRandom RNG = new SecureRandom();

    private static volatile String status = "Not linked";
    private static volatile String loginUrl = "";
    private static volatile String refresh = "";
    private static String access = "";
    private static long accessExp;
    private static String clientId = "";
    private static volatile boolean pollerRunning;
    private static volatile int loginGen;

    public static String status() { return status; }
    public static String loginUrl() { return loginUrl; }
    public static boolean linked() { return !refresh.isEmpty(); }

    private static Path file() {
        return Modules.dir("").resolve("spotify.json");
    }

    /** Called once at start-up: picks up a saved link and starts following Spotify. */
    public static void load() {
        try {
            Path f = file();
            if (Files.isRegularFile(f)) {
                JsonObject o = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
                refresh = o.has("refresh") ? o.get("refresh").getAsString() : "";
                clientId = o.has("client") ? o.get("client").getAsString() : "";
                if (!refresh.isEmpty() && !clientId.isEmpty()) {
                    status = "Linked";
                    startPoller();
                } else {
                    refresh = "";
                }
            }
        } catch (Throwable t) {
            Modules.logError("spotify", t);
        }
    }

    private static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("refresh", refresh);
            o.addProperty("client", clientId);
            Files.writeString(file(), o.toString());
        } catch (Throwable t) {
            Modules.logError("spotify", t);
        }
    }

    public static void unlink() {
        loginGen++;
        refresh = "";
        access = "";
        pollerRunning = false;
        try {
            Files.deleteIfExists(file());
        } catch (IOException ignored) {
            // ignore
        }
        status = "Not linked";
        Music.onSpotifyIdle();
    }

    // ---------- PKCE helpers (pure, tested) ----------

    static String b64url(byte[] b) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(b);
    }

    static String challenge(String verifier) throws Exception {
        return b64url(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));
    }

    static String randomToken(int bytes) {
        byte[] b = new byte[bytes];
        RNG.nextBytes(b);
        return b64url(b);
    }

    /** Parses the query part of "GET /callback?code=..&state=.. HTTP/1.1". */
    static Map<String, String> parseRequestLine(String line) {
        Map<String, String> out = new HashMap<>();
        if (line == null) return out;
        int q = line.indexOf('?');
        int sp = line.lastIndexOf(" HTTP");
        if (q < 0 || sp < q) return out;
        for (String kv : line.substring(q + 1, sp).split("&")) {
            int eq = kv.indexOf('=');
            if (eq > 0) out.put(kv.substring(0, eq), URLDecoder.decode(kv.substring(eq + 1), StandardCharsets.UTF_8));
        }
        return out;
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    // ---------- sign-in ----------

    /** Starts the browser sign-in. clientIdIn is the Client ID of the user's own Spotify developer app. */
    public static void startLogin(String clientIdIn) {
        String id = clientIdIn == null ? "" : clientIdIn.trim();
        if (id.length() < 10) {
            status = "Paste your Spotify Client ID first";
            return;
        }
        final int gen = ++loginGen;
        clientId = id;
        final String verifier = randomToken(48);
        final String state = randomToken(12);
        try {
            loginUrl = "https://accounts.spotify.com/authorize?response_type=code&client_id=" + enc(id)
                    + "&scope=" + enc(SCOPE) + "&redirect_uri=" + enc(REDIRECT) + "&state=" + enc(state)
                    + "&code_challenge_method=S256&code_challenge=" + challenge(verifier);
        } catch (Exception e) {
            status = "Could not start sign-in";
            return;
        }
        status = "Waiting for you to approve in the browser...";
        Thread t = new Thread(() -> waitForCallback(gen, verifier, state), "blackcat-spotify-login");
        t.setDaemon(true);
        t.start();
        if (!openUrl(loginUrl)) status = "Open the link yourself (use Copy link), then approve";
    }

    private static void waitForCallback(int gen, String verifier, String state) {
        try (ServerSocket server = new ServerSocket(8888, 1, InetAddress.getByName("127.0.0.1"))) {
            server.setSoTimeout(240_000);
            while (gen == loginGen) {
                try (Socket s = server.accept()) {
                    s.setSoTimeout(5000);
                    BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.US_ASCII));
                    String line = in.readLine();
                    Map<String, String> q = parseRequestLine(line);
                    boolean ok = q.containsKey("code") && state.equals(q.get("state"));
                    String html = ok ? "<h2>Linked to Black Cat Client</h2><p>You can close this tab and go back to Minecraft.</p>"
                            : "<h2>Not linked</h2><p>Nothing to do here.</p>";
                    byte[] body = ("<html><body style='font-family:sans-serif;background:#0b0b0d;color:#eee;text-align:center;padding-top:80px'>"
                            + html + "</body></html>").getBytes(StandardCharsets.UTF_8);
                    OutputStream out = s.getOutputStream();
                    out.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + body.length
                            + "\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
                    out.write(body);
                    out.flush();
                    if (ok) {
                        exchange(q.get("code"), verifier);
                        return;
                    }
                }
            }
        } catch (java.net.BindException e) {
            if (gen == loginGen) status = "Port 8888 is busy; close other programs using it and try again";
        } catch (java.net.SocketTimeoutException e) {
            if (gen == loginGen) status = "Sign-in timed out. Try Link again";
        } catch (Throwable e) {
            if (gen == loginGen) status = "Sign-in failed";
            Modules.logError("spotify", e);
        }
    }

    private static void exchange(String code, String verifier) {
        try {
            String body = "grant_type=authorization_code&code=" + enc(code) + "&redirect_uri=" + enc(REDIRECT)
                    + "&client_id=" + enc(clientId) + "&code_verifier=" + enc(verifier);
            JsonObject o = tokenRequest(body);
            if (o == null || !o.has("refresh_token")) {
                status = "Spotify refused the sign-in (check the Client ID and redirect link)";
                return;
            }
            refresh = o.get("refresh_token").getAsString();
            access = o.get("access_token").getAsString();
            accessExp = System.currentTimeMillis() + o.get("expires_in").getAsLong() * 1000 - 30_000;
            save();
            status = "Linked";
            startPoller();
        } catch (Throwable t) {
            status = "Sign-in failed";
            Modules.logError("spotify", t);
        }
    }

    private static JsonObject tokenRequest(String form) throws Exception {
        HttpRequest r = HttpRequest.newBuilder(URI.create("https://accounts.spotify.com/api/token"))
                .timeout(Duration.ofSeconds(15))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(form)).build();
        HttpResponse<String> resp = HTTP.send(r, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) return null;
        return JsonParser.parseString(resp.body()).getAsJsonObject();
    }

    private static boolean ensureAccess() {
        if (!access.isEmpty() && System.currentTimeMillis() < accessExp) return true;
        try {
            JsonObject o = tokenRequest("grant_type=refresh_token&refresh_token=" + enc(refresh) + "&client_id=" + enc(clientId));
            if (o == null) {
                status = "Link expired. Press Link again";
                return false;
            }
            access = o.get("access_token").getAsString();
            accessExp = System.currentTimeMillis() + o.get("expires_in").getAsLong() * 1000 - 30_000;
            if (o.has("refresh_token")) {
                refresh = o.get("refresh_token").getAsString();
                save();
            }
            return true;
        } catch (Throwable t) {
            status = "Linked (offline?)";
            return false;
        }
    }

    // ---------- following what is playing ----------

    private static void startPoller() {
        if (pollerRunning) return;
        pollerRunning = true;
        Thread t = new Thread(() -> {
            long sleep = 2500;
            while (pollerRunning && linked()) {
                try {
                    if (Modules.text("spotify_on").equals("off") || !Music.spotifyMayDrive()) {
                        Thread.sleep(2500);
                        continue;
                    }
                    if (ensureAccess()) {
                        HttpResponse<String> r = HTTP.send(HttpRequest.newBuilder(
                                        URI.create("https://api.spotify.com/v1/me/player/currently-playing?additional_types=track"))
                                .timeout(Duration.ofSeconds(10))
                                .header("Authorization", "Bearer " + access).GET().build(), HttpResponse.BodyHandlers.ofString());
                        sleep = 2500;
                        int code = r.statusCode();
                        if (code == 204) {
                            Music.onSpotifyIdle();
                            status = "Linked - nothing playing";
                        } else if (code == 200) {
                            handle(r.body());
                        } else if (code == 401) {
                            access = "";
                        } else if (code == 429) {
                            sleep = r.headers().firstValueAsLong("Retry-After").orElse(5) * 1000 + 500;
                        } else if (code == 403) {
                            status = "Spotify needs the account added to your app (User Management)";
                        }
                    }
                    Thread.sleep(sleep);
                } catch (InterruptedException e) {
                    return;
                } catch (Throwable e) {
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException ie) {
                        return;
                    }
                }
            }
            pollerRunning = false;
        }, "blackcat-spotify-poll");
        t.setDaemon(true);
        t.start();
    }

    static void handle(String body) {
        JsonObject o = JsonParser.parseString(body).getAsJsonObject();
        if (!o.has("item") || o.get("item").isJsonNull()) {
            Music.onSpotifyIdle();
            return;
        }
        JsonObject item = o.getAsJsonObject("item");
        String name = item.get("name").getAsString();
        StringBuilder artists = new StringBuilder();
        if (item.has("artists")) {
            JsonArray a = item.getAsJsonArray("artists");
            for (JsonElement el : a) {
                if (artists.length() > 0) artists.append(", ");
                artists.append(el.getAsJsonObject().get("name").getAsString());
            }
        }
        long dur = item.has("duration_ms") ? item.get("duration_ms").getAsLong() : 0;
        long prog = o.has("progress_ms") && !o.get("progress_ms").isJsonNull() ? o.get("progress_ms").getAsLong() : 0;
        boolean playing = o.has("is_playing") && o.get("is_playing").getAsBoolean();
        String firstArtist = artists.toString().split(",")[0].trim();
        Music.onSpotify(firstArtist, name, dur, prog, playing);
        status = "Linked - " + (playing ? "playing" : "paused");
    }

    // ---------- opening the browser ----------

    private static boolean openUrl(String url) {
        try {
            Object platform = Class.forName("net.minecraft.Util").getMethod("getPlatform").invoke(null);
            for (java.lang.reflect.Method m : platform.getClass().getMethods()) {
                if (!m.getName().equals("openUri") || m.getParameterCount() != 1) continue;
                Class<?> p = m.getParameterTypes()[0];
                if (p == String.class) m.invoke(platform, url);
                else if (p == URI.class) m.invoke(platform, URI.create(url));
                else continue;
                return true;
            }
        } catch (Throwable ignored) {
            // try the next way
        }
        try {
            if (java.awt.Desktop.isDesktopSupported() && java.awt.Desktop.getDesktop().isSupported(java.awt.Desktop.Action.BROWSE)) {
                java.awt.Desktop.getDesktop().browse(URI.create(url));
                return true;
            }
        } catch (Throwable ignored) {
            // no browser from here
        }
        return false;
    }

    /** Copies the sign-in link to the clipboard (true if that worked). */
    public static boolean copyLink() {
        if (loginUrl.isEmpty()) return false;
        try {
            net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
            Object kh = net.minecraft.client.Minecraft.class.getField("keyboardHandler").get(mc);
            kh.getClass().getMethod("setClipboard", String.class).invoke(kh, loginUrl);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
