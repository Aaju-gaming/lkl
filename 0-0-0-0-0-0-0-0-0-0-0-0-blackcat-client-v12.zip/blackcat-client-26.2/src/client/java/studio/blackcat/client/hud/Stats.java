package studio.blackcat.client.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayDeque;

/** Session counters used by the combat / movement / utility modules. Updated once per client tick. */
public final class Stats {
    private Stats() {}

    public static int hits;
    public static int combo;
    public static long lastHitMs;
    public static float lastReach;
    public static long hitFlashUntil;
    public static float lastDamage;
    public static long damageUntil;
    public static int jumps;
    public static final long SESSION_START = System.currentTimeMillis();
    public static float speed;                 // blocks per second
    public static final ArrayDeque<Float> SPEED_HIST = new ArrayDeque<>();
    public static long pearlUntil;
    public static float fall;

    private static double px, pz;
    private static boolean havePos;
    private static boolean wasOnGround = true;
    private static boolean wasUse;
    private static int tick;
    private static final float[] lastHp = {0};
    private static int targetId = -1;
    private static float targetHp = -1;

    /** Called from the attack callback with the entity that was just hit. */
    public static void onAttack(Minecraft mc, Entity target) {
        long now = System.currentTimeMillis();
        if (now - lastHitMs > 3000) combo = 0;
        combo++;
        hits++;
        lastHitMs = now;
        hitFlashUntil = now + 250;
        if (mc.player != null) {
            lastReach = (float) Math.sqrt(mc.player.distanceToSqr(target));
        }
        targetId = target.getId();
        targetHp = -1;
    }

    /** Combo resets when you take damage or stop hitting. */
    public static int comboNow() {
        if (System.currentTimeMillis() - lastHitMs > 3000) combo = 0;
        return combo;
    }

    public static void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null) {
            havePos = false;
            return;
        }
        tick++;
        var p = mc.player;
        if (havePos && tick % 2 == 0) {
            double dx = p.getX() - px, dz = p.getZ() - pz;
            speed = (float) (Math.sqrt(dx * dx + dz * dz) * 10.0); // 2 ticks = 0.1s
            px = p.getX();
            pz = p.getZ();
            if (tick % 10 == 0) {
                SPEED_HIST.addLast(speed);
                while (SPEED_HIST.size() > 46) SPEED_HIST.removeFirst();
                HudRenderer.version++;
            }
        } else if (!havePos) {
            px = p.getX();
            pz = p.getZ();
            havePos = true;
        }
        boolean ground = p.onGround();
        if (wasOnGround && !ground && p.getDeltaMovement().y > 0.1) jumps++;
        wasOnGround = ground;
        fall = (float) p.fallDistance;

        boolean use = mc.options.keyUse.isDown();
        if (use && !wasUse && mc.gui.screen() == null && isPearl(p.getMainHandItem()) && System.currentTimeMillis() > pearlUntil) {
            pearlUntil = System.currentTimeMillis() + 1000;
        }
        wasUse = use;
    }

    public static boolean isPearl(ItemStack st) {
        if (st == null || st.isEmpty()) return false;
        return BuiltInRegistries.ITEM.getKey(st.getItem()).getPath().equals("ender_pearl");
    }

    public static void reset() {
        hits = 0;
        combo = 0;
        jumps = 0;
        havePos = false;
    }
}
