package studio.blackcat.client.hud;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.util.Gfx;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

/** The v0.6 widgets: combat, movement, world and utility read-outs. */
final class Extra {
    private Extra() {}

    private static final String[] DIRS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

    static List<HudWidget> widgets() {
        List<HudWidget> l = new ArrayList<>();
        l.add(new Line(Module.PEARL, "Pearl", c -> {
            long left = Stats.pearlUntil - System.currentTimeMillis();
            return left > 0 ? String.format("%.1fs", left / 1000f) : "Ready";
        }, c -> true));
        l.add(new Line(Module.HITS, "Hits", c -> String.valueOf(Stats.hits), c -> true));
        l.add(new Line(Module.COMBO, "Combo", c -> String.valueOf(Stats.comboNow()), c -> true));
        l.add(new Line(Module.REACH, "Reach", c -> Stats.lastReach <= 0 ? "-" : String.format("%.2f", Stats.lastReach), c -> true));
        l.add(new Line(Module.COMBAT_TIMER, "Combat", c -> {
            if (Stats.lastHitMs == 0) return "-";
            return String.format("%.1fs", (System.currentTimeMillis() - Stats.lastHitMs) / 1000f);
        }, c -> true));
        l.add(new Line(Module.POTION_WARN, "Effect", Extra::expiring, c -> c.preview || !expiring(c).isEmpty()));
        l.add(new Line(Module.TOTEM, "Totems", c -> String.valueOf(count(c, "totem_of_undying")), c -> true));
        l.add(new Line(Module.SPEED, "Speed", c -> String.format("%.1f b/s", Stats.speed), c -> true));
        l.add(new Line(Module.JUMPS, "Jumps", c -> String.valueOf(Stats.jumps), c -> true));
        l.add(new Line(Module.SPRINT, "Move", c -> {
            var p = c.mc.player;
            if (p == null) return "-";
            if (p.isShiftKeyDown()) return "Sneaking";
            return p.isSprinting() ? "Sprinting" : "Walking";
        }, c -> true));
        l.add(new Line(Module.FALL, "Fall", c -> String.format("%.1f m", Stats.fall), c -> true));
        l.add(new Line(Module.GROUND, "State", c -> c.mc.player != null && c.mc.player.onGround() ? "Grounded" : "Airborne", c -> true));
        l.add(new Line(Module.ELYTRA, "Elytra", c -> {
            var p = c.mc.player;
            return p == null ? "-" : String.format("%.0f b/s  Y %.0f", Stats.speed, p.getY());
        }, c -> c.preview || (c.mc.player != null && c.mc.player.isFallFlying())));
        l.add(new Line(Module.WEATHER, "Weather", c -> {
            var w = c.mc.level;
            if (w == null) return "-";
            if (w.isThundering()) return "Storm";
            return w.isRaining() ? "Rain" : "Clear";
        }, c -> true));
        l.add(new Line(Module.TIME, "Time", c -> {
            if (c.mc.level == null) return "-";
            long t = (c.mc.level.getGameTime() + 6000) % 24000; // 0 ticks = 6:00
            return String.format("%02d:%02d", t / 1000, (t % 1000) * 60 / 1000);
        }, c -> true));
        l.add(new Line(Module.WORLD_INFO, "World", c -> {
            var w = c.mc.level;
            return w == null ? "-" : w.dimension().identifier().getPath();
        }, c -> true));
        l.add(new Line(Module.SERVER, "Server", c -> {
            var s = c.mc.getCurrentServer();
            return s == null ? "Singleplayer" : s.ip;
        }, c -> true));
        l.add(new Line(Module.SESSION, "Session", c -> {
            long sec = (System.currentTimeMillis() - Stats.SESSION_START) / 1000;
            return String.format("%dm %02ds  %d hits  %d jumps", sec / 60, sec % 60, Stats.hits, Stats.jumps);
        }, c -> true));
        l.add(new Line(Module.ITEM_COUNT, "Count", c -> {
            var p = c.mc.player;
            if (p == null || p.getMainHandItem().isEmpty()) return "-";
            return String.valueOf(countLike(c, p.getMainHandItem()));
        }, c -> true));
        l.add(new Line(Module.DURABILITY_WARN, "Gear", Extra::lowGear, c -> c.preview || !lowGear(c).isEmpty()));
        l.add(new Line(Module.WAYPOINT, "Waypoint", c -> {
            var p = c.mc.player;
            if (p == null) return "-";
            double dx = Modules.textNum("wp_x", 0) - p.getX();
            double dz = Modules.textNum("wp_z", 0) - p.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            double ang = Math.toDegrees(Math.atan2(-dx, dz)); // yaw that faces the waypoint
            double rel = Mth.wrapDegrees(ang - p.getYRot());
            int idx = Math.floorMod((int) Math.round(rel / 45.0), 8);
            String[] arrows = {"^", "^>", ">", "v>", "v", "<v", "<", "<^"};
            return String.format("%.0f m %s", dist, arrows[idx]);
        }, c -> true));
        l.add(new Notify.Toasts());
        l.add(new Notify.Companion());
        l.add(new Notify.Dashboard());
        l.add(new MusicWidget());
        l.add(new BigLyrics());
        l.add(new MotionGraph());
        l.add(new InvPreview());
        return l;
    }

    // ---------- helpers ----------

    private static String expiring(HudCtx c) {
        if (c.mc.player == null) return c.preview ? "Speed 0:08" : "";
        for (MobEffectInstance e : c.mc.player.getActiveEffects()) {
            if (!e.isInfiniteDuration() && e.getDuration() <= 200) {
                int s = (e.getDuration() + 19) / 20;
                return effectName(e) + " " + s + "s";
            }
        }
        return c.preview ? "Speed 0:08" : "";
    }

    private static String effectName(MobEffectInstance e) {
        String raw = e.getEffect().unwrapKey().map(k -> k.identifier().getPath()).orElse("effect");
        StringBuilder sb = new StringBuilder();
        for (String part : raw.split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    static int count(HudCtx c, String itemPath) {
        var p = c.mc.player;
        if (p == null) return 0;
        int n = 0;
        var inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack st = inv.getItem(i);
            if (!st.isEmpty() && BuiltInRegistries.ITEM.getKey(st.getItem()).getPath().equals(itemPath)) n += st.getCount();
        }
        ItemStack off = p.getOffhandItem();
        if (!off.isEmpty() && BuiltInRegistries.ITEM.getKey(off.getItem()).getPath().equals(itemPath) && !inInv(inv, off)) n += off.getCount();
        return n;
    }

    private static boolean inInv(net.minecraft.world.entity.player.Inventory inv, ItemStack st) {
        for (int i = 0; i < inv.getContainerSize(); i++) if (inv.getItem(i) == st) return true;
        return false;
    }

    static int countLike(HudCtx c, ItemStack like) {
        var p = c.mc.player;
        if (p == null) return 0;
        int n = 0;
        var inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack st = inv.getItem(i);
            if (ItemStack.isSameItem(st, like)) n += st.getCount();
        }
        return n;
    }

    private static final EquipmentSlot[] GEAR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND};

    /** Name of the first piece of gear below the configured durability percentage ("" if none). */
    static String lowGear(HudCtx c) {
        if (c.mc.player == null) return c.preview ? "Chestplate 8%" : "";
        double pct = Modules.textNum("durability_pct", 10);
        for (EquipmentSlot s : GEAR) {
            ItemStack st = c.mc.player.getItemBySlot(s);
            if (st.isEmpty() || st.getMaxDamage() <= 0) continue;
            double left = (st.getMaxDamage() - st.getDamageValue()) * 100.0 / st.getMaxDamage();
            if (left <= pct) return st.getHoverName().getString() + " " + Math.round(left) + "%";
        }
        return c.preview ? "Chestplate 8%" : "";
    }

    // ---------- widgets ----------

    /** A label + value pill. */
    static final class Line extends HudWidget {
        private final String label;
        private final Function<HudCtx, String> value;
        private final java.util.function.Predicate<HudCtx> show;
        private String text = "";

        Line(Module m, String label, Function<HudCtx, String> value, java.util.function.Predicate<HudCtx> show) {
            super(m);
            this.label = label;
            this.value = value;
            this.show = show;
        }

        private long nextUpdate;
        private long shrinkAt;
        private boolean shown;

        @Override
        public void layout(HudCtx c) {
            long now = System.currentTimeMillis();
            // work the text out 10 times a second, not every frame: no per-frame String.format and
            // no flood of one-off strings in the width cache
            if (now >= nextUpdate) {
                nextUpdate = now + 100;
                shown = show.test(c);
                if (shown) {
                    try {
                        text = value.apply(c);
                    } catch (Throwable t) {
                        text = "?";
                    }
                    int want = Gfx.width(c.font, label) + 6 + Gfx.width(c.font, text) + 14;
                    // grow at once, shrink slowly, so the pill (and everything stacked under it) doesn't twitch
                    if (want >= w) {
                        w = want;
                        shrinkAt = now + 2000;
                    } else if (now >= shrinkAt) {
                        w = want;
                        shrinkAt = now + 2000;
                    }
                }
            }
            visible = shown;
            h = 16;
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            Widgets.panel(g, x, y, w, h);
            Gfx.text(g, c.font, label, x + 7, y + 4, Style.DIM);
            Gfx.text(g, c.font, text, x + 7 + Gfx.width(c.font, label) + 6, y + 4, Style.WHITE);
        }
    }

    static final class MotionGraph extends HudWidget {
        MotionGraph() {
            super(Module.MOTION);
        }

        @Override
        public void layout(HudCtx c) {
            w = 110;
            h = 38;
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            Widgets.panel(g, x, y, w, h);
            Gfx.text(g, c.font, "Motion", x + 7, y + 4, Style.DIM);
            String v = String.format("%.1f b/s", Stats.speed);
            Gfx.text(g, c.font, v, x + w - 7 - Gfx.width(c.font, v), y + 4, Style.WHITE);
            int bx = x + 7, by = y + h - 5, bh = 16;
            float max = 8f;
            for (float f : Stats.SPEED_HIST) max = Math.max(max, f);
            int i = 0;
            int n = Stats.SPEED_HIST.size();
            int start = Math.max(0, 46 - n);
            for (float f : Stats.SPEED_HIST) {
                int bar = Math.max(1, Math.round(Mth.clamp(f / max, 0f, 1f) * bh));
                int px = bx + (start + i) * 2;
                g.fill(px, by - bar, px + 1, by, Gfx.mulAlpha(Style.accentAt((start + i) / 46f), 0.9f));
                i++;
            }
        }
    }

    static final class InvPreview extends HudWidget {
        InvPreview() {
            super(Module.INV_PREVIEW);
        }

        @Override
        public void layout(HudCtx c) {
            w = 9 * 18 + 8;
            h = 26;
        }

        @Override
        public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
            Widgets.panel(g, x, y, w, h);
            var p = c.mc.player;
            if (p == null) return;
            var inv = p.getInventory();
            for (int i = 0; i < 9; i++) {
                ItemStack st = inv.getItem(i);
                if (st.isEmpty()) continue;
                Gfx.item(g, st, x + 4 + i * 18, y + 5);
            }
        }
    }
}
