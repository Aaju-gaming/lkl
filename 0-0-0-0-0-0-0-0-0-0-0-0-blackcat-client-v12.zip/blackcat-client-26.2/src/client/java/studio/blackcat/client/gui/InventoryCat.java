package studio.blackcat.client.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import studio.blackcat.client.hud.Style;
import studio.blackcat.client.util.Cat;
import studio.blackcat.client.util.Gfx;

/**
 * The Black Cat logo badge on the top edge of the survival inventory (the cat blinks).
 * Tap/click it to open the Black Cat menu (handy on Pojav, where there is no Left Shift key).
 */
public final class InventoryCat {
    private InventoryCat() {}

    // vanilla survival inventory window size
    private static final int PANEL_W = 176;
    private static final int PANEL_H = 166;

    private static int badgeX;
    private static int badgeY;
    private static int badgeW;
    private static int badgeH;
    private static float badgeScale = 1f;
    private static int mouseX = -1;
    private static int mouseY = -1;

    public static void render(GuiGraphicsExtractor g, Font font, int screenW, int screenH, int mx, int my) {
        mouseX = mx;
        mouseY = my;

        int panelX = (screenW - PANEL_W) / 2;
        int panelY = (screenH - PANEL_H) / 2;

        // shrink a little if the screen is short, so the badge still fits above the window
        float room = panelY - 5f;
        badgeScale = Math.max(0.6f, Math.min(1f, room / LogoBadge.H));
        badgeW = Math.round(LogoBadge.W * badgeScale);
        badgeH = Math.round(LogoBadge.H * badgeScale);
        badgeX = panelX + PANEL_W - badgeW;
        badgeY = Math.max(2, panelY - badgeH - 3);

        boolean hover = hit();
        int y = badgeY - (hover ? 2 : 0);
        LogoBadge.draw(g, badgeX, y, badgeScale, Cat.time());
        if (hover) {
            Gfx.roundOutline(g, badgeX, y, badgeW, badgeH, 6, Style.accent());
            String hint = "Open menu";
            Gfx.text(g, font, hint, badgeX - Gfx.width(font, hint) - 6, y + badgeH / 2 - 4, Style.WHITE);
        }
    }

    /** True if the last known pointer position is over the badge. */
    public static boolean hit() {
        return mouseX >= badgeX && mouseX < badgeX + badgeW && mouseY >= badgeY - 2 && mouseY < badgeY + badgeH;
    }
}
