package studio.blackcat.client.hud;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.util.Mth;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.Music;
import studio.blackcat.client.util.Gfx;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Big on-screen lyrics: the current line is shown word by word as it is sung, each word in its own
 * colour and gently bobbing, with a dark outline so it reads over any scene. No panel behind it.
 */
final class BigLyrics extends HudWidget {
    private final List<String> words = new ArrayList<>();
    private final List<int[]> placed = new ArrayList<>(); // x, y (unscaled) per word
    private float scale = 2f;
    private float progress;
    private String nextLine = "";
    private String lastLine = null;
    private int lineCount = 1;

    BigLyrics() {
        super(Module.LYRICS);
    }

    @Override
    public void layout(HudCtx c) {
        scale = (float) Mth.clamp(Modules.textNum("lyr_scale", 2), 1, 4);
        String cur;
        Music.Status st = Music.status();
        if (c.preview && st != Music.Status.SYNCED) {
            cur = "And fallin' one cloud at a time";
            progress = 0.65f;
            nextLine = "around you";
        } else if (st == Music.Status.SYNCED) {
            long pos = Music.positionMs();
            int idx = Music.indexAt(pos);
            List<Music.Line> lines = Music.lines();
            if (idx < 0 || lines.get(idx).text().isEmpty()) {
                visible = false;
                return;
            }
            cur = lines.get(idx).text();
            long start = lines.get(idx).timeMs();
            long end = idx + 1 < lines.size() ? lines.get(idx + 1).timeMs() : start + 4000;
            long span = Math.max(600, Math.min(end - start, 6000)); // long gaps do not stretch the reveal
            progress = Mth.clamp((pos - start) / (float) span * 1.25f, 0f, 1f);
            nextLine = idx + 1 < lines.size() ? lines.get(idx + 1).text() : "";
        } else {
            visible = false;
            return;
        }
        visible = true;

        int maxW = Math.max(120, Math.min((int) (HudRenderer.screenW * 0.78f), 520));
        int unscaledMax = Math.round(maxW / scale);
        if (!cur.equals(lastLine)) {
            lastLine = cur;
            words.clear();
            for (String wd : cur.trim().split("\\s+")) if (!wd.isEmpty()) words.add(wd);
        }
        placed.clear();
        int x = 0, y = 0, lineW = 0, lines = 1, space = Gfx.width(c.font, " ");
        List<int[]> row = new ArrayList<>();
        int rowStart = 0;
        for (int i = 0; i < words.size(); i++) {
            int ww = Gfx.width(c.font, words.get(i));
            if (x > 0 && x + ww > unscaledMax) {
                centerRow(row, x - space, unscaledMax);
                row.clear();
                x = 0;
                y += 11;
                lines++;
            }
            int[] p = {x, y};
            placed.add(p);
            row.add(p);
            x += ww + space;
            lineW = Math.max(lineW, x - space);
        }
        centerRow(row, x - space, unscaledMax);
        lineCount = lines;
        w = maxW;
        h = Math.round((lines * 11 + 14) * scale);
    }

    private void centerRow(List<int[]> row, int rowW, int maxW) {
        int off = Math.max(0, (maxW - rowW) / 2);
        for (int[] p : row) p[0] += off;
    }

    @Override
    public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
        String mode = Modules.text("lyr_style");
        int n = words.size();
        for (int i = 0; i < n; i++) {
            float need = i / (float) Math.max(1, n);
            float pop = Mth.clamp((progress - need) * n * 0.9f, 0f, 1f); // each word eases in as it is sung
            if (pop <= 0f) continue;
            float e = Gfx.easeOutCubic(pop);
            float bob = (float) Math.sin(c.time * 3.2f + i * 0.9f) * 1.6f;
            int col;
            if (mode.equals("white")) col = 0xFFFFFFFF;
            else if (mode.equals("accent")) col = Style.accentAt(i / (float) Math.max(1, n));
            else col = 0xFF000000 | Color.HSBtoRGB(((i * 0.11f) + c.time * 0.08f) % 1f, 0.55f, 1f);
            int[] p = placed.get(i);
            String word = words.get(i);
            float s = scale * (0.85f + 0.15f * e);
            g.pose().pushMatrix();
            g.pose().translate(x + p[0] * scale, y + (p[1] + 2 + bob) * scale);
            g.pose().scale(s, s);
            int shadow = Gfx.mulAlpha(0xFF000000, e * 0.9f);
            Gfx.text(g, c.font, word, 1, 0, shadow);
            Gfx.text(g, c.font, word, -1, 0, shadow);
            Gfx.text(g, c.font, word, 0, 1, shadow);
            Gfx.text(g, c.font, word, 0, -1, shadow);
            Gfx.text(g, c.font, word, 0, 0, Gfx.mulAlpha(col, e));
            g.pose().popMatrix();
        }
        if (!nextLine.isEmpty() && Modules.text("lyr_next").equals("on")) {
            String s = Gfx.fit(c.font, nextLine, Math.round(w / 1.2f));
            g.pose().pushMatrix();
            g.pose().translate(x + (w - Gfx.width(c.font, s) * 1.2f) / 2f, y + (lineCount * 11 + 6) * scale);
            g.pose().scale(1.2f, 1.2f);
            Gfx.text(g, c.font, s, 1, 1, 0x99000000);
            Gfx.text(g, c.font, s, 0, 0, 0xB0FFFFFF);
            g.pose().popMatrix();
        }
    }
}
