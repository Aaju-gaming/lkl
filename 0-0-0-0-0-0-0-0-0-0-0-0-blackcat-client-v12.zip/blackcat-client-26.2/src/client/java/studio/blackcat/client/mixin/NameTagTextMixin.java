package studio.blackcat.client.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;

/**
 * Puts a little cat in front of your own name tag in third person ("=^.^= Name").
 * Switched by Theme > "Cat on name tag". Non-fatal (require = 0): if the method moves, only this stops working.
 */
@Mixin(targets = "net.minecraft.client.renderer.entity.EntityRenderer")
public abstract class NameTagTextMixin {
    @Inject(method = "getNameTag", at = @At("RETURN"), cancellable = true, require = 0)
    private void blackcat$cat(CallbackInfoReturnable<Component> cir) {
        Component tag = cir.getReturnValue();
        Minecraft mc = Minecraft.getInstance();
        if (tag == null || mc.player == null || !Modules.nameBadge() || !Modules.isEnabled(Module.NAME)) return;
        if (tag.getString().equals(mc.player.getName().getString())) {
            cir.setReturnValue(Component.literal("=^.^= ").append(tag));
        }
    }
}
