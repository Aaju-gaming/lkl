package studio.blackcat.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Music;
import studio.blackcat.client.hud.Stats;
import studio.blackcat.client.hud.Style;
import studio.blackcat.client.util.Cat;
import studio.blackcat.client.util.Gfx;

import java.lang.reflect.Constructor;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Cat OS: the Black Cat lobby. It replaces the title screen with a small "operating system":
 * a boot animation, a menu bar with the clock and account, a Play hero, info windows and a dock
 * whose icons grow as the pointer moves over them.
 */
public class CatOsScreen extends Screen {
    /** Set while the plain vanilla title screen is deliberately being shown. */
    public static boolean allowVanilla;
    private static boolean booted;
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");

    public static boolean enabled() {
        return !Modules.text("catos").equals("off");
    }

    private record Hit(int x, int y, int w, int h, Runnable click) {
        boolean contains(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private record DockItem(String glyph, String label, Runnable action) {}

    private final List<Hit> hits = new ArrayList<>();
    private final List<DockItem> dock = new ArrayList<>();
    private float boot = booted ? 1f : 0f;
    private float intro;
    private float time;
    private long lastNanos = System.nanoTime();
    private int mx, my;
    private float alpha = 1f;
    private String message = "";
    private long messageUntil;
    private final float[] dockScale = new float[9];

    public CatOsScreen() {
        super(Component.literal("Cat OS"));
        allowVanilla = false;
        for (int i = 0; i < dockScale.length; i++) dockScale[i] = 1f;
        dock.add(new DockItem("SP", "Singleplayer", () -> openVanilla("Singleplayer",
                "net.minecraft.client.gui.screens.worldselection.SelectWorldScreen")));
        dock.add(new DockItem("MP", "Multiplayer", () -> openVanilla("Multiplayer",
                "net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen")));
        dock.add(new DockItem("CL", "Client hub", () -> go(new HubScreen())));
        dock.add(new DockItem("HUD", "HUD editor", () -> go(new HudEditorScreen())));
        dock.add(new DockItem("MU", "Music", () -> go(new HubScreen())));
        dock.add(new DockItem("?", "Command palette", () -> go(new PaletteScreen())));
        dock.add(new DockItem("OP", "Minecraft options", () -> openVanilla("Options",
                "net.minecraft.client.gui.screens.options.OptionsScreen", "net.minecraft.client.gui.screens.OptionsScreen")));
        dock.add(new DockItem("VA", "Vanilla menu", () -> {
            allowVanilla = true;
            go(new TitleScreen());
        }));
        dock.add(new DockItem("X", "Quit game", () -> {
            if (this.minecraft != null) this.minecraft.stop();
        }));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false; // the lobby is the bottom of the screen stack
    }

    // ---------- opening other screens ----------

    private void go(Screen s) {
        if (this.minecraft != null) this.minecraft.gui.setScreen(s);
    }

    /** Opens a vanilla screen by class name (so a signature change can only show a message, never break the build). */
    private void openVanilla(String what, String... classNames) {
        Minecraft mc = this.minecraft;
        if (mc == null) return;
        for (String cn : classNames) {
            try {
                Class<?> k = Class.forName(cn);
                for (Constructor<?> ct : k.getConstructors()) {
                    Class<?>[] pt = ct.getParameterTypes();
                    Object[] args = new Object[pt.length];
                    boolean ok = pt.length > 0 && pt.length <= 3;
                    for (int i = 0; ok && i < pt.length; i++) {
                        if (pt[i].isAssignableFrom(this.getClass()) && Screen.class.isAssignableFrom(pt[i])) args[i] = this;
                        else if (pt[i].isInstance(mc.options)) args[i] = mc.options;
                        else if (pt[i] == boolean.class) args[i] = Boolean.FALSE;
                        else ok = false;
                    }
                    if (ok && pt[0].isAssignableFrom(this.getClass())) {
                        mc.gui.setScreen((Screen) ct.newInstance(args));
                        return;
                    }
                }
            } catch (Throwable ignored) {
                // try the next name
            }
        }
        say("Couldn't open " + what + ". Use the Vanilla menu icon instead.");
    }

    private void say(String s) {
        message = s;
        messageUntil = System.currentTimeMillis() + 4000;
    }

    // ---------- drawing helpers ----------

    private int c(int col) {
        return Gfx.mulAlpha(col, alpha);
    }

    private boolean over(int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void hit(int x, int y, int w, int h, Runnable r) {
        hits.add(new Hit(x, y, w, h, r));
    }

    private int radius() {
        return (int) Math.max(2, Math.min(10, Modules.textNum("radius", 4)));
    }

    /** A window/card in the current look. */
    private void glass(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        int r = radius() + 2;
        Gfx.roundRectV(g, x, y, w, h, r, c(Style.bgTop()), c(Style.bg()));
        Gfx.roundOutline(g, x, y, w, h, r, c(Style.edge()));
        if (Style.glass() && w > 12) g.fill(x + r, y + 1, x + w - r, y + 2, c(Style.look() == Style.LOOK_LIQUID ? 0x55FFFFFF : 0x30FFFFFF));
    }

    private void text(GuiGraphicsExtractor g, String s, int x, int y, int col) {
        Gfx.text(g, this.font, s, x, y, c(col));
    }

    private void scaledText(GuiGraphicsExtractor g, String s, int x, int y, float sc, int col) {
        g.pose().pushMatrix();
        g.pose().translate((float) x, (float) y);
        g.pose().scale(sc, sc);
        Gfx.text(g, this.font, s, 0, 0, c(col));
        g.pose().popMatrix();
    }

    // ---------- wallpaper ----------

    private void blob(GuiGraphicsExtractor g, float cx, float cy, float radius, int color, float strength) {
        for (int i = 0; i < 9; i++) {
            float f = 1f - i / 9f;
            int r = Math.round(radius * f);
            if (r < 4) break;
            Gfx.roundRect(g, Math.round(cx - r), Math.round(cy - r), r * 2, r * 2, r, Gfx.mulAlpha(color, strength * 0.09f * alpha));
        }
    }

    private void wallpaper(GuiGraphicsExtractor g) {
        String wall = Modules.text("os_wall");
        boolean mono = Style.look() == Style.LOOK_MONO;
        int top = mono ? 0xFF000000 : 0xFF04050A;
        int bot = mono ? 0xFF050505 : 0xFF0C0D14;
        int bands = 24;
        for (int i = 0; i < bands; i++) {
            int y1 = this.height * i / bands;
            int y2 = this.height * (i + 1) / bands;
            g.fill(0, y1, this.width, y2, Gfx.lerpColor(top, bot, i / (float) (bands - 1)));
        }
        if (wall.equals("plain")) return;
        if (!mono) {
            int a1 = Style.accent();
            int a2 = Style.accentAt(1f);
            float w = this.width, h = this.height;
            blob(g, w * (0.28f + 0.06f * (float) Math.sin(time * 0.35f)), h * (0.4f + 0.05f * (float) Math.cos(time * 0.3f)), h * 0.75f, a1, 1f);
            blob(g, w * (0.75f + 0.05f * (float) Math.cos(time * 0.28f)), h * (0.62f + 0.06f * (float) Math.sin(time * 0.33f)), h * 0.7f, a2, 0.8f);
        }
        // stars
        for (int i = 0; i < 46; i++) {
            long seed = i * 2654435761L;
            int sx = (int) ((seed >>> 3) % Math.max(1, this.width));
            int sy = (int) ((seed >>> 11) % Math.max(1, this.height - 30));
            float tw = 0.35f + 0.65f * (0.5f + 0.5f * (float) Math.sin(time * (0.8f + (i % 5) * 0.3f) + i));
            g.fill(sx, sy, sx + 1, sy + 1, Gfx.mulAlpha(0xFFFFFFFF, 0.5f * tw * alpha));
        }
    }

    // ---------- frame ----------

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min((now - lastNanos) / 1_000_000_000f, 0.1f);
        lastNanos = now;
        time += dt;
        mx = mouseX;
        my = mouseY;
        hits.clear();

        if (!booted) {
            boot = Math.min(1f, boot + dt / 1.8f);
            if (boot >= 1f) booted = true;
        }
        if (boot > 0.8f) intro = Math.min(1f, intro + dt * 2.2f);
        alpha = Gfx.easeOutCubic(intro);

        if (boot > 0.8f || booted) {
            wallpaper(g);
            menubar(g);
            hero(g);
            cards(g);
            dock(g);
            if (System.currentTimeMillis() < messageUntil) {
                int mw = Gfx.width(this.font, message) + 20;
                glass(g, (this.width - mw) / 2, this.height - 86, mw, 18);
                text(g, message, (this.width - mw) / 2 + 10, this.height - 81, Style.WHITE);
            }
        }
        if (!booted) bootOverlay(g);
    }

    private void bootOverlay(GuiGraphicsExtractor g) {
        float fade = boot > 0.88f ? (1f - boot) / 0.12f : 1f;
        g.fill(0, 0, this.width, this.height, Gfx.mulAlpha(0xFF000000, fade));
        float eyes = Gfx.clamp01((boot - 0.12f) * 3f);
        int size = 70;
        int cx = this.width / 2;
        int cy = this.height / 2 - 24;
        Cat.draw(g, cx - size / 2, cy - Cat.heightFor(size) / 2, size, Math.min(eyes, 1f));
        // fade the cat with the overlay
        int labelCol = Gfx.mulAlpha(0xFFF2F2F5, fade);
        String t = "CAT OS";
        Gfx.spaced(g, this.font, t, cx - Gfx.spacedWidth(this.font, t, 3) / 2, cy + 40, labelCol, 3);
        int bw = 90;
        g.fill(cx - bw / 2, cy + 58, cx + bw / 2, cy + 60, Gfx.mulAlpha(0xFF2A2A30, fade));
        g.fill(cx - bw / 2, cy + 58, cx - bw / 2 + Math.round(bw * Math.min(1f, boot / 0.85f)), cy + 60, Gfx.mulAlpha(Style.accent(), fade));
        Gfx.text(g, this.font, "Black Cat Studios", cx - Gfx.width(this.font, "Black Cat Studios") / 2, cy + 68, Gfx.mulAlpha(0xFF6C6C75, fade));
        hits.clear();
        hit(0, 0, this.width, this.height, () -> {
            boot = 0.9f;
            booted = true;
        });
    }

    private void menubar(GuiGraphicsExtractor g) {
        g.fill(0, 0, this.width, 15, c(0x99000000));
        g.fill(0, 15, this.width, 16, c(0x22FFFFFF));
        Gfx.spaced(g, this.font, "CAT OS", 8, 4, c(Style.accent()), 1);
        text(g, "Lobby", 62, 4, 0xFFC8C8CE);
        String clock = LocalTime.now().format(CLOCK);
        int rx = this.width - 8 - Gfx.width(this.font, clock);
        text(g, clock, rx, 4, Style.WHITE);
        String user = "Player";
        try {
            user = this.minecraft.getUser().getName();
        } catch (Throwable ignored) {
            // keep the fallback
        }
        String prof = Modules.profileName();
        rx -= 14 + Gfx.width(this.font, user);
        text(g, user, rx, 4, 0xFFC8C8CE);
        rx -= 14 + Gfx.width(this.font, prof);
        text(g, prof, rx, 4, Style.DIM);
        String search = "Search";
        rx -= 14 + Gfx.width(this.font, search);
        boolean hov = over(rx - 4, 0, Gfx.width(this.font, search) + 8, 15);
        text(g, search, rx, 4, hov ? Style.WHITE : Style.DIM);
        hit(rx - 4, 0, Gfx.width(this.font, search) + 8, 15, () -> go(new PaletteScreen()));
    }

    private void hero(GuiGraphicsExtractor g) {
        boolean wide = this.width >= 360;
        int areaW = wide ? (int) (this.width * 0.5f) : this.width;
        int x = wide ? Math.max(14, (int) (this.width * 0.07f)) : (this.width - 150) / 2;
        int top = 28 + Math.round((1f - alpha) * 10f);
        int usable = this.height - 28 - 82;
        int catSize = Math.max(56, Math.min(96, usable / 3));
        float bob = (float) Math.sin(time * 1.5f) * 1.5f;
        int cy = top + Math.max(0, (usable - (catSize + 110)) / 2);
        Cat.draw(g, x, cy + Math.round(bob), catSize, Cat.blink(time));

        int ty = cy + Cat.heightFor(catSize) + 10;
        scaledText(g, "BLACK CAT", x, ty, 2.2f, Style.WHITE);
        text(g, "Black Cat Studios  |  Cat OS", x + 2, ty + 24, Style.DIM);

        int by = ty + 40;
        int pw = Math.min(150, areaW - 20);
        boolean hovP = over(x, by, pw, 26);
        Gfx.roundRect(g, x, by, pw, 26, radius() + 2, c(hovP ? Gfx.lerpColor(Style.accent(), 0xFFFFFFFF, 0.25f) : Style.accent()));
        String play = "PLAY";
        Gfx.spaced(g, this.font, play, x + (pw - Gfx.spacedWidth(this.font, play, 2)) / 2, by + 9, c(0xFF0B0B0D), 2);
        hit(x, by, pw, 26, () -> openVanilla("Multiplayer", "net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen"));

        int hw = (pw - 6) / 2;
        smallButton(g, x, by + 32, hw, "Singleplayer", () -> openVanilla("Singleplayer",
                "net.minecraft.client.gui.screens.worldselection.SelectWorldScreen"));
        smallButton(g, x + hw + 6, by + 32, hw, "Client", () -> go(new HubScreen()));
    }

    private void smallButton(GuiGraphicsExtractor g, int x, int y, int w, String label, Runnable r) {
        boolean hov = over(x, y, w, 18);
        glass(g, x, y, w, 18);
        if (hov) Gfx.roundOutline(g, x, y, w, 18, radius() + 2, c(Style.accent()));
        text(g, Gfx.fit(this.font, label, w - 8), x + (w - Gfx.width(this.font, Gfx.fit(this.font, label, w - 8))) / 2, y + 5, Style.WHITE);
        hit(x, y, w, 18, r);
    }

    private void cards(GuiGraphicsExtractor g) {
        if (this.width < 360) return;
        int w = Math.min(190, (int) (this.width * 0.33f));
        int x = this.width - w - Math.max(14, (int) (this.width * 0.06f));
        int y = 30 + Math.round((1f - alpha) * 10f);
        // now playing
        glass(g, x, y, w, 52);
        text(g, "NOW PLAYING", x + 10, y + 7, Style.DIM);
        if (Music.status() == Music.Status.IDLE) {
            text(g, "Nothing playing", x + 10, y + 20, Style.WHITE);
            text(g, "Open the Client hub > Music", x + 10, y + 33, Style.DIM);
        } else {
            text(g, Gfx.fit(this.font, Music.title(), w - 20), x + 10, y + 20, Style.WHITE);
            int idx = Music.indexAt(Music.positionMs());
            String line = idx >= 0 ? Music.lines().get(idx).text() : "";
            text(g, Gfx.fit(this.font, line.isEmpty() ? (Music.isPlaying() ? "..." : "paused") : line, w - 20), x + 10, y + 33, 0xFFC8C8CE);
        }
        // stats
        y += 60;
        glass(g, x, y, w, 52);
        int active = 0;
        for (Modules.Module m : Modules.Module.values()) if (Modules.isEnabled(m)) active++;
        long sec = (System.currentTimeMillis() - Stats.SESSION_START) / 1000;
        text(g, "YOUR CLIENT", x + 10, y + 7, Style.DIM);
        text(g, "Profile: " + Gfx.fit(this.font, Modules.profileName(), w - 70), x + 10, y + 20, Style.WHITE);
        text(g, active + " modules on  |  open " + (sec / 60) + "m", x + 10, y + 33, 0xFFC8C8CE);
        // news
        y += 60;
        int nh = 78;
        glass(g, x, y, w, nh);
        text(g, "WHAT'S NEW", x + 10, y + 7, Style.DIM);
        String[] news = {"Cat OS lobby", "Big word-by-word lyrics", "Liquid glass + Obsidian looks", "Palette on Right Ctrl"};
        for (int i = 0; i < news.length; i++) {
            g.fill(x + 10, y + 22 + i * 12, x + 12, y + 29 + i * 12, c(Style.accent()));
            text(g, Gfx.fit(this.font, news[i], w - 30), x + 17, y + 21 + i * 12, 0xFFC8C8CE);
        }
    }

    private void dock(GuiGraphicsExtractor g) {
        int n = dock.size();
        int base = 26;
        int gap = 6;
        int baseline = this.height - 12;
        boolean near = my > baseline - 70;
        float[] sc = new float[n];
        float total = 0;
        // first pass: lay out at rest to know where each icon sits, then magnify by pointer distance
        float restTotal = n * base + (n - 1) * gap;
        float startRest = (this.width - restTotal) / 2f;
        for (int i = 0; i < n; i++) {
            float center = startRest + i * (base + gap) + base / 2f;
            float target = near && my >= 0 ? 1f + 0.5f * Math.max(0f, 1f - Math.abs(mx - center) / 56f) : 1f;
            dockScale[i] += (target - dockScale[i]) * 0.25f;
            sc[i] = dockScale[i];
            total += base * sc[i] + (i < n - 1 ? gap : 0);
        }
        int dockW = Math.round(total) + 20;
        int dockX = (this.width - dockW) / 2;
        int dockY = baseline - base - 8;
        int dockH = base + 16;
        int rise = Math.round((1f - alpha) * 20f);
        glass(g, dockX, dockY + rise, dockW, dockH);
        float cx = dockX + 10;
        for (int i = 0; i < n; i++) {
            int size = Math.round(base * sc[i]);
            int ix = Math.round(cx);
            int iy = baseline - size - 2 + rise;
            boolean hov = over(ix, iy, size, size);
            int r = Math.max(4, radius() + 2);
            int fillTop = hov ? 0xFF2C2C36 : 0xFF1C1C24;
            Gfx.roundRectV(g, ix, iy, size, size, r, c(fillTop), c(0xFF111116));
            Gfx.roundOutline(g, ix, iy, size, size, r, c(hov ? Style.accent() : 0xFF34343E));
            String gl = dock.get(i).glyph();
            float gs = Math.max(1f, size / 28f);
            int gw = Math.round(Gfx.width(this.font, gl) * gs);
            scaledText(g, gl, ix + (size - gw) / 2, iy + Math.round((size - 8 * gs) / 2f), gs, hov ? Style.accent() : Style.WHITE);
            if (hov) {
                String lab = dock.get(i).label();
                int lw = Gfx.width(this.font, lab) + 12;
                int lx = Math.max(4, Math.min(this.width - lw - 4, ix + size / 2 - lw / 2));
                glass(g, lx, iy - 22, lw, 16);
                text(g, lab, lx + 6, iy - 18, Style.WHITE);
            }
            final DockItem item = dock.get(i);
            hit(ix, iy, size, size, item.action());
            cx += size + gap;
        }
    }

    // ---------- input ----------

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.contains(mx, my)) {
                h.click().run();
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        return super.keyPressed(event);
    }
}
