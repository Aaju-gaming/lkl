package studio.blackcat.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import studio.blackcat.client.hud.Notify;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Music + Lyrics: looks a song up on LRCLIB (a free lyrics database) and keeps a clock that follows
 * the song, so the HUD can show the line being sung. The client cannot see what other apps are
 * playing, so the clock is started with the song and can be paused, restarted or nudged.
 */
public final class Music {
    private Music() {}

    public record Line(long timeMs, String text) {}

    public enum Status { IDLE, LOADING, SYNCED, PLAIN, NOT_FOUND, ERROR }

    private static volatile Status status = Status.IDLE;
    private static volatile String title = "";
    private static volatile String artist = "";
    private static volatile List<Line> lines = List.of();
    private static volatile long durationMs;
    private static volatile int generation;

    private static boolean playing;
    private static long baseMs;        // song position at the moment playback (re)started
    private static long baseWall;      // wall clock at that moment
    private static long offsetMs;      // user sync correction

    private static final Pattern LRC = Pattern.compile("\\[(\\d+):(\\d+)(?:[.:](\\d+))?]");
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(6)).build();

    public static Status status() { return status; }
    public static String title() { return title; }
    public static String artist() { return artist; }
    public static List<Line> lines() { return lines; }
    public static long durationMs() { return durationMs; }
    public static boolean isPlaying() { return playing; }
    public static long offsetMs() { return offsetMs; }

    private static boolean local;   // true while a local .ogg is really playing (the audio clock drives the lyrics)
    private static java.nio.file.Path currentFile;

    public static boolean isLocal() { return local; }

    /** .ogg files in config/blackcat/music, sorted by name. */
    public static List<java.nio.file.Path> library() {
        List<java.nio.file.Path> out = new ArrayList<>();
        try (var st = java.nio.file.Files.walk(Modules.dir("music"), 2)) {
            st.filter(f -> f.getFileName().toString().toLowerCase(java.util.Locale.ROOT).endsWith(".ogg")).sorted().forEach(out::add);
        } catch (Exception ignored) {
            // empty library
        }
        return out;
    }

    public static String musicFolder() {
        return Modules.dir("music").toString();
    }

    /** Plays a file from the library and fetches its lyrics ("Artist - Title.ogg" gives the best match). */
    public static void playFile(java.nio.file.Path file) {
        String name = file.getFileName().toString();
        int dot = name.lastIndexOf('.');
        if (dot > 0) name = name.substring(0, dot);
        AudioPlayer.stop();
        local = false;
        spotify = false;
        currentFile = file;
        setTrack(name.replace('_', ' '));
        AudioPlayer.load(file, generation);
    }

    /** Called every client tick: starts audio when it is ready, follows its end, reports problems. */
    public static void tick() {
        float vol = (float) Math.max(0.0, Math.min(1.0, Modules.textNum("music_vol", 0.6)));
        int started = AudioPlayer.poll(generation, vol);
        if (started >= 0) {
            local = true;
            playing = true;
            if (durationMs == 0) durationMs = (long) (AudioPlayer.durationSec() * 1000);
        }
        if (local && AudioPlayer.finished()) {
            playing = false;
            local = false;
            AudioPlayer.stop();
            Notify.push("Song finished");
        }
        String err = AudioPlayer.takeError();
        if (err != null) {
            local = false;
            Notify.push(err);
        }
    }

    /** Current song position in ms (including the sync correction). */
    public static long positionMs() {
        if (spotify) return Math.max(0, spBase + (playing ? System.currentTimeMillis() - spWall : 0) + offsetMs);
        if (local && AudioPlayer.active()) return Math.max(0, (long) (AudioPlayer.positionSec() * 1000) + offsetMs);
        long p = baseMs + (playing ? System.currentTimeMillis() - baseWall : 0) + offsetMs;
        return Math.max(0, p);
    }

    public static void toggle() {
        if (status == Status.IDLE || spotify) return; // Spotify is controlled from the Spotify app
        if (local) {
            if (playing) AudioPlayer.pause(); else AudioPlayer.resume();
            playing = !playing;
            return;
        }
        long pos = baseMs + (playing ? System.currentTimeMillis() - baseWall : 0);
        playing = !playing;
        baseMs = pos;
        baseWall = System.currentTimeMillis();
    }

    public static void restart() {
        if (spotify) return;
        if (local) {
            AudioPlayer.seekTo(0);
            if (!playing) AudioPlayer.resume();
            playing = true;
            return;
        }
        baseMs = 0;
        baseWall = System.currentTimeMillis();
        playing = true;
    }

    public static void seek(long deltaMs) {
        if (spotify) return;
        if (local) {
            AudioPlayer.seekTo(AudioPlayer.positionSec() + deltaMs / 1000.0);
            return;
        }
        long pos = baseMs + (playing ? System.currentTimeMillis() - baseWall : 0) + deltaMs;
        baseMs = Math.max(0, pos);
        baseWall = System.currentTimeMillis();
    }

    /** Nudges the lyric timing (positive = lyrics come sooner). */
    public static void nudge(long deltaMs) {
        offsetMs = Math.max(-10000, Math.min(10000, offsetMs + deltaMs));
    }

    public static void clear() {
        generation++;
        spotify = false;
        spotifyKey = "";
        AudioPlayer.stop();
        local = false;
        status = Status.IDLE;
        title = "";
        artist = "";
        lines = List.of();
        playing = false;
    }

    /** "Artist - Title" (or just a search phrase). Fetches in the background; the clock starts from 0 now. */
    public static void setTrack(String query) {
        final String q = query == null ? "" : query.trim();
        if (q.isEmpty()) {
            clear();
            return;
        }
        final int gen = ++generation;
        AudioPlayer.stop(); // typing a new song replaces whatever file was playing
        local = false;
        spotify = false;
        status = Status.LOADING;
        lines = List.of();
        offsetMs = 0;
        durationMs = 0;
        int dash = q.indexOf(" - ");
        artist = dash > 0 ? q.substring(0, dash).trim() : "";
        title = dash > 0 ? q.substring(dash + 3).trim() : q;
        baseMs = 0;
        baseWall = System.currentTimeMillis();
        playing = true;
        lookup(q.replace(" - ", " "), gen);
    }

    private static void lookup(String q, int gen) {
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create("https://lrclib.net/api/search?q="
                            + URLEncoder.encode(q, StandardCharsets.UTF_8)))
                    .timeout(Duration.ofSeconds(10))
                    .header("User-Agent", "BlackCatClient/0.11 (Minecraft mod)")
                    .GET().build();
            HTTP.sendAsync(req, HttpResponse.BodyHandlers.ofString()).whenComplete((resp, err) -> {
                if (gen != generation) return; // a newer search replaced this one
                if (err != null || resp == null || resp.statusCode() != 200) {
                    status = Status.ERROR;
                    Notify.push("Lyrics lookup failed (offline?)");
                    return;
                }
                try {
                    apply(resp.body(), gen);
                } catch (Throwable t) {
                    status = Status.ERROR;
                    Modules.logError("lyrics", t);
                }
            });
        } catch (Throwable t) {
            status = Status.ERROR;
            Modules.logError("lyrics", t);
        }
    }

    // ---------- Spotify mode: the clock follows what the linked Spotify account is playing ----------

    private static boolean spotify;
    private static String spotifyKey = "";
    private static long spBase, spWall;

    public static boolean isSpotify() { return spotify; }

    /** True when Spotify may take over (nothing from a local file is playing right now). */
    public static boolean spotifyMayDrive() {
        return !(local && playing);
    }

    /** A fresh sample from Spotify's "currently playing". Called from the Spotify poller thread. */
    public static void onSpotify(String artistName, String trackName, long durationMsIn, long progressMs, boolean isPlaying) {
        long now = System.currentTimeMillis();
        String key = artistName + "|" + trackName;
        if (!spotify || !key.equals(spotifyKey)) {
            final int gen = ++generation;
            AudioPlayer.stop();
            local = false;
            spotify = true;
            spotifyKey = key;
            status = Status.LOADING;
            lines = List.of();
            offsetMs = 0;
            artist = artistName;
            title = trackName;
            durationMs = durationMsIn;
            spBase = progressMs;
            spWall = now;
            playing = isPlaying;
            lookup(artistName + " " + trackName, gen);
            return;
        }
        long expected = spBase + (playing ? now - spWall : 0);
        // small differences are blended in so the lyrics do not jump on every poll; big ones (a seek) are taken at once
        spBase = Math.abs(expected - progressMs) < 1500 && playing && isPlaying ? (expected + progressMs) / 2 : progressMs;
        spWall = now;
        playing = isPlaying;
    }

    /** Spotify has nothing playing. */
    public static void onSpotifyIdle() {
        if (spotify) {
            long now = System.currentTimeMillis();
            spBase = spBase + (playing ? now - spWall : 0);
            spWall = now;
            playing = false;
        }
    }

    /** Downloads (if needed) and plays a track from a free music site. */
    public static void playOnline(OnlineMusic.Track t) {
        final int gen = ++generation;
        AudioPlayer.stop();
        local = false;
        spotify = false;
        status = Status.LOADING;
        lines = List.of();
        artist = t.artist();
        title = t.title();
        playing = false;
        Notify.push("Getting " + t.title() + "...");
        OnlineMusic.fetch(t, path -> {
            if (gen != generation) return;
            net.minecraft.client.Minecraft.getInstance().execute(() -> {
                if (gen == generation) playFile(path);
            });
        }, err -> {
            if (gen == generation) {
                status = Status.ERROR;
                Notify.push(err);
            }
        });
    }

    private static void apply(String body, int gen) {
        JsonArray arr = JsonParser.parseString(body).getAsJsonArray();
        JsonObject best = null;
        for (JsonElement el : arr) {
            JsonObject o = el.getAsJsonObject();
            if (str(o, "syncedLyrics").isEmpty()) continue;
            best = o;
            break;
        }
        if (best == null) {
            for (JsonElement el : arr) {
                JsonObject o = el.getAsJsonObject();
                if (!str(o, "plainLyrics").isEmpty()) {
                    best = o;
                    break;
                }
            }
        }
        if (gen != generation) return;
        if (best == null) {
            status = Status.NOT_FOUND;
            Notify.push("No lyrics found");
            return;
        }
        String t = str(best, "trackName");
        String a = str(best, "artistName");
        if (!t.isEmpty()) title = t;
        if (!a.isEmpty()) artist = a;
        if (best.has("duration") && !best.get("duration").isJsonNull()) {
            durationMs = (long) (best.get("duration").getAsDouble() * 1000);
        }
        String synced = str(best, "syncedLyrics");
        if (!synced.isEmpty()) {
            lines = parseLrc(synced);
            status = lines.isEmpty() ? Status.NOT_FOUND : Status.SYNCED;
        } else {
            List<Line> plain = new ArrayList<>();
            for (String s : str(best, "plainLyrics").split("\n")) plain.add(new Line(0, s.trim()));
            lines = plain;
            status = Status.PLAIN;
        }
        Notify.push("Now playing: " + title);
    }

    private static String str(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
    }

    static List<Line> parseLrc(String lrc) {
        List<Line> out = new ArrayList<>();
        for (String row : lrc.split("\n")) {
            Matcher m = LRC.matcher(row);
            List<Long> stamps = new ArrayList<>();
            int end = 0;
            while (m.find()) {
                long min = Long.parseLong(m.group(1));
                long sec = Long.parseLong(m.group(2));
                String f = m.group(3);
                long ms = f == null ? 0 : (long) (Double.parseDouble("0." + f) * 1000);
                stamps.add(min * 60000 + sec * 1000 + ms);
                end = m.end();
            }
            if (stamps.isEmpty()) continue;
            String text = row.substring(end).trim();
            for (long s : stamps) out.add(new Line(s, text));
        }
        out.sort((x, y) -> Long.compare(x.timeMs(), y.timeMs()));
        return out;
    }

    /** Index of the line being sung at the given position (-1 before the first line). */
    public static int indexAt(long posMs) {
        List<Line> l = lines;
        int lo = 0, hi = l.size() - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (l.get(mid).timeMs() <= posMs) {
                ans = mid;
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
        return ans;
    }
}
