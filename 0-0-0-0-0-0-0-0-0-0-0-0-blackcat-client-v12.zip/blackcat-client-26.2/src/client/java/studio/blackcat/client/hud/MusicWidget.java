package studio.blackcat.client.hud;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.Music;
import studio.blackcat.client.util.Gfx;

import java.util.List;

/** Now playing + synced lyrics: previous line (dim), current line (bright, fades in), next line (dim). */
final class MusicWidget extends HudWidget {
    private static final int W = 210;

    MusicWidget() {
        super(Module.MUSIC);
    }

    @Override
    public void layout(HudCtx c) {
        w = W;
        h = 62;
    }

    private static String clock(long ms) {
        long s = ms / 1000;
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }

    @Override
    public void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y) {
        Widgets.panel(g, x, y, w, h);
        Music.Status st = Music.status();
        int in = 8;
        if (st == Music.Status.IDLE && !c.preview) {
            Gfx.text(g, c.font, "Music + Lyrics", x + in, y + 8, Style.WHITE);
            Gfx.text(g, c.font, "Palette > Edit text settings >", x + in, y + 26, Style.DIM);
            Gfx.text(g, c.font, "type: Artist - Song", x + in, y + 38, Style.DIM);
            return;
        }
        String title = c.preview && st == Music.Status.IDLE ? "Midnight City" : Music.title();
        String artist = c.preview && st == Music.Status.IDLE ? "M83" : Music.artist();
        String head = artist.isEmpty() ? title : title + "  -  " + artist;
        Gfx.text(g, c.font, Gfx.fit(c.font, head, w - 2 * in), x + in, y + 6, Style.WHITE);

        // progress
        long pos = Music.positionMs();
        long dur = Music.durationMs();
        int bx = x + in, bw = w - 2 * in, by = y + 19;
        g.fill(bx, by, bx + bw, by + 2, 0xFF2A2A30);
        float frac = dur > 0 ? Math.min(1f, pos / (float) dur) : 0f;
        int fw = Math.round(bw * frac);
        for (int i = 0; i < fw; i += 2) {
            g.fill(bx + i, by, bx + Math.min(fw, i + 2), by + 2, Style.accentAt(bw == 0 ? 0 : i / (float) bw));
        }
        String tm = clock(pos) + (dur > 0 ? " / " + clock(dur) : "") + (Music.isPlaying() ? "" : "  paused");
        Gfx.text(g, c.font, tm, x + in, y + 24, Style.DIM);

        if (st == Music.Status.LOADING) {
            Gfx.text(g, c.font, "Finding lyrics...", x + in, y + 41, Style.DIM);
            return;
        }
        if (st == Music.Status.NOT_FOUND || st == Music.Status.ERROR) {
            Gfx.text(g, c.font, st == Music.Status.ERROR ? "Lookup failed (offline?)" : "No lyrics found", x + in, y + 41, Style.DIM);
            return;
        }
        if (c.preview && st == Music.Status.IDLE) {
            Gfx.text(g, c.font, "Waiting for the city to wake up", x + in, y + 41, Style.WHITE);
            return;
        }
        List<Music.Line> lines = Music.lines();
        if (st == Music.Status.PLAIN) {
            Gfx.text(g, c.font, "Lyrics found, but not timed", x + in, y + 41, Style.DIM);
            return;
        }
        int idx = Music.indexAt(pos);
        String prev = idx - 1 >= 0 ? lines.get(idx - 1).text() : "";
        String cur = idx >= 0 ? lines.get(idx).text() : "";
        String next = idx + 1 < lines.size() ? lines.get(idx + 1).text() : "";
        // the current line fades in over 300 ms after it starts
        float fade = idx >= 0 ? Math.min(1f, (pos - lines.get(idx).timeMs()) / 300f) : 1f;
        int maxW = w - 2 * in;
        Gfx.text(g, c.font, Gfx.fit(c.font, prev, maxW), x + in, y + 32, Gfx.mulAlpha(Style.DIM, 0.55f));
        Gfx.text(g, c.font, Gfx.fit(c.font, cur.isEmpty() ? "..." : cur, maxW), x + in, y + 42,
                Gfx.mulAlpha(Style.WHITE, 0.35f + 0.65f * fade));
        Gfx.text(g, c.font, Gfx.fit(c.font, next, maxW), x + in, y + 53, Gfx.mulAlpha(Style.DIM, 0.55f + 0.0f));
    }
}
