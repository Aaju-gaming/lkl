package studio.blackcat.client.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import studio.blackcat.client.util.Cat;

/** Everything a HUD element needs for one frame. */
public final class HudCtx {
    public final Minecraft mc;
    public final Font font;
    public final float dt;
    /** True in the HUD editor and the cosmetics preview: show sample data when the real data is empty. */
    public final boolean preview;
    public final float time;

    public HudCtx(Minecraft mc, float dt, boolean preview) {
        this.mc = mc;
        this.font = mc.font;
        this.dt = dt;
        this.preview = preview;
        this.time = Cat.time();
    }
}
