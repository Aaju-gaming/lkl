package studio.blackcat.client.hud;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;

/**
 * Freelook state. After pressing the key (press again to stop), mouse movement turns the camera instead of the player
 * (see EntityMixin / CameraMixin). Stopping snaps the view back to where the player faces.
 */
public final class Freelook {
    private Freelook() {}

    private static boolean active;
    private static float yaw;
    private static float pitch;

    public static boolean active() {
        return active;
    }

    public static float yaw() {
        return yaw;
    }

    public static float pitch() {
        return pitch;
    }

    private static CameraType before;

    /** Key press: starts freelook (and switches to F5 view), or stops it and restores the old view. */
    public static void toggle(Minecraft mc) {
        if (active) {
            stop(mc);
            return;
        }
        if (!Modules.isEnabled(Module.FREELOOK) || mc.player == null || mc.gui.screen() != null) return;
        yaw = mc.player.getYRot();
        pitch = mc.player.getXRot();
        before = mc.options.getCameraType();
        active = true;
        if (before.isFirstPerson()) mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
    }

    private static void stop(Minecraft mc) {
        active = false;
        if (before != null) mc.options.setCameraType(before);
        before = null;
    }

    /** Called every client tick: ends freelook if it was switched off or the player is gone. */
    public static void update(Minecraft mc) {
        if (active && (mc.player == null || !Modules.isEnabled(Module.FREELOOK))) stop(mc);
    }

    /** Applies a mouse delta (same units and 0.15 factor as vanilla's Entity.turn). */
    public static void turn(double yRot, double xRot) {
        yaw += (float) yRot * 0.15f;
        pitch = Math.max(-90f, Math.min(90f, pitch + (float) xRot * 0.15f));
    }
}
