package studio.blackcat.client.util;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;

import java.lang.reflect.Method;

/** Small 2D drawing toolkit: rounded rects, outlines, colour maths, textures, text. */
public final class Gfx {
    private Gfx() {}

    // ---------- colour / easing ----------

    public static int clamp255(int v) {
        return Math.max(0, Math.min(255, v));
    }

    public static float clamp01(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    public static int argb(int a, int r, int g, int b) {
        return (clamp255(a) << 24) | (clamp255(r) << 16) | (clamp255(g) << 8) | clamp255(b);
    }

    /** Multiplies the alpha channel of a colour by m (0..1). */
    public static int mulAlpha(int color, float m) {
        int a = Math.round(((color >>> 24) & 0xFF) * clamp01(m));
        return (a << 24) | (color & 0xFFFFFF);
    }

    public static int lerpColor(int c1, int c2, float t) {
        t = clamp01(t);
        int a = Math.round(((c1 >>> 24) & 0xFF) * (1 - t) + ((c2 >>> 24) & 0xFF) * t);
        int r = Math.round(((c1 >> 16) & 0xFF) * (1 - t) + ((c2 >> 16) & 0xFF) * t);
        int g = Math.round(((c1 >> 8) & 0xFF) * (1 - t) + ((c2 >> 8) & 0xFF) * t);
        int b = Math.round((c1 & 0xFF) * (1 - t) + (c2 & 0xFF) * t);
        return argb(a, r, g, b);
    }

    public static float easeOutCubic(float t) {
        float u = 1f - clamp01(t);
        return 1f - u * u * u;
    }

    // ---------- rounded rectangles ----------

    /** Horizontal inset of row i for a rect of height h with corner radius r. */
    private static int inset(int i, int h, int r) {
        int j = i < r ? i : (i >= h - r ? h - 1 - i : r);
        if (j >= r) return 0;
        double dy = r - j - 0.5;
        return r - (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
    }

    public static void roundRect(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int color) {
        roundRectV(g, x, y, w, h, r, color, color);
    }

    /** Rounded rect with a vertical colour gradient (top -> bottom). */
    public static void roundRectV(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int top, int bottom) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (top == bottom) {
            // solid colour: one fill for the straight middle, one per corner row (far fewer draw calls)
            if ((top >>> 24) == 0) return;
            for (int i = 0; i < r; i++) {
                int in = inset(i, h, r);
                g.fill(x + in, y + i, x + w - in, y + i + 1, top);
                g.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, top);
            }
            if (h - 2 * r > 0) g.fill(x, y + r, x + w, y + h - r, top);
            return;
        }
        // gradient: corner rows one by one, the straight middle in 3px bands (far fewer draw calls)
        int i = 0;
        while (i < h) {
            boolean corner = i < r || i >= h - r;
            int rows = corner ? 1 : Math.min(3, (h - r) - i);
            int c = lerpColor(top, bottom, h <= 1 ? 0f : (i + (rows - 1) / 2f) / (h - 1f));
            if ((c >>> 24) != 0) {
                int in = corner ? inset(i, h, r) : 0;
                g.fill(x + in, y + i, x + w - in, y + i + rows, c);
            }
            i += rows;
        }
    }

    /** 1px rounded outline. */
    public static void roundOutline(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 1 || (color >>> 24) == 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        // corner rows one by one, the straight sides as two tall fills
        for (int i = 0; i < r; i++) {
            int in = inset(i, h, r);
            int next = inset(i + 1, h, r);
            if (i == 0) {
                g.fill(x + in, y, x + w - in, y + 1, color);
                g.fill(x + in, y + h - 1, x + w - in, y + h, color);
            } else {
                int len = Math.max(1, inset(i - 1, h, r) - in);
                g.fill(x + in, y + i, x + in + len, y + i + 1, color);
                g.fill(x + w - in - len, y + i, x + w - in, y + i + 1, color);
                g.fill(x + in, y + h - 1 - i, x + in + len, y + h - i, color);
                g.fill(x + w - in - len, y + h - 1 - i, x + w - in, y + h - i, color);
            }
        }
        if (r == 0) {
            g.fill(x, y, x + w, y + 1, color);
            g.fill(x, y + h - 1, x + w, y + h, color);
        }
        if (h - 2 * r > 0) {
            g.fill(x, y + r, x + 1, y + h - r, color);
            g.fill(x + w - 1, y + r, x + w, y + h - r, color);
        }
    }

    // ---------- textures ----------

    /**
     * Draws a texture (texW x texH pixels) scaled to drawW x drawH. Scaling is done with the pose
     * matrix so only the plain 10-argument blit is needed.
     */
    public static void textureFit(GuiGraphicsExtractor g, Identifier id, int x, int y, int drawW, int drawH,
                                  int texW, int texH) {
        g.pose().pushMatrix();
        g.pose().translate((float) x, (float) y);
        g.pose().scale(drawW / (float) texW, drawH / (float) texH);
        g.blit(RenderPipelines.GUI_TEXTURED, id, 0, 0, 0f, 0f, texW, texH, texW, texH);
        g.pose().popMatrix();
    }

    /** Fades something already drawn on a flat backdrop by covering it with the backdrop colour. */
    public static void fadeCover(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int gr, int b, float visible) {
        int a = Math.round(255 * (1f - clamp01(visible)));
        if (a > 0) g.fill(x, y, x + w, y + h, argb(a, r, gr, b));
    }

    // ---------- text ----------

    private static final java.util.HashMap<String, Integer> WIDTHS = new java.util.HashMap<>();
    private static Font widthFont;

    /** Text width, cached (the HUD measures the same labels every frame). */
    public static int width(Font font, String s) {
        if (font != widthFont) {
            WIDTHS.clear();
            widthFont = font;
        }
        Integer w = WIDTHS.get(s);
        if (w == null) {
            if (WIDTHS.size() > 600) WIDTHS.clear();
            w = font.width(s);
            WIDTHS.put(s, w);
        }
        return w;
    }

    /** Text with extra space between the letters (for titles). Returns the width drawn. */
    public static int spaced(GuiGraphicsExtractor g, Font font, String s, int x, int y, int color, int spacing) {
        int cx = x;
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            text(g, font, ch, cx, y, color);
            cx += width(font, ch) + spacing;
        }
        return cx - x - spacing;
    }

    public static int spacedWidth(Font font, String s, int spacing) {
        int w = 0;
        for (int i = 0; i < s.length(); i++) w += width(font, String.valueOf(s.charAt(i))) + spacing;
        return Math.max(0, w - spacing);
    }

    public static void text(GuiGraphicsExtractor g, Font font, String s, int x, int y, int color) {
        if ((color >>> 24) < 8) return; // vanilla treats tiny alpha as opaque
        g.text(font, s, x, y, color);
    }

    // ---------- item icons ----------

    private static Method itemMethod;
    private static boolean itemLookedUp;

    /**
     * Draws an item icon. The method name differs between Minecraft versions, so it is looked up once at
     * runtime; returns false if no icon method was found (callers then draw a text fallback).
     */
    public static boolean item(GuiGraphicsExtractor g, ItemStack stack, int x, int y) {
        if (!itemLookedUp) {
            itemLookedUp = true;
            for (String name : new String[]{"item", "renderItem", "fakeItem", "renderFakeItem"}) {
                try {
                    Method m = GuiGraphicsExtractor.class.getMethod(name, ItemStack.class, int.class, int.class);
                    itemMethod = m;
                    break;
                } catch (Throwable ignored) {
                    // try next name
                }
            }
        }
        if (itemMethod == null) return false;
        try {
            itemMethod.invoke(g, stack, x, y);
            return true;
        } catch (Throwable t) {
            itemMethod = null;
            return false;
        }
    }

    /** Cuts text with ".." so it fits maxW pixels. */
    public static String fit(Font font, String s, int maxW) {
        if (font.width(s) <= maxW) return s;
        while (s.length() > 1 && font.width(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
}
