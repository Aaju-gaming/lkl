package studio.blackcat.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.multiplayer.ServerData;
import org.lwjgl.glfw.GLFW;
import net.minecraft.network.chat.Component;
import studio.blackcat.client.BlackCatClient;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.hud.HudCtx;
import studio.blackcat.client.hud.Style;
import studio.blackcat.client.hud.Widgets;
import studio.blackcat.client.util.Cat;
import studio.blackcat.client.util.Gfx;
import studio.blackcat.client.util.Smooth;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;

/**
 * The Black Cat menu: flat matte black, thin edges, smooth motion everywhere.
 *
 * Pages: Modules (switch things on/off), Theme (colours, gradient, opacity, saved themes),
 * Profiles (save / load / import / export layouts, auto-switch per server) and Keys (rebind our keys).
 * An Edit HUD button opens the drag-to-move editor.
 *
 * Built in immediate mode: each frame the page draws itself and registers the clickable areas it drew.
 */
public class GlassMenuScreen extends Screen {
    private static final int PANEL_W = 400;
    private static final int PANEL_H = 232;
    private static final int PAD = 14;
    private static final int GAP = 8;
    private static final int COLS = 3;
    private static final int CARD_H = 54;
    private static final int HEADER_H = 46;
    private static final int TAB_H = 18;

    // matte palette
    private static final int PANEL_BG = 0xF20B0B0D;
    private static final int PANEL_EDGE = 0xFF26262C;
    private static final int DIVIDER = 0xFF1C1C21;
    private static final int CARD_BG = 0xFF121215;
    private static final int CARD_HOVER = 0xFF19191D;
    private static final int CARD_EDGE = 0xFF222228;
    private static final int TEXT = 0xFFEDEDED;
    private static final int DIM = 0xFF8C8C95;
    private static final int TRACK_OFF = 0xFF2A2A30;
    private static final int KNOB_OFF = 0xFF8C8C95;
    private static final int KNOB_ON = 0xFF0B0B0D;

    private static final String[] TAB_NAMES = {"Modules", "Theme", "Profiles", "Keys"};
    private static final String EDIT_LABEL = "Edit HUD";

    /** Remembered between openings. */
    private static int lastTab = 0;

    /** A clickable (and optionally draggable) area registered while drawing. */
    private static final class Hit {
        final int x, y, w, h;
        final Runnable click;
        final DoubleConsumer drag;   // gets the pointer x while dragging (sliders)
        final Runnable release;      // after a slider drag

        Hit(int x, int y, int w, int h, Runnable click, DoubleConsumer drag, Runnable release) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.click = click;
            this.drag = drag;
            this.release = release;
        }

        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private int tab = lastTab;
    private final Smooth open = new Smooth(0f);
    private final Smooth page = new Smooth(1f);
    private final Smooth scrollAnim = new Smooth(0f);
    private Modules.Category catFilter;
    private boolean favOnly;
    private String search = "";
    private boolean searchFocus;
    private final Smooth[] hover = new Smooth[Module.values().length];
    private final Smooth[] on = new Smooth[Module.values().length];
    private final Smooth[] hdrHover = new Smooth[TAB_NAMES.length + 1];
    private final Smooth[] tabOn = new Smooth[TAB_NAMES.length];
    private final Smooth badgeOn = new Smooth(Modules.nameBadge() ? 1f : 0f);
    private final Smooth gradOn = new Smooth(Modules.gradient() ? 1f : 0f);

    private final List<Hit> hits = new ArrayList<>();
    private Hit slider;
    private boolean closing;
    private long lastNanos = System.nanoTime();
    private int lastMouseX = -1;
    private int lastMouseY = -1;
    private float scrollTarget;
    private float dragTotal;
    private boolean dragging;
    private int contentH;
    private KeyMapping listening;
    private String message = "";

    public GlassMenuScreen() {
        super(Component.literal("Black Cat"));
        for (int i = 0; i < hover.length; i++) {
            hover[i] = new Smooth(0f);
            on[i] = new Smooth(Modules.isEnabled(Module.values()[i]) ? 1f : 0f);
        }
        for (int i = 0; i < hdrHover.length; i++) hdrHover[i] = new Smooth(0f);
        for (int i = 0; i < tabOn.length; i++) tabOn[i] = new Smooth(i == tab ? 1f : 0f);
    }

    /** Opens straight on a tab (0 Modules, 1 Theme, 2 Profiles, 3 Keys). */
    public GlassMenuScreen(int startTab) {
        this();
        tab = Math.max(0, Math.min(TAB_NAMES.length - 1, startTab));
        for (int i = 0; i < tabOn.length; i++) tabOn[i].value = i == tab ? 1f : 0f;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        closing = true; // fade out first, then really close
    }

    // ---------- layout ----------

    private int panelX() {
        return (width - PANEL_W) / 2;
    }

    private int panelY() {
        return (height - PANEL_H) / 2;
    }

    private int viewTop() {
        return panelY() + HEADER_H + 8;
    }

    private int viewBottom() {
        return panelY() + PANEL_H - PAD + 2;
    }

    private int cardW() {
        return (PANEL_W - PAD * 2 - GAP * (COLS - 1)) / COLS;
    }

    private int rowX() {
        return panelX() + PAD;
    }

    private int rowW() {
        return PANEL_W - PAD * 2;
    }

    private float maxScroll() {
        return Math.max(0f, contentH - (viewBottom() - viewTop()));
    }

    private int scrollPx() {
        return Math.round(scrollAnim.value);
    }

    // header buttons: 0..3 = tabs, 4 = Edit HUD

    private int hdrW(int i) {
        return Gfx.width(font, i == TAB_NAMES.length ? EDIT_LABEL : TAB_NAMES[i]) + 14;
    }

    private int hdrX(int i) {
        if (i == TAB_NAMES.length) return panelX() + PANEL_W - PAD - hdrW(i);
        int x = panelX() + 106;
        for (int k = 0; k < i; k++) x += hdrW(k) + 3;
        return x;
    }

    private int hdrY() {
        return panelY() + 14;
    }

    private boolean overHdr(int i, double mx, double my) {
        return mx >= hdrX(i) && mx < hdrX(i) + hdrW(i) && my >= hdrY() && my < hdrY() + TAB_H;
    }

    private boolean inView(double my) {
        return my >= viewTop() && my <= viewBottom();
    }

    private void switchTab(int t) {
        if (t == tab) return;
        tab = t;
        lastTab = t;
        scrollTarget = 0f;
        scrollAnim.value = 0f;
        page.value = 0f;
        listening = null;
        message = "";
    }

    // ---------- immediate-mode helpers ----------

    /** Registers a clickable page area, cut to the visible view so it never reaches under the header. */
    private void hit(int x, int y, int w, int h, Runnable click) {
        addClipped(new Hit(x, y, w, h, click, null, null));
    }

    private void addClipped(Hit hh) {
        int y0 = Math.max(hh.y, viewTop());
        int y1 = Math.min(hh.y + hh.h, viewBottom());
        if (y1 <= y0) return;
        hits.add(new Hit(hh.x, y0, hh.w, y1 - y0, hh.click, hh.drag, hh.release));
    }

    /** A card background; returns true if it is at least partly visible (so the caller draws its content). */
    private boolean card(GuiGraphicsExtractor g, int x, int y, int w, int h, float alpha, boolean hov) {
        if (y > viewBottom() || y + h < viewTop()) return false;
        Gfx.roundRect(g, x, y, w, h, 6, Gfx.mulAlpha(hov ? CARD_HOVER : CARD_BG, alpha));
        Gfx.roundOutline(g, x, y, w, h, 6, Gfx.mulAlpha(CARD_EDGE, alpha));
        return true;
    }

    private boolean visible(int y, int h) {
        return y <= viewBottom() && y + h >= viewTop();
    }

    private boolean overMouse(int x, int y, int w, int h) {
        return !closing && inView(lastMouseY) && lastMouseX >= x && lastMouseX < x + w && lastMouseY >= y && lastMouseY < y + h;
    }

    /** The sliding on/off switch (28 x 12). */
    private void toggle(GuiGraphicsExtractor g, int tx, int ty, float s, float alpha) {
        int tw = 28;
        int th = 12;
        Gfx.roundRect(g, tx, ty, tw, th, 6, Gfx.mulAlpha(Gfx.lerpColor(TRACK_OFF, Style.accent(), s), alpha));
        int knobX = tx + 2 + Math.round(s * (tw - th));
        Gfx.roundRect(g, knobX, ty + 2, th - 4, th - 4, 4,
                Gfx.mulAlpha(Gfx.lerpColor(KNOB_OFF, KNOB_ON, s), alpha));
    }

    /** A small text button. Returns its width. */
    private int smallButton(GuiGraphicsExtractor g, int x, int y, String label, boolean enabled, float alpha, Runnable click) {
        int w = Gfx.width(font, label) + 14;
        int h = 16;
        boolean hov = enabled && overMouse(x, y, w, h);
        Gfx.roundRect(g, x, y, w, h, 4, Gfx.mulAlpha(hov ? 0xFF26262C : 0xFF17171B, alpha));
        Gfx.roundOutline(g, x, y, w, h, 4, Gfx.mulAlpha(hov ? DIM : CARD_EDGE, alpha));
        Gfx.text(g, font, label, x + 7, y + 4, Gfx.mulAlpha(enabled ? TEXT : 0xFF55555D, alpha));
        if (enabled && visible(y, h)) hit(x, y, w, h, click);
        return w;
    }

    /** A horizontal slider. frac 0..1; onFrac receives new values while dragging; onRelease runs at the end. */
    private void sliderBar(GuiGraphicsExtractor g, int x0, int x1, int y, float frac, float alpha, int accent,
                           DoubleConsumer onFrac, Runnable onRelease) {
        int kx = x0 + Math.round(Gfx.clamp01(frac) * (x1 - x0));
        Gfx.roundRect(g, x0, y - 2, x1 - x0, 4, 2, Gfx.mulAlpha(TRACK_OFF, alpha));
        if (kx > x0) Gfx.roundRect(g, x0, y - 2, kx - x0, 4, 2, Gfx.mulAlpha(accent, alpha));
        boolean held = slider != null && slider.x == x0 - 6 && slider.w == x1 - x0 + 12;
        int kw = held ? 10 : 8;
        Gfx.roundRect(g, kx - kw / 2, y - 6, kw, 12, 4, Gfx.mulAlpha(Style.WHITE, alpha));
        if (visible(y - 10, 20)) {
            final int fx0 = x0;
            final int fx1 = x1;
            addClipped(new Hit(x0 - 6, y - 10, x1 - x0 + 12, 20, null,
                    mx -> onFrac.accept(Gfx.clamp01((float) (mx - fx0) / (fx1 - fx0))), onRelease));
        }
    }

    // ---------- rendering ----------

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        lastMouseX = mouseX;
        lastMouseY = mouseY;

        long now = System.nanoTime();
        float dt = Math.min((now - lastNanos) / 1_000_000_000f, 0.1f);
        lastNanos = now;

        open.update(closing ? 0f : 1f, dt, closing ? 14f : 9f);
        if (closing && open.value <= 0.01f) {
            super.onClose(); // vanilla: leave the screen
            return;
        }
        page.update(1f, dt, 9f);
        float t = Gfx.easeOutCubic(open.value);
        int accent = Style.accent();

        scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget));
        scrollAnim.update(scrollTarget, dt, 16f);

        // a slider being dragged follows the pointer
        if (slider != null && slider.drag != null) slider.drag.accept(mouseX);

        hits.clear();

        // soft dim on top of vanilla's blur
        g.fill(0, 0, width, height, Gfx.argb(Math.round(80 * t), 0, 0, 0));

        // panel rises and scales up slightly
        float scale = 0.95f + 0.05f * t;
        float rise = (1f - t) * 12f;
        g.pose().pushMatrix();
        g.pose().translate(width / 2f, height / 2f + rise);
        g.pose().scale(scale, scale);
        g.pose().translate(-width / 2f, -height / 2f);

        int px = panelX();
        int py = panelY();

        // matte body + hairline edge
        Gfx.roundRectV(g, px, py, PANEL_W, PANEL_H, 8, Gfx.mulAlpha(Style.panelTop(), t), Gfx.mulAlpha(Style.panelBottom(), t));
        Gfx.roundOutline(g, px, py, PANEL_W, PANEL_H, 8, Gfx.mulAlpha(Style.panelEdge(), t));
        if (Style.glass()) {
            g.fill(px + 8, py + 1, px + PANEL_W - 8, py + 2, Gfx.mulAlpha(0x38FFFFFF, t)); // glass highlight
        }

        // header: the logo cat (blinking) + title
        if (open.value > 0.35f) {
            // idle: the cat slowly breathes (a tiny rise and fall) while it blinks
            float ct = Cat.time();
            int bob = Math.round((float) Math.sin(ct * 1.6f) * 0.8f);
            Cat.draw(g, px + PAD, py + 15 + bob, 40, Cat.blink(ct));
        }
        Gfx.spaced(g, font, "BLACK CAT", px + PAD + 46, py + 13, Gfx.mulAlpha(TEXT, t), 1);
        Gfx.spaced(g, font, "STUDIOS", px + PAD + 46, py + 25, Gfx.mulAlpha(DIM, t), 2);

        // header buttons: tabs + Edit HUD
        for (int i = 0; i <= TAB_NAMES.length; i++) {
            boolean hov = !closing && overHdr(i, mouseX, mouseY);
            float h = hdrHover[i].update(hov ? 1f : 0f, dt, 14f);
            int x = hdrX(i);
            int y = hdrY() - Math.round(h);
            int w = hdrW(i);
            boolean isEdit = i == TAB_NAMES.length;
            String label = isEdit ? EDIT_LABEL : TAB_NAMES[i];

            if (!isEdit) {
                float a = tabOn[i].update(tab == i ? 1f : 0f, dt, 14f);
                int bg = Gfx.lerpColor(Gfx.lerpColor(0x00000000, 0xFF17171B, h), 0xFF222228, a);
                int edge = Gfx.lerpColor(Gfx.lerpColor(0x00000000, Style.EDGE, h), accent, a * 0.8f);
                Gfx.roundRect(g, x, y, w, TAB_H, 5, Gfx.mulAlpha(bg, t));
                Gfx.roundOutline(g, x, y, w, TAB_H, 5, Gfx.mulAlpha(edge, t));
                Gfx.text(g, font, label, x + (w - Gfx.width(font, label)) / 2, y + 5,
                        Gfx.mulAlpha(Gfx.lerpColor(DIM, Style.WHITE, Math.max(a, h * 0.6f)), t));
            } else {
                int bg = Gfx.lerpColor(0xFF141418, accent, h * 0.9f);
                int edge = Gfx.lerpColor(accent, Style.WHITE, h * 0.3f);
                Gfx.roundRect(g, x, y, w, TAB_H, 5, Gfx.mulAlpha(bg, t));
                Gfx.roundOutline(g, x, y, w, TAB_H, 5, Gfx.mulAlpha(edge, t));
                Gfx.text(g, font, label, x + (w - Gfx.width(font, label)) / 2, y + 5,
                        Gfx.mulAlpha(Gfx.lerpColor(Style.WHITE, 0xFF0B0B0D, h), t));
            }
            final int idx = i;
            hits.add(new Hit(hdrX(i), hdrY(), hdrW(i), TAB_H, () -> {
                if (idx < TAB_NAMES.length) switchTab(idx);
                else this.minecraft.gui.setScreen(new HudEditorScreen());
            }, null, null));
        }

        g.fill(px + PAD, py + HEADER_H, px + PANEL_W - PAD, py + HEADER_H + 1, Gfx.mulAlpha(DIVIDER, t));

        // ----- the page, clipped to the view -----
        float pageT = Math.min(open.value, page.value);
        int top = viewTop() - scrollPx();
        g.enableScissor(px + 4, viewTop(), px + PANEL_W - 4, viewBottom());
        int endY;
        switch (tab) {
            case 0 -> endY = renderModules(g, top, dt, pageT);
            case 1 -> endY = renderTheme(g, top, dt, pageT);
            case 2 -> endY = renderProfiles(g, top, pageT);
            default -> endY = renderKeys(g, top, pageT);
        }
        g.disableScissor();
        contentH = Math.max(0, endY - top);

        // thin scroll bar
        float max = maxScroll();
        if (max > 0f) {
            int trackTop = viewTop();
            int trackH = viewBottom() - viewTop();
            int thumbH = Math.max(18, Math.round(trackH * trackH / (trackH + max)));
            int thumbY = trackTop + Math.round((trackH - thumbH) * (scrollAnim.value / max));
            int bx = px + PANEL_W - 8;
            g.fill(bx, thumbY, bx + 2, thumbY + thumbH, Gfx.mulAlpha(0xFF3A3A42, t));
        }

        g.pose().popMatrix();
    }

    // ----- Modules page -----

    private int renderModules(GuiGraphicsExtractor g, int top, float dt, float pageT) {
        int accent = Style.accent();
        int cw = cardW();

        // ---- filter row: categories, favourites, search ----
        int fx = rowX();
        String[] chipNames = new String[Modules.Category.values().length + 1];
        chipNames[0] = "All";
        for (int c = 0; c < Modules.Category.values().length; c++) chipNames[c + 1] = Modules.Category.values()[c].title;
        for (int c = 0; c < chipNames.length; c++) {
            boolean sel = (c == 0 && catFilter == null) || (c > 0 && catFilter == Modules.Category.values()[c - 1]);
            final int ci = c;
            fx += chip(g, fx, top, chipNames[c], sel, pageT, accent, () -> {
                catFilter = ci == 0 ? null : Modules.Category.values()[ci - 1];
                scrollTarget = 0f;
            }) + 4;
        }
        fx += chip(g, fx, top, "Favs", favOnly, pageT, accent, () -> {
            favOnly = !favOnly;
            scrollTarget = 0f;
        }) + 4;
        int sy = top + 18;
        int sw = rowW() - 2 * 62 - 8;
        float sa = Gfx.easeOutCubic(Gfx.clamp01(pageT));
        Gfx.roundRect(g, rowX(), sy, sw, 14, 4, Gfx.mulAlpha(searchFocus ? 0xFF26262C : 0xFF1A1A1F, sa));
        Gfx.roundOutline(g, rowX(), sy, sw, 14, 4, Gfx.mulAlpha(searchFocus ? accent : CARD_EDGE, sa));
        String shownQ = search.isEmpty() ? (searchFocus ? "" : "Search modules...") : search;
        boolean caret = searchFocus && (System.currentTimeMillis() / 500) % 2 == 0;
        Gfx.text(g, font, Gfx.fit(font, shownQ + (caret ? "_" : ""), sw - 12), rowX() + 6, sy + 3,
                Gfx.mulAlpha(search.isEmpty() ? DIM : TEXT, sa));
        hit(rowX(), sy, sw, 14, () -> searchFocus = true);
        chip(g, rowX() + sw + 4, sy, "Settings", false, pageT, accent,
                () -> this.minecraft.gui.setScreen(new TextSettingsScreen()));
        chip(g, rowX() + sw + 4 + 62, sy, "Palette", false, pageT, accent,
                () -> this.minecraft.gui.setScreen(new PaletteScreen()));
        top += 38;

        // favourites first, otherwise in the usual order; filtered by category / favourites / search
        String q = search.toLowerCase(java.util.Locale.ROOT).trim();
        List<Module> order = new ArrayList<>();
        for (int pass = 0; pass < 2; pass++) {
            for (Module m : Module.values()) {
                if (Modules.isFavModule(m) != (pass == 0)) continue;
                if (catFilter != null && m.category != catFilter) continue;
                if (favOnly && !Modules.isFavModule(m)) continue;
                if (!q.isEmpty() && !m.title.toLowerCase(java.util.Locale.ROOT).contains(q)
                        && !m.description.toLowerCase(java.util.Locale.ROOT).contains(q)) continue;
                order.add(m);
            }
        }
        if (order.isEmpty()) {
            Gfx.text(g, font, "No modules match.", rowX() + 4, top + 6, Gfx.mulAlpha(DIM, sa));
            return top + 20;
        }

        for (int i = 0; i < order.size(); i++) {
            Module m = order.get(i);
            int oi = m.ordinal();
            float cardT = Gfx.easeOutCubic(Gfx.clamp01((pageT - i * 0.03f) / 0.7f));
            int cx = rowX() + (i % COLS) * (cw + GAP);
            int baseY = top + (i / COLS) * (CARD_H + GAP);

            boolean hov = overMouse(cx, baseY, cw, CARD_H);
            float h = hover[oi].update(hov ? 1f : 0f, dt, 14f);
            float s = on[oi].update(Modules.isEnabled(m) ? 1f : 0f, dt, 12f);

            int cy = baseY - Math.round(h * 1.5f) + Math.round((1f - cardT) * 8f);
            if (!visible(cy, CARD_H)) continue;

            int bg = Gfx.lerpColor(CARD_BG, CARD_HOVER, h);
            int edge = Gfx.lerpColor(CARD_EDGE, Gfx.lerpColor(DIM, accent, s), Math.max(h * 0.5f, s * 0.7f));
            Gfx.roundRect(g, cx, cy, cw, CARD_H, 6, Gfx.mulAlpha(bg, cardT));
            Gfx.roundOutline(g, cx, cy, cw, CARD_H, 6, Gfx.mulAlpha(edge, cardT));

            Gfx.text(g, font, Gfx.fit(font, m.title, cw - 30), cx + 9, cy + 8, Gfx.mulAlpha(TEXT, cardT));
            Gfx.text(g, font, Gfx.fit(font, m.description, cw - 18), cx + 9, cy + 20, Gfx.mulAlpha(DIM, cardT));
            toggle(g, cx + 9, cy + CARD_H - 12 - 8, s, cardT);

            // favourite marker (a small diamond): tap it to pin the module to the top
            boolean fav = Modules.isFavModule(m);
            diamond(g, cx + cw - 14, cy + 11, fav ? accent : 0xFF3A3A42, cardT, fav);

            hit(cx, baseY, cw, CARD_H, () -> Modules.toggle(m));
            hit(cx + cw - 24, baseY, 24, 22, () -> Modules.toggleFavModule(m));
        }
        int rows = (order.size() + COLS - 1) / COLS;
        return top + rows * (CARD_H + GAP) - GAP;
    }

    /** A small filter chip; returns its width. */
    private int chip(GuiGraphicsExtractor g, int x, int y, String label, boolean sel, float pageT, int accent, Runnable click) {
        int w = Gfx.width(font, label) + 12;
        float a = Gfx.easeOutCubic(Gfx.clamp01(pageT));
        boolean hov = overMouse(x, y, w, 14);
        int bg = sel ? 0xFF222228 : hov ? 0xFF1C1C21 : 0xFF141418;
        Gfx.roundRect(g, x, y, w, 14, 4, Gfx.mulAlpha(bg, a));
        Gfx.roundOutline(g, x, y, w, 14, 4, Gfx.mulAlpha(sel ? accent : CARD_EDGE, a));
        Gfx.text(g, font, label, x + 6, y + 3, Gfx.mulAlpha(sel ? TEXT : DIM, a));
        hit(x, y, w, 14, click);
        return w;
    }

    /** A small diamond centred on (cx, cy): filled when active, outline otherwise. */
    private void diamond(GuiGraphicsExtractor g, int cx, int cy, int color, float alpha, boolean filled) {
        int c = Gfx.mulAlpha(color, alpha);
        for (int d = -4; d <= 4; d++) {
            int half = 4 - Math.abs(d);
            if (filled) {
                g.fill(cx - half, cy + d, cx + half + 1, cy + d + 1, c);
            } else {
                g.fill(cx - half, cy + d, cx - half + 1, cy + d + 1, c);
                g.fill(cx + half, cy + d, cx + half + 1, cy + d + 1, c);
            }
        }
    }

    // ----- Theme page -----

    private int renderTheme(GuiGraphicsExtractor g, int top, float dt, float pageT) {
        int rx = rowX();
        int rw = rowW();
        int y = top;
        int row = 0;

        // 1. preview
        {
            float a = rowAlpha(pageT, row++);
            int h = 54;
            if (card(g, rx, y, rw, h, a, false)) {
                Gfx.text(g, font, "Preview", rx + 10, y + 8, Gfx.mulAlpha(TEXT, a));
                String note = "changes show live";
                Gfx.text(g, font, note, rx + rw - 10 - Gfx.width(font, note), y + 8, Gfx.mulAlpha(DIM, a));
                int by = y + 22;
                Gfx.roundRectV(g, rx + 8, by, rw - 16, 26, 5, Gfx.mulAlpha(0xFF46505E, a), Gfx.mulAlpha(0xFF2B323C, a));
                HudCtx ctx = new HudCtx(this.minecraft, dt, true);
                Widgets.NAME.layout(ctx);
                Widgets.FPS.layout(ctx);
                int nx = rx + 16;
                Widgets.NAME.draw(g, ctx, nx, by + (26 - Widgets.NAME.h) / 2);
                Widgets.FPS.draw(g, ctx, nx + Widgets.NAME.w + 6, by + (26 - Widgets.FPS.h) / 2);
            }
            y += h + GAP;
        }

        // 1b. look: matte / monochrome / frosted glass
        {
            float a = rowAlpha(pageT, row++);
            int h = 52;
            if (card(g, rx, y, rw, h, a, false)) {
                Gfx.text(g, font, "Look", rx + 10, y + 8, Gfx.mulAlpha(TEXT, a));
                String cur = Style.LOOK_NAMES[Modules.look()];
                Gfx.text(g, font, cur, rx + rw - 10 - Gfx.width(font, cur), y + 8, Gfx.mulAlpha(DIM, a));
                int bx = rx + 10;
                for (int i = 0; i < Style.LOOK_NAMES.length; i++) {
                    final int idx = i;
                    String label = Style.LOOK_NAMES[i];
                    int w = Gfx.width(font, label) + 22;
                    boolean sel = Modules.look() == i;
                    boolean hov = overMouse(bx, y + 26, w, 18);
                    Gfx.roundRect(g, bx, y + 26, w, 18, 5, Gfx.mulAlpha(sel ? 0xFF2A2A31 : (hov ? 0xFF212127 : 0xFF17171B), a));
                    Gfx.roundOutline(g, bx, y + 26, w, 18, 5, Gfx.mulAlpha(sel ? Style.accent() : CARD_EDGE, a));
                    Gfx.text(g, font, label, bx + 11, y + 31, Gfx.mulAlpha(sel ? Style.WHITE : DIM, a));
                    if (visible(y + 26, 18)) hit(bx, y + 26, w, 18, () -> Modules.setLook(idx));
                    bx += w + 6;
                }
            }
            y += h + GAP;
        }

        // 2. accent presets + custom
        {
            float a = rowAlpha(pageT, row++);
            int h = 54;
            if (card(g, rx, y, rw, h, a, false)) {
                Gfx.text(g, font, "Accent color", rx + 10, y + 8, Gfx.mulAlpha(TEXT, a));
                String name = Modules.accentIndex() < 0 ? "Custom" : Modules.ACCENT_NAMES[Modules.accentIndex()];
                Gfx.text(g, font, name, rx + rw - 10 - Gfx.width(font, name), y + 8, Gfx.mulAlpha(DIM, a));
                int n = Modules.ACCENT_COLORS.length;
                for (int i = 0; i <= n; i++) {
                    int sx = rx + 10 + i * 32;
                    int sy = y + 28;
                    boolean custom = i == n;
                    int col = custom ? Modules.customAccent() : Modules.ACCENT_COLORS[i];
                    Gfx.roundRect(g, sx, sy, 24, 14, 5, Gfx.mulAlpha(col, a));
                    if (custom) Gfx.text(g, font, "RGB", sx + 3, sy + 3, Gfx.mulAlpha(0xFF0B0B0D, a));
                    boolean sel = custom ? Modules.accentIndex() < 0 : Modules.accentIndex() == i;
                    if (sel) Gfx.roundOutline(g, sx - 3, sy - 3, 30, 20, 7, Gfx.mulAlpha(Style.WHITE, a));
                    final int idx = i;
                    if (visible(sy, 14)) hit(sx - 2, sy - 3, 28, 20, () -> {
                        if (idx == n) {
                            int c = Modules.customAccent();
                            Modules.setCustomAccent((c >> 16) & 255, (c >> 8) & 255, c & 255);
                            Modules.save();
                        } else {
                            Modules.setAccent(idx);
                        }
                    });
                }
            }
            y += h + GAP;
        }

        // 3. custom colour: R G B sliders
        {
            float a = rowAlpha(pageT, row++);
            int h = 82;
            if (card(g, rx, y, rw, h, a, false)) {
                Gfx.text(g, font, "Custom color", rx + 10, y + 8, Gfx.mulAlpha(TEXT, a));
                int c = Modules.customAccent();
                String hex = String.format("#%06X", c & 0xFFFFFF);
                Gfx.text(g, font, hex, rx + rw - 10 - Gfx.width(font, hex), y + 8, Gfx.mulAlpha(DIM, a));
                String[] names = {"R", "G", "B"};
                int[] shift = {16, 8, 0};
                int[] tint = {0xFFFF6B6B, 0xFF6BE08A, 0xFF6BA8FF};
                for (int k = 0; k < 3; k++) {
                    int sy = y + 30 + k * 16;
                    int val = (c >> shift[k]) & 255;
                    Gfx.text(g, font, names[k], rx + 10, sy - 4, Gfx.mulAlpha(DIM, a));
                    String num = String.valueOf(val);
                    Gfx.text(g, font, num, rx + rw - 10 - Gfx.width(font, num), sy - 4, Gfx.mulAlpha(TEXT, a));
                    final int kk = k;
                    sliderBar(g, rx + 26, rx + rw - 40, sy, val / 255f, a, tint[k], f -> {
                        int cur = Modules.customAccent();
                        int[] rgb = {(cur >> 16) & 255, (cur >> 8) & 255, cur & 255};
                        rgb[kk] = Math.round((float) f * 255f);
                        Modules.setCustomAccent(rgb[0], rgb[1], rgb[2]);
                    }, Modules::save);
                }
            }
            y += h + GAP;
        }

        // 4. gradient
        {
            float a = rowAlpha(pageT, row++);
            int h = 78;
            float s = gradOn.update(Modules.gradient() ? 1f : 0f, dt, 12f);
            if (card(g, rx, y, rw, h, a, false)) {
                Gfx.text(g, font, "Gradient accent", rx + 10, y + 8, Gfx.mulAlpha(TEXT, a));
                Gfx.text(g, font, "Blend the accent into a second color", rx + 10, y + 20, Gfx.mulAlpha(DIM, a));
                toggle(g, rx + rw - 10 - 28, y + 8, s, a);
                if (visible(y, 30)) hit(rx, y, rw, 30, Modules::toggleGradient);

                // preview strip
                int sx0 = rx + 10;
                int sw = rw - 20;
                for (int i = 0; i < sw; i += 2) {
                    int col = Modules.gradient() ? Gfx.lerpColor(Modules.accent(), Modules.accent2(), i / (float) sw) : Modules.accent();
                    g.fill(sx0 + i, y + 36, sx0 + Math.min(sw, i + 2), y + 40, Gfx.mulAlpha(col, a));
                }
                // second colour presets
                Gfx.text(g, font, "Second", rx + 10, y + 52, Gfx.mulAlpha(DIM, a));
                int n = Modules.ACCENT_COLORS.length;
                for (int i = 0; i < n; i++) {
                    int sx = rx + 58 + i * 28;
                    int sy = y + 50;
                    int col = Modules.ACCENT_COLORS[i];
                    Gfx.roundRect(g, sx, sy, 20, 12, 4, Gfx.mulAlpha(col, a * (Modules.gradient() ? 1f : 0.5f)));
                    if ((Modules.accent2() & 0xFFFFFF) == (col & 0xFFFFFF)) {
                        Gfx.roundOutline(g, sx - 2, sy - 2, 24, 16, 6, Gfx.mulAlpha(Style.WHITE, a));
                    }
                    final int idx = i;
                    if (visible(sy, 12)) hit(sx - 2, sy - 2, 24, 16, () -> Modules.setAccent2(Modules.ACCENT_COLORS[idx]));
                }
            }
            y += h + GAP;
        }

        // 5. opacity
        {
            float a = rowAlpha(pageT, row++);
            int h = 52;
            if (card(g, rx, y, rw, h, a, false)) {
                Gfx.text(g, font, "HUD opacity", rx + 10, y + 8, Gfx.mulAlpha(TEXT, a));
                String pct = Math.round(Modules.opacity() * 100f) + "%";
                Gfx.text(g, font, pct, rx + rw - 10 - Gfx.width(font, pct), y + 8, Gfx.mulAlpha(DIM, a));
                float f = (Modules.opacity() - Modules.MIN_OPACITY) / (1f - Modules.MIN_OPACITY);
                sliderBar(g, rx + 10, rx + rw - 10, y + 35, f, a, Style.accent(),
                        v -> Modules.setOpacity(Modules.MIN_OPACITY + (float) v * (1f - Modules.MIN_OPACITY)), Modules::save);
            }
            y += h + GAP;
        }

        // 6. name badge
        {
            float a = rowAlpha(pageT, row++);
            int h = 40;
            boolean hov = overMouse(rx, y, rw, h);
            if (card(g, rx, y, rw, h, a, hov)) {
                Gfx.text(g, font, "Cat on name tag", rx + 10, y + 8, Gfx.mulAlpha(TEXT, a));
                Gfx.text(g, font, "Blinking cat next to your name", rx + 10, y + 21, Gfx.mulAlpha(DIM, a));
                float s = badgeOn.update(Modules.nameBadge() ? 1f : 0f, dt, 12f);
                toggle(g, rx + rw - 10 - 28, y + (h - 12) / 2, s, a);
                if (visible(y, h)) hit(rx, y, rw, h, Modules::toggleNameBadge);
            }
            y += h + GAP;
        }

        // 7. saved themes
        {
            float a = rowAlpha(pageT, row++);
            List<Modules.Theme> themes = Modules.themes();
            int perRow = Math.max(1, (rw - 20) / 94);
            int chipRows = (themes.size() + perRow - 1) / perRow;
            int h = 44 + chipRows * 22;
            if (card(g, rx, y, rw, h, a, false)) {
                Gfx.text(g, font, "Saved themes", rx + 10, y + 8, Gfx.mulAlpha(TEXT, a));
                int bx = rx + rw - 10;
                String lab = "Save current";
                int bw = Gfx.width(font, lab) + 14;
                smallButton(g, bx - bw, y + 5, lab, true, a, Modules::saveTheme);
                if (themes.isEmpty()) {
                    Gfx.text(g, font, "Nothing saved yet. Set colors, then Save current.", rx + 10, y + 28, Gfx.mulAlpha(DIM, a));
                }
                for (int i = 0; i < themes.size(); i++) {
                    Modules.Theme th = themes.get(i);
                    int cx = rx + 10 + (i % perRow) * 94;
                    int cy = y + 28 + (i / perRow) * 22;
                    boolean hov = overMouse(cx, cy, 88, 18);
                    Gfx.roundRect(g, cx, cy, 88, 18, 4, Gfx.mulAlpha(hov ? 0xFF26262C : 0xFF17171B, a));
                    Gfx.roundOutline(g, cx, cy, 88, 18, 4, Gfx.mulAlpha(CARD_EDGE, a));
                    int c1 = th.accentIdx < 0 ? th.accentCustom : Modules.ACCENT_COLORS[Math.min(th.accentIdx, Modules.ACCENT_COLORS.length - 1)];
                    int c2 = th.gradient ? th.accent2 : c1;
                    for (int k = 0; k < 10; k++) {
                        g.fill(cx + 5 + k, cy + 5, cx + 6 + k, cy + 13, Gfx.mulAlpha(Gfx.lerpColor(c1, c2, k / 9f), a));
                    }
                    Gfx.text(g, font, Gfx.fit(font, th.name, 44), cx + 20, cy + 5, Gfx.mulAlpha(TEXT, a));
                    Gfx.text(g, font, "x", cx + 88 - 10, cy + 5, Gfx.mulAlpha(DIM, a));
                    if (visible(cy, 18)) {
                        hit(cx + 76, cy, 12, 18, () -> Modules.deleteTheme(th));
                        hit(cx, cy, 76, 18, () -> Modules.applyTheme(th));
                    }
                }
            }
            y += h;
        }
        return y;
    }

    private static float rowAlpha(float pageT, int row) {
        return Gfx.easeOutCubic(Gfx.clamp01((pageT - row * 0.07f) / 0.7f));
    }

    // ----- Profiles page -----

    private String currentServerIp() {
        try {
            ServerData sd = this.minecraft.getCurrentServer();
            return sd == null ? "" : sd.ip;
        } catch (Throwable t) {
            return "";
        }
    }

    private int renderProfiles(GuiGraphicsExtractor g, int top, float pageT) {
        int rx = rowX();
        int rw = rowW();
        int y = top;
        int row = 0;

        // active profile + actions
        {
            float a = rowAlpha(pageT, row++);
            int h = 82;
            if (card(g, rx, y, rw, h, a, false)) {
                Gfx.text(g, font, "Active profile", rx + 10, y + 8, Gfx.mulAlpha(DIM, a));
                Gfx.text(g, font, Gfx.fit(font, Modules.profileName(), rw - 120), rx + 10 + Gfx.width(font, "Active profile") + 8,
                        y + 8, Gfx.mulAlpha(TEXT, a));
                Gfx.text(g, font, "A profile keeps your HUD layout + theme (a HUD layout = a profile).", rx + 10, y + 21, Gfx.mulAlpha(DIM, a));
                int bx = rx + 10;
                int by = y + 38;
                bx += smallButton(g, bx, by, "Save as new", true, a, () -> {
                    Modules.saveProfile(Modules.newProfileName());
                    message = "Saved.";
                }) + 4;
                bx += smallButton(g, bx, by, "Save over active", true, a, () -> {
                    Modules.saveProfile(Modules.profileName());
                    message = "Saved.";
                }) + 4;
                smallButton(g, bx, by, "Reset all settings", true, a, () -> {
                    Modules.resetEverything();
                    message = "Back to defaults.";
                });
                bx = rx + 10;
                by = y + 58;
                bx += smallButton(g, bx, by, "Backup now", true, a, () -> {
                    int n = Modules.backup();
                    message = "Backed up " + n + " file(s) to config/blackcat/backups/";
                }) + 4;
                String latest = Modules.latestBackup();
                smallButton(g, bx, by, latest == null ? "Restore (no backup)" : "Restore " + latest, latest != null, a,
                        () -> message = Modules.restoreLatest());
            }
            y += h + GAP;
        }

        // one row per saved profile (favourites first), with a small preview of its theme
        List<Modules.ProfileInfo> infos = Modules.profileInfos();
        String ip = currentServerIp();
        for (Modules.ProfileInfo info : infos) {
            float a = rowAlpha(pageT, row++);
            int h = 52;
            String name = info.name();
            boolean active = name.equals(Modules.profileName());
            if (card(g, rx, y, rw, h, a, false)) {
                if (active) Gfx.roundOutline(g, rx, y, rw, h, 6, Gfx.mulAlpha(Style.accent(), a * 0.8f));

                diamond(g, rx + 16, y + 13, info.favorite() ? Style.accent() : 0xFF3A3A42, a, info.favorite());
                if (visible(y, 24)) hit(rx + 4, y + 2, 24, 22, () -> Modules.toggleFavProfile(name));
                Gfx.text(g, font, Gfx.fit(font, name, 150), rx + 28, y + 8, Gfx.mulAlpha(TEXT, a));

                // preview: accent swatch (graded if gradient), look and module count
                int pvx = rx + rw - 10 - 90;
                for (int k = 0; k < 28; k++) {
                    int col = info.gradient() ? Gfx.lerpColor(info.accent(), info.accent2(), k / 27f) : info.accent();
                    g.fill(pvx + k, y + 8, pvx + k + 1, y + 16, Gfx.mulAlpha(info.look() == Style.LOOK_MONO ? 0xFFD0D0D4 : col, a));
                }
                Gfx.text(g, font, Style.LOOK_NAMES[Math.min(Style.LOOK_NAMES.length - 1, info.look())].substring(0, 1) + " | " + info.enabledCount() + " mods",
                        pvx + 34, y + 8, Gfx.mulAlpha(DIM, a));

                String server = info.server();
                Gfx.text(g, font, server.isEmpty() ? "auto-switch: off" : "auto: " + Gfx.fit(font, server, 150),
                        rx + 28, y + 20, Gfx.mulAlpha(DIM, a));

                int bx = rx + 10;
                int by = y + 31;
                bx += smallButton(g, bx, by, "Load", true, a, () -> message = Modules.loadProfile(name) ? "Loaded " + name : "Could not load.") + 4;
                bx += smallButton(g, bx, by, "Duplicate", true, a, () -> {
                    String copy = Modules.duplicateProfile(name);
                    message = copy == null ? "Could not duplicate." : "Created " + copy;
                }) + 4;
                bx += smallButton(g, bx, by, "Export", true, a, () ->
                        message = Modules.exportProfile(name) ? "Exported to config/blackcat/export/" + name + ".json" : "Export failed.") + 4;
                String auto = server.isEmpty() ? "Auto: this server" : "Auto: off";
                bx += smallButton(g, bx, by, auto, !ip.isEmpty() || !server.isEmpty(), a, () -> {
                    Modules.setProfileServer(name, server.isEmpty() ? ip : "");
                    message = server.isEmpty() ? "Auto-switch on for " + ip : "Auto-switch off.";
                }) + 4;
                smallButton(g, bx, by, "Delete", true, a, () -> Modules.deleteProfile(name));
            }
            y += h + 6;
        }
        if (infos.isEmpty()) {
            Gfx.text(g, font, "No profiles yet. Press Save as new.", rx + 4, y + 2, Gfx.mulAlpha(DIM, rowAlpha(pageT, row++)));
            y += 16;
        }
        y += GAP - 6;

        // import
        {
            float a = rowAlpha(pageT, row++);
            int h = 50;
            if (card(g, rx, y, rw, h, a, false)) {
                Gfx.text(g, font, "Import / export", rx + 10, y + 8, Gfx.mulAlpha(TEXT, a));
                Gfx.text(g, font, "Drop .json files in config/blackcat/import/ then press Import (they are checked first).", rx + 10, y + 21, Gfx.mulAlpha(DIM, a));
                smallButton(g, rx + 10, y + 31, "Import", true, a, () -> message = Modules.importProfiles());
            }
            y += h;
        }
        if (!message.isEmpty()) {
            y += 6;
            Gfx.text(g, font, Gfx.fit(font, message, rw - 4), rx + 4, y, Gfx.mulAlpha(Style.accent(), rowAlpha(pageT, row)));
            y += 12;
        }
        return y;
    }

    // ----- Keys page -----

    private int renderKeys(GuiGraphicsExtractor g, int top, float pageT) {
        int rx = rowX();
        int rw = rowW();
        int y = top;
        int row = 0;

        {
            float a = rowAlpha(pageT, row++);
            Gfx.text(g, font, "Tap a key, then press the new one. Esc cancels, Delete clears.", rx + 2, y, Gfx.mulAlpha(DIM, a));
            y += 14;
        }
        for (KeyMapping km : BlackCatClient.keys()) {
            float a = rowAlpha(pageT, row++);
            int h = 30;
            boolean wait = km == listening;
            boolean hov = overMouse(rx, y, rw, h);
            if (card(g, rx, y, rw, h, a, hov)) {
                if (wait) Gfx.roundOutline(g, rx, y, rw, h, 6, Gfx.mulAlpha(Style.accent(), a));
                String name = Component.translatable(km.getName()).getString();
                Gfx.text(g, font, name, rx + 10, conflictWith(km) != null ? y + 6 : y + 11, Gfx.mulAlpha(TEXT, a));
                String clash = wait ? null : conflictWith(km);
                String key = wait ? "press a key..." : km.getTranslatedKeyMessage().getString();
                if (clash != null) {
                    Gfx.text(g, font, "conflict: " + Gfx.fit(font, clash, 120), rx + 10, y + 20, Gfx.mulAlpha(Style.RED, a));
                }
                int kw = Gfx.width(font, key) + 16;
                int kx = rx + rw - 10 - kw;
                Gfx.roundRect(g, kx, y + 6, kw, 18, 4, Gfx.mulAlpha(wait ? Style.accent() : 0xFF1C1C21, a));
                Gfx.text(g, font, key, kx + 8, y + 11, Gfx.mulAlpha(wait ? 0xFF0B0B0D : Style.WHITE, a));
                if (visible(y, h)) hit(rx, y, rw, h, () -> listening = wait ? null : km);
            }
            y += h + 6;
        }
        if (!message.isEmpty()) {
            Gfx.text(g, font, Gfx.fit(font, message, rw - 4), rx + 4, y + 2, Gfx.mulAlpha(Style.accent(), rowAlpha(pageT, row)));
            y += 14;
        }
        return y;
    }

    /** Name of another key binding on the same key, or null. */
    private String conflictWith(KeyMapping km) {
        try {
            if (km.isUnbound()) return null;
            for (KeyMapping other : this.minecraft.options.keyMappings) {
                if (other != km && km.same(other)) return Component.translatable(other.getName()).getString();
            }
        } catch (Throwable ignored) {
            // conflict hints are optional
        }
        return null;
    }

    // ---------- input ----------

    @Override
    public boolean charTyped(net.minecraft.client.input.CharacterEvent event) {
        if (searchFocus && tab == 0 && search.length() < 24) {
            search += event.codepointAsString();
            scrollTarget = 0f;
            return true;
        }
        return super.charTyped(event);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (searchFocus && listening == null) {
            int code = InputConstants.getKey(event).getValue();
            if (event.isEscape()) {
                searchFocus = false;
                return true;
            }
            if (code == GLFW.GLFW_KEY_BACKSPACE) {
                if (!search.isEmpty()) search = search.substring(0, search.length() - 1);
                return true;
            }
            if (code == GLFW.GLFW_KEY_ENTER || code == GLFW.GLFW_KEY_KP_ENTER) {
                searchFocus = false;
                return true;
            }
        }
        if (listening != null) {
            if (!event.isEscape()) {
                InputConstants.Key newKey = InputConstants.getKey(event);
                int code = newKey.getValue();
                // Delete / Backspace clears the binding; anything else becomes the new key
                boolean clear = code == GLFW.GLFW_KEY_DELETE || code == GLFW.GLFW_KEY_BACKSPACE;
                listening.setKey(clear ? InputConstants.UNKNOWN : newKey);
                KeyMapping.resetMapping();
                this.minecraft.options.save();
                String other = conflictWith(listening);
                message = clear ? "Cleared." : other == null ? "" : "Heads up: also used by " + other;
            }
            listening = null;
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scrollTarget -= (float) scrollY * 30f;
        scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget));
        return true;
    }

    private Hit hitAt(double mx, double my) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.contains(mx, my)) return h;
        }
        return null;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        dragTotal = 0f;
        dragging = false;
        slider = null;
        if (closing) return false;
        Hit h = hitAt(lastMouseX, lastMouseY);
        if (h != null && h.drag != null) slider = h; // grabbing a slider, not scrolling the page
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double deltaX, double deltaY) {
        if (slider != null) return true;
        dragTotal += (float) Math.abs(deltaY);
        if (dragTotal > 4f) dragging = true;
        if (dragging) {
            scrollTarget -= (float) deltaY;
            scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget));
        }
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (slider != null) {
            Hit s = slider;
            slider = null;
            if (s.release != null) s.release.run();
            return true;
        }
        boolean wasDrag = dragging;
        dragging = false;
        if (closing || wasDrag) return true;

        // a clean tap/click: act on whatever is under the last known pointer position
        // (works for mouse and for touch taps on Pojav)
        searchFocus = false;
        Hit h = hitAt(lastMouseX, lastMouseY);
        if (h != null && h.click != null) {
            h.click.run();
            return true;
        }
        return super.mouseReleased(event);
    }
}
