package studio.blackcat.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.Collection;
import java.util.Set;

/**
 * Checks and cleans profile files (imports, restores). Pure logic, no game classes, so it can be tested on its own.
 * Anything unknown or out of range is dropped or clamped; a file that is not a profile at all is rejected.
 */
public final class ProfileCodec {
    private ProfileCodec() {}

    public static final int MAX_BYTES = 64 * 1024;
    public static final int CURRENT_CFG = 6;

    /** Either a cleaned profile or the reason it was rejected. */
    public record Result(JsonObject profile, String error, int dropped) {
        public boolean ok() {
            return profile != null;
        }
    }

    public static Result validate(String text, Set<String> moduleNames) {
        if (text == null || text.isBlank()) return fail("empty file");
        if (text.length() > MAX_BYTES) return fail("file is too big (over 64 KB)");
        JsonElement root;
        try {
            root = JsonParser.parseString(text);
        } catch (Exception e) {
            return fail("not valid JSON");
        }
        if (!root.isJsonObject()) return fail("not a profile (expected a JSON object)");
        JsonObject in = root.getAsJsonObject();
        if (!in.has("enabled") && !in.has("pos") && !in.has("accent") && !in.has("opts")) {
            return fail("does not look like a Black Cat profile");
        }

        int cfg = intOr(in, "cfg", 1);
        if (cfg > CURRENT_CFG) return fail("made by a newer version (cfg " + cfg + ")");

        int[] dropped = {0};
        JsonObject out = new JsonObject();
        out.addProperty("cfg", CURRENT_CFG);

        // a missing or damaged module list keeps the default modules instead of switching everything off
        if (in.has("enabled") && in.get("enabled").isJsonArray()) {
            JsonArray enabled = new JsonArray();
            for (JsonElement e : in.getAsJsonArray("enabled")) {
                if (e.isJsonPrimitive() && moduleNames.contains(e.getAsString())) enabled.add(e.getAsString());
                else dropped[0]++;
            }
            out.add("enabled", enabled);
        }

        JsonObject pos = new JsonObject();
        if (in.has("pos") && in.get("pos").isJsonObject()) {
            for (var e : in.getAsJsonObject("pos").entrySet()) {
                try {
                    JsonArray a = e.getValue().getAsJsonArray();
                    float x = a.get(0).getAsFloat();
                    float y = a.get(1).getAsFloat();
                    if (!moduleNames.contains(e.getKey()) || Float.isNaN(x) || Float.isNaN(y)) throw new IllegalArgumentException();
                    JsonArray n = new JsonArray();
                    n.add(clamp(x, 0f, 1f));
                    n.add(clamp(y, 0f, 1f));
                    pos.add(e.getKey(), n);
                } catch (Exception ex) {
                    dropped[0]++;
                }
            }
        }
        out.add("pos", pos);

        JsonObject opts = new JsonObject();
        if (in.has("opts") && in.get("opts").isJsonObject()) {
            for (var e : in.getAsJsonObject("opts").entrySet()) {
                try {
                    if (!moduleNames.contains(e.getKey())) throw new IllegalArgumentException();
                    JsonObject j = e.getValue().getAsJsonObject();
                    JsonObject n = new JsonObject();
                    n.addProperty("scale", clamp(j.get("scale").getAsFloat(), 0.5f, 2.5f));
                    n.addProperty("bg", j.get("bg").getAsBoolean());
                    float op = j.get("opacity").getAsFloat();
                    n.addProperty("opacity", op < 0f ? -1f : clamp(op, 0.1f, 1f));
                    n.addProperty("accent", j.get("accent").getAsInt());
                    if (j.has("grad")) n.addProperty("grad", Math.max(0, Math.min(2, j.get("grad").getAsInt())));
                    if (j.has("accent2")) n.addProperty("accent2", j.get("accent2").getAsInt());
                    opts.add(e.getKey(), n);
                } catch (Exception ex) {
                    dropped[0]++;
                }
            }
        }
        out.add("opts", opts);

        out.addProperty("accent", Math.max(-1, Math.min(5, intOr(in, "accent", 0))));
        out.addProperty("accentCustom", intOr(in, "accentCustom", 0xFFF2F2F5) | 0xFF000000);
        out.addProperty("gradient", boolOr(in, "gradient", false));
        out.addProperty("accent2", intOr(in, "accent2", 0xFF8FD3FF) | 0xFF000000);
        out.addProperty("opacity", clamp(floatOr(in, "opacity", 0.85f), 0.3f, 1f));
        out.addProperty("badge", boolOr(in, "badge", true));
        out.addProperty("look", Math.max(0, Math.min(4, intOr(in, "look", 0))));
        return new Result(out, null, dropped[0]);
    }

    /** "Name", or "Name (2)", "Name (3)" ... if taken (case-insensitive). */
    public static String uniqueName(String base, Collection<String> existing) {
        String name = safeName(base);
        if (!contains(existing, name)) return name;
        int i = 2;
        while (contains(existing, name + " (" + i + ")")) i++;
        return name + " (" + i + ")";
    }

    public static String safeName(String n) {
        String s = n == null ? "" : n.replaceAll("[^A-Za-z0-9 _.()-]", "").replaceAll("^[. ]+", "").trim();
        if (s.length() > 32) s = s.substring(0, 32).trim();
        return s.isEmpty() ? "Profile" : s;
    }

    private static boolean contains(Collection<String> c, String s) {
        for (String x : c) if (x.equalsIgnoreCase(s)) return true;
        return false;
    }

    private static Result fail(String why) {
        return new Result(null, why, 0);
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static int intOr(JsonObject o, String k, int d) {
        try {
            return o.has(k) ? o.get(k).getAsInt() : d;
        } catch (Exception e) {
            return d;
        }
    }

    private static float floatOr(JsonObject o, String k, float d) {
        try {
            return o.has(k) ? o.get(k).getAsFloat() : d;
        } catch (Exception e) {
            return d;
        }
    }

    private static boolean boolOr(JsonObject o, String k, boolean d) {
        try {
            return o.has(k) ? o.get(k).getAsBoolean() : d;
        } catch (Exception e) {
            return d;
        }
    }
}
