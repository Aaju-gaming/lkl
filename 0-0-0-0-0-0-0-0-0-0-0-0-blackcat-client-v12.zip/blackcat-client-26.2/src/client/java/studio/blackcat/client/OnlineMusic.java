package studio.blackcat.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Searches free, legal music sites and downloads a track into the cache so it can be played in game:
 * the Internet Archive (no account needed) and Jamendo (Creative Commons music; needs a free client id).
 * Only Ogg files are used, because that is what the in-game player can decode.
 */
public final class OnlineMusic {
    private OnlineMusic() {}

    public static final String[] SOURCES = {"Internet Archive", "Jamendo"};

    /** One search result. For the Archive, url is empty until the track is fetched (an item can hold many files). */
    public record Track(int source, String id, String title, String artist, String url) {}

    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(8))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();
    private static final long MAX_BYTES = 120L * 1024 * 1024;

    private static HttpRequest.Builder req(String url) {
        return HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(25))
                .header("User-Agent", "BlackCatClient/0.11 (Minecraft mod)");
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    // ---------- search ----------

    public static void search(int source, String query, Consumer<List<Track>> done, Consumer<String> failed) {
        String q = query == null ? "" : query.trim();
        if (q.isEmpty()) {
            done.accept(List.of());
            return;
        }
        String url;
        if (source == 0) {
            url = "https://archive.org/advancedsearch.php?q=" + enc("(" + q + ") AND mediatype:audio AND format:\"Ogg Vorbis\"")
                    + "&fl[]=identifier&fl[]=title&fl[]=creator&rows=15&output=json";
        } else {
            String id = Modules.text("jamendo_id").trim();
            if (id.isEmpty()) {
                failed.accept("Jamendo needs a free client id (see Music page)");
                return;
            }
            url = "https://api.jamendo.com/v3.0/tracks/?client_id=" + enc(id) + "&format=json&limit=15&audioformat=ogg&search=" + enc(q);
        }
        HTTP.sendAsync(req(url).GET().build(), HttpResponse.BodyHandlers.ofString()).whenComplete((resp, err) -> {
            if (err != null || resp == null || resp.statusCode() != 200) {
                failed.accept("Search failed (offline?)");
                return;
            }
            try {
                done.accept(source == 0 ? parseArchiveSearch(resp.body()) : parseJamendo(resp.body()));
            } catch (Throwable t) {
                failed.accept("Could not read the search results");
            }
        });
    }

    static String firstString(JsonElement e) {
        if (e == null || e.isJsonNull()) return "";
        if (e.isJsonArray()) return e.getAsJsonArray().isEmpty() ? "" : firstString(e.getAsJsonArray().get(0));
        return e.getAsString();
    }

    static List<Track> parseArchiveSearch(String json) {
        List<Track> out = new ArrayList<>();
        JsonArray docs = JsonParser.parseString(json).getAsJsonObject().getAsJsonObject("response").getAsJsonArray("docs");
        for (JsonElement el : docs) {
            JsonObject d = el.getAsJsonObject();
            String id = firstString(d.get("identifier"));
            if (id.isEmpty()) continue;
            String title = firstString(d.get("title"));
            out.add(new Track(0, id, title.isEmpty() ? id : title, firstString(d.get("creator")), ""));
        }
        return out;
    }

    static List<Track> parseJamendo(String json) {
        List<Track> out = new ArrayList<>();
        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        if (!root.has("results")) return out;
        for (JsonElement el : root.getAsJsonArray("results")) {
            JsonObject d = el.getAsJsonObject();
            String url = firstString(d.get("audio"));
            if (url.isEmpty()) continue;
            out.add(new Track(1, firstString(d.get("id")), firstString(d.get("name")), firstString(d.get("artist_name")), url));
        }
        return out;
    }

    /** Picks the first Ogg Vorbis file (not too big) of an Internet Archive item, or "" if there is none. */
    static String pickArchiveOgg(String metadataJson) {
        JsonObject root = JsonParser.parseString(metadataJson).getAsJsonObject();
        if (!root.has("files")) return "";
        for (JsonElement el : root.getAsJsonArray("files")) {
            JsonObject f = el.getAsJsonObject();
            String fmt = firstString(f.get("format"));
            String name = firstString(f.get("name"));
            if (!fmt.equals("Ogg Vorbis") && !name.toLowerCase(java.util.Locale.ROOT).endsWith(".ogg")) continue;
            long size = 0;
            try {
                size = Long.parseLong(firstString(f.get("size")));
            } catch (NumberFormatException ignored) {
                // unknown size: allow
            }
            if (size > MAX_BYTES) continue;
            return name;
        }
        return "";
    }

    // ---------- download ----------

    static String safeName(String s) {
        String t = s.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", " ").replaceAll("\\s+", " ").trim();
        if (t.length() > 70) t = t.substring(0, 70).trim();
        while (t.startsWith(".")) t = t.substring(1);
        return t.isEmpty() ? "track" : t;
    }

    /** Makes sure the track is in config/blackcat/music/online, then calls ready with the file. */
    public static void fetch(Track t, Consumer<Path> ready, Consumer<String> failed) {
        String base = t.artist().isEmpty() ? safeName(t.title()) : safeName(t.artist() + " - " + t.title());
        Path out = Modules.dir("music").resolve("online").resolve(base + ".ogg");
        try {
            Files.createDirectories(out.getParent());
        } catch (Exception e) {
            failed.accept("Could not create the cache folder");
            return;
        }
        if (Files.isRegularFile(out)) {
            ready.accept(out);
            return;
        }
        Thread th = new Thread(() -> {
            try {
                String url = t.url();
                if (url.isEmpty()) {
                    HttpResponse<String> meta = HTTP.send(req("https://archive.org/metadata/" + enc(t.id())).GET().build(),
                            HttpResponse.BodyHandlers.ofString());
                    String file = meta.statusCode() == 200 ? pickArchiveOgg(meta.body()) : "";
                    if (file.isEmpty()) {
                        failed.accept("No playable Ogg file in that item");
                        return;
                    }
                    url = "https://archive.org/download/" + enc(t.id()) + "/" + enc(file).replace("+", "%20");
                }
                HttpResponse<InputStream> r = HTTP.send(req(url).GET().build(), HttpResponse.BodyHandlers.ofInputStream());
                if (r.statusCode() != 200) {
                    failed.accept("Download failed (" + r.statusCode() + ")");
                    return;
                }
                long len = r.headers().firstValueAsLong("Content-Length").orElse(-1);
                if (len > MAX_BYTES) {
                    failed.accept("That file is too large");
                    return;
                }
                Path tmp = out.resolveSibling(base + ".part");
                try (InputStream in = r.body()) {
                    Files.copy(in, tmp, StandardCopyOption.REPLACE_EXISTING);
                }
                if (Files.size(tmp) > MAX_BYTES) {
                    Files.deleteIfExists(tmp);
                    failed.accept("That file is too large");
                    return;
                }
                Files.move(tmp, out, StandardCopyOption.REPLACE_EXISTING);
                ready.accept(out);
            } catch (Throwable e) {
                failed.accept("Download failed (offline?)");
            }
        }, "blackcat-music-download");
        th.setDaemon(true);
        th.start();
    }
}
