package studio.blackcat.client;

import org.lwjgl.openal.AL10;
import org.lwjgl.openal.AL11;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.system.libc.LibCStdlib;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Plays an .ogg file through the game's own OpenAL (the same audio system Minecraft uses, so it also
 * works on PojavLauncher). Decoding happens on a background thread; every OpenAL call happens on the
 * game thread (poll / control methods), and everything is guarded so a sound problem can never crash.
 */
final class AudioPlayer {
    private AudioPlayer() {}

    // ready-to-upload decode result (handed from the decode thread to the game thread)
    private static volatile ShortBuffer pendingPcm;
    private static volatile int pendingChannels;
    private static volatile int pendingRate;
    private static volatile int pendingGen = -1;
    private static volatile String error;

    private static int buffer;
    private static int source;
    private static double durationSec;
    private static boolean pausedByUser;

    static String takeError() {
        String e = error;
        error = null;
        return e;
    }

    /** Starts decoding in the background. The track begins playing when poll() picks it up. */
    static void load(Path file, int gen) {
        Thread t = new Thread(() -> {
            try {
                byte[] bytes = Files.readAllBytes(file);
                ByteBuffer mem = MemoryUtil.memAlloc(bytes.length);
                try {
                    mem.put(bytes).flip();
                    try (MemoryStack stack = MemoryStack.stackPush()) {
                        IntBuffer ch = stack.mallocInt(1);
                        IntBuffer sr = stack.mallocInt(1);
                        ShortBuffer pcm = STBVorbis.stb_vorbis_decode_memory(mem, ch, sr);
                        if (pcm == null) {
                            error = "Could not read that file (only .ogg is supported)";
                            return;
                        }
                        ShortBuffer old = pendingPcm;
                        pendingChannels = ch.get(0);
                        pendingRate = sr.get(0);
                        pendingGen = gen;
                        pendingPcm = pcm;
                        if (old != null) LibCStdlib.free(old);
                    }
                } finally {
                    MemoryUtil.memFree(mem);
                }
            } catch (IOException e) {
                error = "Could not open the file";
            } catch (Throwable e) {
                error = "Audio decode failed: " + e.getClass().getSimpleName();
            }
        }, "blackcat-audio-decode");
        t.setDaemon(true);
        t.start();
    }

    /** Game thread: starts playback when a decoded track is waiting. Returns the generation started, or -1. */
    static int poll(int currentGen, float volume) {
        try {
            ShortBuffer pcm = pendingPcm;
            if (pcm != null) {
                pendingPcm = null;
                int gen = pendingGen;
                if (gen != currentGen) {
                    LibCStdlib.free(pcm);
                } else {
                    stop();
                    buffer = AL10.alGenBuffers();
                    AL10.alBufferData(buffer, pendingChannels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16, pcm, pendingRate);
                    durationSec = (double) pcm.limit() / pendingChannels / pendingRate;
                    LibCStdlib.free(pcm);
                    source = AL10.alGenSources();
                    AL10.alSourcei(source, AL10.AL_BUFFER, buffer);
                    AL10.alSourcei(source, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
                    AL10.alSourcef(source, AL10.AL_GAIN, volume);
                    AL10.alSourcePlay(source);
                    pausedByUser = false;
                    if (AL10.alGetError() != AL10.AL_NO_ERROR) {
                        stop();
                        error = "The sound system refused the track";
                        return -1;
                    }
                    return gen;
                }
            }
            if (source != 0) AL10.alSourcef(source, AL10.AL_GAIN, volume);
        } catch (Throwable t) {
            stop();
            error = "Audio error: " + t.getClass().getSimpleName();
        }
        return -1;
    }

    static boolean active() {
        return source != 0;
    }

    static double positionSec() {
        try {
            return source == 0 ? 0 : AL10.alGetSourcef(source, AL11.AL_SEC_OFFSET);
        } catch (Throwable t) {
            return 0;
        }
    }

    static double durationSec() {
        return durationSec;
    }

    static boolean finished() {
        try {
            return source != 0 && !pausedByUser && AL10.alGetSourcei(source, AL10.AL_SOURCE_STATE) == AL10.AL_STOPPED;
        } catch (Throwable t) {
            return false;
        }
    }

    static void pause() {
        try {
            if (source != 0) {
                AL10.alSourcePause(source);
                pausedByUser = true;
            }
        } catch (Throwable ignored) {
            // ignore
        }
    }

    static void resume() {
        try {
            if (source != 0) {
                AL10.alSourcePlay(source);
                pausedByUser = false;
            }
        } catch (Throwable ignored) {
            // ignore
        }
    }

    static void seekTo(double sec) {
        try {
            if (source != 0) {
                double s = Math.max(0, Math.min(Math.max(0, durationSec - 0.1), sec));
                AL10.alSourcef(source, AL11.AL_SEC_OFFSET, (float) s);
            }
        } catch (Throwable ignored) {
            // ignore
        }
    }

    static void stop() {
        try {
            if (source != 0) {
                AL10.alSourceStop(source);
                AL10.alDeleteSources(source);
            }
            if (buffer != 0) AL10.alDeleteBuffers(buffer);
        } catch (Throwable ignored) {
            // ignore
        }
        source = 0;
        buffer = 0;
        durationSec = 0;
    }
}
