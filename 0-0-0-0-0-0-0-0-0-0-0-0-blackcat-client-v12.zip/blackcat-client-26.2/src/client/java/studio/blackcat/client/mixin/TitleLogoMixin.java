package studio.blackcat.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Removes the Minecraft logo from the title screen (TitleBrand draws ours instead).
 * Non-fatal (require = 0): if Mojang renames the method, the vanilla logo simply stays.
 */
@Mixin(targets = "net.minecraft.client.gui.components.LogoRenderer")
public abstract class TitleLogoMixin {
    @Inject(method = "extractRenderState", at = @At("HEAD"), cancellable = true, require = 0)
    private void blackcat$noVanillaLogo(CallbackInfo ci) {
        ci.cancel();
    }
}
