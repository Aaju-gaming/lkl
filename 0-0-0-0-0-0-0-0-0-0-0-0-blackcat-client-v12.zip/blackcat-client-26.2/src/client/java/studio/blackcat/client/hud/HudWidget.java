package studio.blackcat.client.hud;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import studio.blackcat.client.Modules.Module;

/** One movable HUD element. It measures itself (layout), then draws at a top-left corner. */
public abstract class HudWidget {
    public final Module module;
    public int w;
    public int h;
    /** False when there is nothing to show right now (e.g. no potion effects). */
    public boolean visible = true;

    protected HudWidget(Module module) {
        this.module = module;
    }

    /** Works out w, h and visible for this frame. */
    public abstract void layout(HudCtx c);

    public abstract void draw(GuiGraphicsExtractor g, HudCtx c, int x, int y);

    public String title() {
        return module.title;
    }
}
