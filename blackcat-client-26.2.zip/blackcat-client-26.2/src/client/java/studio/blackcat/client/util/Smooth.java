package studio.blackcat.client.util;

/** A value that glides toward a target (frame-rate independent exponential smoothing). */
public final class Smooth {
    public float value;

    public Smooth(float start) {
        this.value = start;
    }

    public float update(float target, float dt, float speed) {
        value += (target - value) * (1f - (float) Math.exp(-dt * speed));
        if (Math.abs(target - value) < 0.001f) value = target;
        return value;
    }
}
