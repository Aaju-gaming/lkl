package studio.blackcat.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.resources.Identifier;
import org.lwjgl.sdl.SDLScancode;
import studio.blackcat.client.gui.GlassMenuScreen;
import studio.blackcat.client.gui.InventoryCat;
import studio.blackcat.client.hud.HudRenderer;

public class BlackCatClient implements ClientModInitializer {
    public static final String MOD_ID = "blackcat";

    public static final Identifier CAT_WHITE_96 = id("textures/gui/cat_white_96.png");
    /** Black cat with light contour lines (384x252) - used on the inventory. */
    public static final Identifier CAT_LOGO = id("textures/gui/cat.png");
    /** "BLACK CAT STUDIOS" wordmark (960x96) - used on the loading screen. */
    public static final Identifier WORDMARK = id("textures/gui/wordmark.png");

    private static KeyMapping menuKey;

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitializeClient() {
        Modules.load();

        // Left Shift as requested. Rebind in Options > Controls if it clashes with sneak.
        KeyMapping.Category category = KeyMapping.Category.register(id("main"));
        menuKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.blackcat.menu",
                InputConstants.Type.KEYBOARD,
                SDLScancode.SDL_SCANCODE_LSHIFT,
                category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.consumeClick()) {
                if (client.screen == null && client.player != null) {
                    client.setScreen(new GlassMenuScreen());
                }
            }
        });

        HudElementRegistry.addLast(id("hud"), HudRenderer::render);

        // The napping cat on the survival inventory. Tapping it opens the menu (touch-friendly for Pojav).
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof InventoryScreen) {
                ScreenEvents.afterExtract(screen).register((s, graphics, mouseX, mouseY, tickProgress) ->
                        InventoryCat.render(graphics, client.font, s.width, s.height, mouseX, mouseY));
                ScreenMouseEvents.allowMouseClick(screen).register((s, event) -> {
                    if (InventoryCat.hit()) {
                        client.setScreen(new GlassMenuScreen());
                        return false;
                    }
                    return true;
                });
            }
        });
    }
}
