package studio.blackcat.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import studio.blackcat.client.BlackCatClient;
import studio.blackcat.client.util.Gfx;

import java.lang.reflect.Field;

/**
 * The "Black Cat Studios" loading screen: near-black backdrop, a breathing sleeping cat,
 * the wordmark and a thin shimmering bar.
 *
 * Only textures and fills are used: Minecraft's fonts are not loaded yet while this screen is up.
 * Vanilla still does the real work (reload progress, fade-out); we paint over what it draws.
 */
public final class SplashBrand {
    private SplashBrand() {}

    private static final int BG_R = 10, BG_G = 10, BG_B = 12;
    private static final int WORD_TEX_W = 960, WORD_TEX_H = 96;
    private static final int WORD_W = 300;
    private static final int WORD_H = WORD_W * WORD_TEX_H / WORD_TEX_W;
    private static final int CAT = 96;
    private static final int BAR_W = 120;

    private static long startNanos = 0L;
    private static long fadeStartNanos = 0L;
    private static Field fadeOutStartField;
    private static boolean fieldLookedUp;

    /** Reads vanilla's "fade-out started" timestamp; -1 means still loading (or the field was not found). */
    private static long vanillaFadeStart(Object overlay) {
        try {
            if (!fieldLookedUp) {
                fieldLookedUp = true;
                Field f = overlay.getClass().getDeclaredField("fadeOutStart");
                f.setAccessible(true);
                fadeOutStartField = f;
            }
            return fadeOutStartField == null ? -1L : fadeOutStartField.getLong(overlay);
        } catch (Throwable t) {
            fadeOutStartField = null;
            return -1L;
        }
    }

    public static void render(GuiGraphicsExtractor g, Object overlay) {
        Minecraft mc = Minecraft.getInstance();
        int w = g.guiWidth();
        int h = g.guiHeight();

        long now = System.nanoTime();
        if (startNanos == 0L) startNanos = now;
        float t = (now - startNanos) / 1_000_000_000f;

        // Vanilla: opaque while loading, then fades over ~1s once it is done. We mirror that.
        if (fadeStartNanos == 0L && vanillaFadeStart(overlay) != -1L) fadeStartNanos = now;
        float a = 1f;
        if (fadeStartNanos != 0L) {
            float f = (now - fadeStartNanos) / 1_000_000_000f;
            a = 1f - Gfx.clamp01(f - 1f) ; // vanilla holds for 1s, then fades for 1s
        }
        if (a <= 0.003f) return;

        // Cover vanilla's red backdrop and Mojang logo. The veil goes opaque quickly so nothing shows through.
        int veil = Math.round(255 * Gfx.clamp01(a * 3f));
        g.fill(0, 0, w, h, Gfx.argb(veil, BG_R, BG_G, BG_B));

        float appear = Gfx.easeOutCubic(t / 0.9f) * a;
        int cx = w / 2;
        int top = h / 2 - 66;

        // sleeping cat, breathing; faded in by covering it with the backdrop colour
        float breathe = 1f + 0.02f * (float) Math.sin(t * 1.8f);
        g.pose().pushMatrix();
        g.pose().translate((float) cx, (float) (top + CAT));
        g.pose().scale(breathe, breathe);
        g.pose().translate((float) -cx, (float) -(top + CAT));
        Gfx.textureFit(g, BlackCatClient.CAT_WHITE_96, cx - CAT / 2, top, CAT, CAT, 96, 96);
        Gfx.fadeCover(g, cx - CAT / 2 - 4, top - 4, CAT + 8, CAT + 8, BG_R, BG_G, BG_B, appear);
        g.pose().popMatrix();

        // wordmark
        float wordIn = Gfx.easeOutCubic((t - 0.25f) / 0.9f) * a;
        int wy = top + CAT + 14;
        Gfx.textureFit(g, BlackCatClient.WORDMARK, cx - WORD_W / 2, wy, WORD_W, WORD_H, WORD_TEX_W, WORD_TEX_H);
        Gfx.fadeCover(g, cx - WORD_W / 2 - 2, wy - 2, WORD_W + 4, WORD_H + 4, BG_R, BG_G, BG_B, wordIn);

        // thin bar with a soft highlight sliding through it
        int barY = wy + WORD_H + 16;
        int bx = cx - BAR_W / 2;
        g.fill(bx, barY, bx + BAR_W, barY + 2, Gfx.argb(Math.round(36 * appear), 255, 255, 255));
        float sweep = (t * 0.55f) % 1f;
        int segW = 36;
        int sx = bx - segW + Math.round(sweep * (BAR_W + segW));
        int x1 = Math.max(bx, sx);
        int x2 = Math.min(bx + BAR_W, sx + segW);
        if (x2 > x1) {
            g.fill(x1, barY, x2, barY + 2, Gfx.argb(Math.round(220 * appear), 255, 255, 255));
        }
    }
}
