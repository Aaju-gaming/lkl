package studio.blackcat.client.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import studio.blackcat.client.BlackCatClient;
import studio.blackcat.client.util.Gfx;

/**
 * The sleeping cat that sits on the top edge of the inventory window, breathing, with drifting "z"s.
 * Tap/click it to open the Black Cat menu (handy on Pojav, where there is no Left Shift key).
 */
public final class InventoryCat {
    private InventoryCat() {}

    private static final int TEX_W = 384;
    private static final int TEX_H = 252;
    private static final int DRAW_W = 58;
    private static final int DRAW_H = Math.round(DRAW_W * TEX_H / (float) TEX_W);

    // vanilla survival inventory window size
    private static final int PANEL_W = 176;
    private static final int PANEL_H = 166;

    private static int catX, catY;
    private static int mouseX = -1, mouseY = -1;

    public static void render(GuiGraphicsExtractor g, Font font, int screenW, int screenH, int mx, int my) {
        mouseX = mx;
        mouseY = my;
        float t = System.nanoTime() / 1_000_000_000f;
        float breathe = (float) Math.sin(t * 1.6f);

        int panelX = (screenW - PANEL_W) / 2;
        int panelY = (screenH - PANEL_H) / 2;
        catX = panelX + PANEL_W - DRAW_W - 8;
        catY = Math.max(1, panelY - DRAW_H + 4);

        boolean hover = hit();
        int y = catY - (hover ? 2 : 0);

        float sy = 1f + 0.018f * breathe;
        g.pose().pushMatrix();
        g.pose().translate(catX + DRAW_W / 2f, (float) (y + DRAW_H));
        g.pose().scale(1f, sy);
        g.pose().translate(-(catX + DRAW_W / 2f), (float) -(y + DRAW_H));
        Gfx.textureFit(g, BlackCatClient.CAT_LOGO, catX, y, DRAW_W, DRAW_H, TEX_W, TEX_H);
        g.pose().popMatrix();

        String[] z = {"z", "z", "Z"};
        for (int i = 0; i < z.length; i++) {
            float p = ((t * 0.45f) + i / 3f) % 1f;
            float alpha = (float) Math.sin(Math.PI * p);
            int zx = catX + 12 + Math.round(p * 10f) + i * 2;
            int zy = y + 8 - Math.round(p * 16f);
            Gfx.text(g, font, z[i], zx, zy, Gfx.argb(Math.round(210 * alpha), 255, 255, 255));
        }

        if (hover) {
            Gfx.text(g, font, "Black Cat menu", catX - Gfx.width(font, "Black Cat menu") - 4, y + DRAW_H / 2 - 4,
                    0xFFFFFFFF);
        }
    }

    /** True if the last known pointer position is over the cat. */
    public static boolean hit() {
        return mouseX >= catX && mouseX < catX + DRAW_W && mouseY >= catY - 2 && mouseY < catY + DRAW_H;
    }
}
