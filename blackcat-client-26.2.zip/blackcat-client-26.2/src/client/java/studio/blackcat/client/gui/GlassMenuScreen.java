package studio.blackcat.client.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import studio.blackcat.client.BlackCatClient;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.util.Gfx;
import studio.blackcat.client.util.Smooth;

/**
 * Liquid-glass module menu. Everything glides: the panel eases in, cards lift on hover,
 * toggles slide, and the whole thing fades out on close. Vanilla's background blur sits behind it.
 */
public class GlassMenuScreen extends Screen {
    private static final int PANEL_W = 360;
    private static final int PANEL_H = 214;
    private static final int PAD = 14;
    private static final int GAP = 8;
    private static final int COLS = 3;
    private static final int CARD_H = 58;

    private static final int GLASS_TOP = 0xB8222230;
    private static final int GLASS_BOTTOM = 0xB8101018;
    private static final int GLASS_EDGE = 0x33FFFFFF;
    private static final int CARD_TOP = 0x34FFFFFF;
    private static final int CARD_BOTTOM = 0x14FFFFFF;
    private static final int ACCENT = 0xFFF2F2F7;

    private final Smooth open = new Smooth(0f);
    private final Smooth[] hover = new Smooth[Module.values().length];
    private final Smooth[] on = new Smooth[Module.values().length];
    private boolean closing;
    private long lastNanos = System.nanoTime();
    private int lastMouseX = -1;
    private int lastMouseY = -1;

    public GlassMenuScreen() {
        super(Component.literal("Black Cat"));
        for (int i = 0; i < hover.length; i++) {
            hover[i] = new Smooth(0f);
            on[i] = new Smooth(Modules.isEnabled(Module.values()[i]) ? 1f : 0f);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        closing = true; // fade out first, then really close
    }

    private int panelX() {
        return (width - PANEL_W) / 2;
    }

    private int panelY() {
        return (height - PANEL_H) / 2;
    }

    private int cardW() {
        return (PANEL_W - PAD * 2 - GAP * (COLS - 1)) / COLS;
    }

    private int cardX(int i) {
        return panelX() + PAD + (i % COLS) * (cardW() + GAP);
    }

    private int cardY(int i) {
        return panelY() + 50 + (i / COLS) * (CARD_H + GAP);
    }

    private boolean over(int i, double mx, double my) {
        return mx >= cardX(i) && mx < cardX(i) + cardW() && my >= cardY(i) && my < cardY(i) + CARD_H;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        lastMouseX = mouseX;
        lastMouseY = mouseY;

        long now = System.nanoTime();
        float dt = Math.min((now - lastNanos) / 1_000_000_000f, 0.1f);
        lastNanos = now;

        open.update(closing ? 0f : 1f, dt, closing ? 14f : 9f);
        if (closing && open.value <= 0.01f) {
            super.onClose(); // vanilla: leave the screen
            return;
        }
        float t = Gfx.easeOutCubic(open.value);
        Font font = this.font;

        // soft dim on top of vanilla's blur
        g.fill(0, 0, width, height, Gfx.argb(Math.round(70 * t), 6, 6, 12));

        // panel rises and scales up slightly
        float scale = 0.94f + 0.06f * t;
        float rise = (1f - t) * 14f;
        g.pose().pushMatrix();
        g.pose().translate(width / 2f, height / 2f + rise);
        g.pose().scale(scale, scale);
        g.pose().translate(-width / 2f, -height / 2f);

        int px = panelX();
        int py = panelY();

        // glass body
        Gfx.roundRectV(g, px, py, PANEL_W, PANEL_H, 12,
                Gfx.mulAlpha(GLASS_TOP, t), Gfx.mulAlpha(GLASS_BOTTOM, t));
        // top sheen
        Gfx.roundRectV(g, px + 1, py + 1, PANEL_W - 2, 34, 11,
                Gfx.argb(Math.round(34 * t), 255, 255, 255), Gfx.argb(0, 255, 255, 255));
        Gfx.roundOutline(g, px, py, PANEL_W, PANEL_H, 12, Gfx.mulAlpha(GLASS_EDGE, t));

        // header: cat + title
        if (open.value > 0.5f) {
            Gfx.textureFit(g, BlackCatClient.CAT_WHITE_96, px + PAD, py + 10, 26, 26, 96, 96);
        }
        Gfx.text(g, font, "BLACK CAT", px + PAD + 33, py + 13, Gfx.argb(Math.round(255 * t), 255, 255, 255));
        Gfx.text(g, font, "Studios", px + PAD + 33, py + 24, Gfx.argb(Math.round(150 * t), 255, 255, 255));

        String hint = "Click a card to toggle  -  Esc to close";
        Gfx.text(g, font, hint, px + PANEL_W - PAD - Gfx.width(font, hint), py + 19,
                Gfx.argb(Math.round(110 * t), 255, 255, 255));

        // divider
        g.fill(px + PAD, py + 42, px + PANEL_W - PAD, py + 43, Gfx.argb(Math.round(28 * t), 255, 255, 255));

        // module cards
        Module[] mods = Module.values();
        for (int i = 0; i < mods.length; i++) {
            // staggered fade-in per card
            float cardT = Gfx.clamp01((open.value - i * 0.06f) / 0.7f);
            cardT = Gfx.easeOutCubic(cardT);

            boolean hov = !closing && over(i, mouseX, mouseY);
            float h = hover[i].update(hov ? 1f : 0f, dt, 14f);
            float s = on[i].update(Modules.isEnabled(mods[i]) ? 1f : 0f, dt, 12f);

            int cw = cardW();
            int cx = cardX(i);
            int cy = cardY(i) - Math.round(h * 2f) + Math.round((1f - cardT) * 8f);

            int top = Gfx.lerpColor(CARD_TOP, 0x50FFFFFF, h);
            int bottom = Gfx.lerpColor(CARD_BOTTOM, 0x26FFFFFF, h);
            top = Gfx.lerpColor(top, 0x66FFFFFF, s * 0.5f);
            bottom = Gfx.lerpColor(bottom, 0x30FFFFFF, s * 0.5f);

            Gfx.roundRectV(g, cx, cy, cw, CARD_H, 9, Gfx.mulAlpha(top, cardT), Gfx.mulAlpha(bottom, cardT));
            int edge = Gfx.lerpColor(0x26FFFFFF, 0x80FFFFFF, Math.max(h * 0.5f, s));
            Gfx.roundOutline(g, cx, cy, cw, CARD_H, 9, Gfx.mulAlpha(edge, cardT));

            Gfx.text(g, font, mods[i].title, cx + 10, cy + 10, Gfx.argb(Math.round(255 * cardT), 255, 255, 255));
            Gfx.text(g, font, mods[i].description, cx + 10, cy + 22, Gfx.argb(Math.round(125 * cardT), 255, 255, 255));

            // sliding toggle
            int tw = 28;
            int th = 12;
            int tx = cx + 10;
            int ty = cy + CARD_H - th - 9;
            int trackColor = Gfx.lerpColor(0x40FFFFFF, ACCENT, s);
            Gfx.roundRect(g, tx, ty, tw, th, 6, Gfx.mulAlpha(trackColor, cardT));
            int knobX = tx + 2 + Math.round(s * (tw - th));
            int knobColor = Gfx.lerpColor(0xFFFFFFFF, 0xFF16161E, s);
            Gfx.roundRect(g, knobX, ty + 2, th - 4, th - 4, 4, Gfx.mulAlpha(knobColor, cardT));
        }

        g.pose().popMatrix();
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (closing) return false;
        // position comes from the last rendered frame (works for mouse and for touch taps on Pojav)
        Module[] mods = Module.values();
        for (int i = 0; i < mods.length; i++) {
            if (over(i, lastMouseX, lastMouseY)) {
                Modules.toggle(mods[i]);
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }
}
