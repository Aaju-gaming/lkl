package studio.blackcat.client.mixin;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import studio.blackcat.client.gui.SplashBrand;

/**
 * Paints the Black Cat Studios loading screen over vanilla's. Targeted by name and non-fatal
 * (require = 0): if Mojang renames something, the game still starts, just with the vanilla loading screen.
 */
@Mixin(targets = "net.minecraft.client.gui.screens.LoadingOverlay")
public abstract class LoadingOverlayMixin {
    @Inject(method = "extractRenderState", at = @At("TAIL"), require = 0)
    private void blackcat$brand(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        SplashBrand.render(graphics, this);
    }
}
