package studio.blackcat.client.hud;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Counts mouse clicks over the last second. Clicks are detected as "button went from up to down"
 * between frames, so no mixin is needed.
 */
public final class Cps {
    private Cps() {}

    private static final Deque<Long> LEFT = new ArrayDeque<>();
    private static final Deque<Long> RIGHT = new ArrayDeque<>();
    private static boolean wasLeft;
    private static boolean wasRight;

    /** Call once per frame with the current button states. */
    public static void poll(boolean leftDown, boolean rightDown) {
        long now = System.currentTimeMillis();
        if (leftDown && !wasLeft) LEFT.addLast(now);
        if (rightDown && !wasRight) RIGHT.addLast(now);
        wasLeft = leftDown;
        wasRight = rightDown;
    }

    public static int left() {
        return count(LEFT);
    }

    public static int right() {
        return count(RIGHT);
    }

    private static int count(Deque<Long> q) {
        long cutoff = System.currentTimeMillis() - 1000;
        while (!q.isEmpty() && q.peekFirst() < cutoff) q.pollFirst();
        return q.size();
    }
}
