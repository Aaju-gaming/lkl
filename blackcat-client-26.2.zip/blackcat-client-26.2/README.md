# Black Cat Client (Minecraft 26.2, Fabric)

Sleek glass-style client mod by Black Cat Studios.

- Loading screen: "BLACK CAT STUDIOS" with a breathing sleeping cat.
- Inventory: a sleeping cat naps on the inventory window. Tap/click it to open the menu.
- Menu: Left Shift (rebindable). Blur, springy open/close, hover lift, sliding toggles. Esc closes.
- HUD: FPS, CPS, Keystrokes, Coordinates, Ping.

## Get the jar (no install needed)

1. Create a new empty repo on github.com (e.g. `blackcat-client`).
2. Upload everything in this folder to it (keep the `.github` folder - on the website use
   "Add file > Upload files" and drag the whole folder contents in).
3. Open the repo's **Actions** tab. The "Build jar" run starts by itself (takes ~3-5 min).
4. When it is green, open the run and download **blackcat-client-jar** at the bottom. Unzip it: the
   `.jar` inside is your mod. If the run is red, open it and copy the error text.

## Install

PC (official launcher): install Fabric Loader for 26.2, then put the jar and Fabric API (26.2) in `.minecraft/mods`.

Pojav (Android): use a 26.2 Fabric profile, put the jar + Fabric API in that profile's `mods` folder.
No Left Shift on a phone: open the inventory and tap the cat, or map an on-screen control to Left Shift
in Pojav's control editor.

## Notes

- Needs Java 25 (Minecraft 26.x requirement).
- The loading-screen and inventory pieces are written so a Mojang rename only disables that feature
  instead of crashing the game.
- Left Shift is also sneak; change either in Options > Controls.
