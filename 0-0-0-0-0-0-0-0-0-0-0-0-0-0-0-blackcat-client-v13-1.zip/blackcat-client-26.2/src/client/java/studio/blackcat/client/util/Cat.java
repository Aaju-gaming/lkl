package studio.blackcat.client.util;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

/**
 * The Black Cat logo cat, drawn as a white silhouette plus a separate layer for the eye slits.
 * Squashing the eye layer up and down makes the cat open and close its eyes.
 */
public final class Cat {
    private Cat() {}

    private static Identifier tex(String name) {
        return Identifier.fromNamespaceAndPath("blackcat", "textures/gui/" + name);
    }

    private static final Identifier BASE_L = tex("cat_base.png");
    private static final Identifier EYES_L = tex("cat_eyes.png");
    private static final Identifier BASE_S = tex("cat_small_base.png");
    private static final Identifier EYES_S = tex("cat_small_eyes.png");
    /** The "BLACK CAT" lettering from the logo. */
    public static final Identifier WORD = tex("logo_text.png");

    // texture sizes (pixels) - generated from the logo
    private static final int L_W = 601;
    private static final int L_H = 261;
    private static final int S_W = 160;
    private static final int S_H = 69;
    public static final int WORD_W = 400;
    public static final int WORD_H = 50;
    /** Vertical centre of the eyes as a fraction of the cat's height. */
    private static final float EYE_FRAC = 114.6f / 261f;

    private static final long T0 = System.nanoTime();

    /** Seconds since the game started (small numbers, so animations stay smooth). */
    public static float time() {
        return (System.nanoTime() - T0) / 1_000_000_000f;
    }

    public static int heightFor(int drawW) {
        return Math.round(drawW * L_H / (float) L_W);
    }

    private static float ease(float x) {
        x = Gfx.clamp01(x);
        return x * x * (3f - 2f * x);
    }

    /**
     * Eye openness (0 closed .. 1 open) over time: wakes up, stays open, does a quick blink,
     * then slowly drifts shut for a moment before starting again. 6 second loop.
     */
    public static float blink(float t) {
        float c = t % 6.0f;
        if (c < 0.9f) return ease(c / 0.9f);               // waking up
        if (c < 2.8f) return 1f;                           // open
        if (c < 3.0f) return 1f - (c - 2.8f) / 0.2f;       // quick blink: down
        if (c < 3.2f) return (c - 3.0f) / 0.2f;            // quick blink: up
        if (c < 4.4f) return 1f;                           // open
        if (c < 5.2f) return 1f - ease((c - 4.4f) / 0.8f); // slowly closing
        return 0f;                                         // closed
    }

    /** Draws the cat with its top-left at (x, y), drawW wide; eyeOpen is 0..1. */
    public static void draw(GuiGraphicsExtractor g, int x, int y, int drawW, float eyeOpen) {
        draw(g, x, y, drawW, eyeOpen, 0f, 0f);
    }

    /** Same, with the eyes shifted by (lookX, lookY) pixels so the cat can look at something. */
    public static void draw(GuiGraphicsExtractor g, int x, int y, int drawW, float eyeOpen, float lookX, float lookY) {
        boolean small = drawW < 90; // small icons use the small textures so they stay crisp
        Identifier base = small ? BASE_S : BASE_L;
        Identifier eyes = small ? EYES_S : EYES_L;
        int tw = small ? S_W : L_W;
        int th = small ? S_H : L_H;
        int drawH = heightFor(drawW);

        Gfx.textureFit(g, base, x, y, drawW, drawH, tw, th);

        float k = 0.12f + 0.88f * Gfx.clamp01(eyeOpen);
        float cy = y + EYE_FRAC * drawH;
        g.pose().pushMatrix();
        g.pose().translate(lookX, cy + lookY);
        g.pose().scale(1f, k);
        g.pose().translate(0f, -cy);
        Gfx.textureFit(g, eyes, x, y, drawW, drawH, tw, th);
        g.pose().popMatrix();
    }
}
