package studio.blackcat.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Music;
import studio.blackcat.client.hud.Stats;
import studio.blackcat.client.hud.Style;
import studio.blackcat.client.util.Cat;
import studio.blackcat.client.util.Gfx;

import java.lang.reflect.Constructor;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Cat OS: the Black Cat lobby. One calm column on a near-black wallpaper: the cat (whose eyes follow
 * the pointer), the wordmark and a short menu with a sliding highlight. A soft light follows the pointer,
 * dust drifts in parallax, and a quiet status line at the bottom shows the clock, the account and the song.
 */
public class CatOsScreen extends Screen {
    /** Set while the plain vanilla title screen is deliberately being shown. */
    public static boolean allowVanilla;
    private static boolean booted;
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");

    public static boolean enabled() {
        return !Modules.text("catos").equals("off");
    }

    private record Hit(int x, int y, int w, int h, Runnable click) {
        boolean contains(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private record Item(String label, Runnable action) {}

    private final List<Hit> hits = new ArrayList<>();
    private final List<Item> menu = new ArrayList<>();
    private float boot = booted ? 1f : 0f;
    private float intro;
    private float age;
    private float time;
    private long lastNanos = System.nanoTime();
    private int mx, my;
    private float smx = -1, smy = -1;
    private float alpha = 1f;
    private String message = "";
    private long messageUntil;
    private final float[] rowHover = new float[8];
    private float pillY = -1, pillA;
    private float quitHover, vanillaHover;

    public CatOsScreen() {
        super(Component.literal("Cat OS"));
        allowVanilla = false;
        menu.add(new Item("MULTIPLAYER", () -> openVanilla("Multiplayer",
                "net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen")));
        menu.add(new Item("SINGLEPLAYER", () -> openVanilla("Singleplayer",
                "net.minecraft.client.gui.screens.worldselection.SelectWorldScreen")));
        menu.add(new Item("CLIENT HUB", () -> go(new HubScreen())));
        menu.add(new Item("HUD EDITOR", () -> go(new HudEditorScreen())));
        menu.add(new Item("OPTIONS", () -> openVanilla("Options",
                "net.minecraft.client.gui.screens.options.OptionsScreen", "net.minecraft.client.gui.screens.OptionsScreen")));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false; // the lobby is the bottom of the screen stack
    }

    // ---------- opening other screens ----------

    private void go(Screen s) {
        if (this.minecraft != null) this.minecraft.gui.setScreen(s);
    }

    /** Opens a vanilla screen by class name (so a signature change can only show a message, never break the build). */
    private void openVanilla(String what, String... classNames) {
        Minecraft mc = this.minecraft;
        if (mc == null) return;
        for (String cn : classNames) {
            try {
                Class<?> k = Class.forName(cn);
                for (Constructor<?> ct : k.getConstructors()) {
                    Class<?>[] pt = ct.getParameterTypes();
                    Object[] args = new Object[pt.length];
                    boolean ok = pt.length > 0 && pt.length <= 3;
                    for (int i = 0; ok && i < pt.length; i++) {
                        if (pt[i].isAssignableFrom(this.getClass()) && Screen.class.isAssignableFrom(pt[i])) args[i] = this;
                        else if (pt[i].isInstance(mc.options)) args[i] = mc.options;
                        else if (pt[i] == boolean.class) args[i] = Boolean.FALSE;
                        else ok = false;
                    }
                    if (ok && pt[0].isAssignableFrom(this.getClass())) {
                        mc.gui.setScreen((Screen) ct.newInstance(args));
                        return;
                    }
                }
            } catch (Throwable ignored) {
                // try the next name
            }
        }
        say("Couldn't open " + what + ". Use the Vanilla menu icon instead.");
    }

    private void say(String s) {
        message = s;
        messageUntil = System.currentTimeMillis() + 4000;
    }

    // ---------- drawing helpers ----------

    private int c(int col) {
        return Gfx.mulAlpha(col, alpha);
    }

    private boolean over(int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void hit(int x, int y, int w, int h, Runnable r) {
        hits.add(new Hit(x, y, w, h, r));
    }

    private int radius() {
        return (int) Math.max(2, Math.min(10, Modules.textNum("radius", 4)));
    }

    /** A window/card in the current look. */
    private void glass(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        int r = radius() + 2;
        Gfx.roundRectV(g, x, y, w, h, r, c(Style.bgTop()), c(Style.bg()));
        Gfx.roundOutline(g, x, y, w, h, r, c(Style.edge()));
        if (Style.glass() && w > 12) g.fill(x + r, y + 1, x + w - r, y + 2, c(Style.look() == Style.LOOK_LIQUID ? 0x55FFFFFF : 0x30FFFFFF));
    }

    private void text(GuiGraphicsExtractor g, String s, int x, int y, int col) {
        Gfx.text(g, this.font, s, x, y, c(col));
    }

    private void scaledText(GuiGraphicsExtractor g, String s, int x, int y, float sc, int col) {
        g.pose().pushMatrix();
        g.pose().translate((float) x, (float) y);
        g.pose().scale(sc, sc);
        Gfx.text(g, this.font, s, 0, 0, c(col));
        g.pose().popMatrix();
    }

    // ---------- wallpaper ----------

    private void blob(GuiGraphicsExtractor g, float cx, float cy, float radius, int color, float strength) {
        for (int i = 0; i < 9; i++) {
            float f = 1f - i / 9f;
            int r = Math.round(radius * f);
            if (r < 4) break;
            Gfx.roundRect(g, Math.round(cx - r), Math.round(cy - r), r * 2, r * 2, r, Gfx.mulAlpha(color, strength * 0.07f));
        }
    }

    private void wallpaper(GuiGraphicsExtractor g) {
        String wall = Modules.text("os_wall");
        boolean mono = Style.look() == Style.LOOK_MONO;
        int top = mono ? 0xFF000000 : 0xFF030408;
        int bot = mono ? 0xFF060606 : 0xFF0A0B11;
        int bands = 20;
        for (int i = 0; i < bands; i++) {
            g.fill(0, this.height * i / bands, this.width, this.height * (i + 1) / bands, Gfx.lerpColor(top, bot, i / (float) (bands - 1)));
        }
        if (wall.equals("plain")) return;
        float w = this.width, h = this.height;
        if (!mono) {
            // one slow light drifting on its own, one that follows the pointer
            blob(g, w * (0.3f + 0.08f * (float) Math.sin(time * 0.2f)), h * (0.35f + 0.06f * (float) Math.cos(time * 0.17f)),
                    h * 0.8f, Style.accent(), 0.7f);
            blob(g, smx, smy, h * 0.55f, Style.accentAt(0.6f), 0.9f);
        } else {
            blob(g, smx, smy, h * 0.5f, 0xFFFFFFFF, 0.5f);
        }
        // dust: drifts upward, deeper motes move less when the pointer moves
        float px = (smx - w / 2f) / w, py = (smy - h / 2f) / h;
        for (int i = 0; i < 44; i++) {
            long seed = (i + 1) * 2654435761L;
            float depth = 0.3f + ((seed >>> 5) % 70) / 100f;
            float x0 = (seed >>> 3) % Math.max(1, this.width);
            float y0 = (seed >>> 13) % Math.max(1, this.height);
            float speed = 2f + depth * 5f;
            float x = ((x0 - px * 30f * depth) % w + w) % w;
            float y = ((y0 - time * speed - py * 20f * depth) % h + h) % h;
            float tw = 0.4f + 0.6f * (0.5f + 0.5f * (float) Math.sin(time * (0.6f + (i % 5) * 0.25f) + i));
            int sz = depth > 0.85f ? 2 : 1;
            g.fill(Math.round(x), Math.round(y), Math.round(x) + sz, Math.round(y) + sz, Gfx.mulAlpha(0xFFFFFFFF, 0.38f * depth * tw));
        }
        // vignette
        for (int i = 0; i < 6; i++) {
            int a = Math.round(70 * (1f - i / 6f) * (1f - i / 6f));
            int col = Gfx.argb(a, 0, 0, 0);
            g.fill(0, i * 5, this.width, i * 5 + 5, col);
            g.fill(0, this.height - i * 5 - 5, this.width, this.height - i * 5, col);
        }
    }

    // ---------- frame ----------

    /** Staggered entrance: 0..1 for section n, a little later for each one. */
    private float stage(int n) {
        return Gfx.easeOutCubic((age - n * 0.09f) / 0.55f);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min((now - lastNanos) / 1_000_000_000f, 0.1f);
        lastNanos = now;
        time += dt;
        mx = mouseX;
        my = mouseY;
        if (smx < 0) {
            smx = this.width / 2f;
            smy = this.height / 2f;
        }
        float follow = 1f - (float) Math.exp(-dt * 4.5f);
        smx += (mx - smx) * follow;
        smy += (my - smy) * follow;
        hits.clear();

        if (!booted) {
            boot = Math.min(1f, boot + dt / 1.8f);
            if (boot >= 1f) booted = true;
        }
        if (boot > 0.8f || booted) age += dt;
        alpha = 1f;

        if (boot > 0.8f || booted) {
            wallpaper(g);
            content(g, dt);
            if (System.currentTimeMillis() < messageUntil) {
                int mw = Gfx.width(this.font, message) + 20;
                glass(g, (this.width - mw) / 2, this.height - 40, mw, 18);
                text(g, message, (this.width - mw) / 2 + 10, this.height - 35, Style.WHITE);
            }
        }
        if (!booted) bootOverlay(g);
    }

    private void bootOverlay(GuiGraphicsExtractor g) {
        float fade = boot > 0.88f ? (1f - boot) / 0.12f : 1f;
        g.fill(0, 0, this.width, this.height, Gfx.mulAlpha(0xFF000000, fade));
        float eyes = Gfx.clamp01((boot - 0.12f) * 3f);
        int size = 70;
        int cx = this.width / 2;
        int cy = this.height / 2 - 24;
        Cat.draw(g, cx - size / 2, cy - Cat.heightFor(size) / 2, size, Math.min(eyes, 1f));
        int labelCol = Gfx.mulAlpha(0xFFF2F2F5, fade);
        String t = "CAT OS";
        Gfx.spaced(g, this.font, t, cx - Gfx.spacedWidth(this.font, t, 3) / 2, cy + 40, labelCol, 3);
        int bw = 90;
        g.fill(cx - bw / 2, cy + 58, cx + bw / 2, cy + 60, Gfx.mulAlpha(0xFF2A2A30, fade));
        g.fill(cx - bw / 2, cy + 58, cx - bw / 2 + Math.round(bw * Math.min(1f, boot / 0.85f)), cy + 60, Gfx.mulAlpha(Style.accent(), fade));
        Gfx.text(g, this.font, "Black Cat Studios", cx - Gfx.width(this.font, "Black Cat Studios") / 2, cy + 68, Gfx.mulAlpha(0xFF6C6C75, fade));
        hits.clear();
        hit(0, 0, this.width, this.height, () -> {
            boot = 0.9f;
            booted = true;
        });
    }

    private void content(GuiGraphicsExtractor g, float dt) {
        int rows = menu.size();
        int rowH = this.height < 250 ? 17 : 21;
        int menuH = rows * rowH;
        int avail = this.height - 34;
        int catH = Math.max(22, Math.min(56, avail - menuH - 62));
        int catW = Math.round(catH / 0.434f);
        int wordW = Math.min(170, this.width - 40);
        int wordH = Math.round(wordW * Cat.WORD_H / (float) Cat.WORD_W);
        int contentH = catH + 10 + wordH + 6 + 9 + 14 + menuH;
        int y = Math.max(20, (this.height - contentH) / 2 - 8);
        int cx = this.width / 2;
        int backR = 5, backG = 6, backB = 10;

        // cat: eyes follow the pointer
        float a = stage(0);
        int slide = Math.round((1f - a) * 10f);
        int catX = cx - catW / 2;
        float lx = Gfx.clamp01((mx - (cx - this.width / 2f)) / this.width) * 2f - 1f;
        float ly = Gfx.clamp01((my - (y + catH / 2f - this.height / 2f)) / this.height) * 2f - 1f;
        Cat.draw(g, catX, y + slide, catW, Cat.blink(time), lx * catW * 0.016f, ly * catW * 0.010f);
        Gfx.fadeCover(g, catX - 2, y + slide - 2, catW + 4, catH + 4, backR, backG, backB, a);
        y += catH + 10;

        // wordmark + tagline
        a = stage(1);
        slide = Math.round((1f - a) * 8f);
        Gfx.textureFit(g, Cat.WORD, cx - wordW / 2, y + slide, wordW, wordH, Cat.WORD_W, Cat.WORD_H);
        Gfx.fadeCover(g, cx - wordW / 2 - 2, y + slide - 2, wordW + 4, wordH + 4, backR, backG, backB, a);
        y += wordH + 6;
        alpha = stage(2);
        String tag = "BLACK CAT STUDIOS";
        Gfx.spaced(g, this.font, tag, cx - Gfx.spacedWidth(this.font, tag, 2) / 2, y + Math.round((1f - alpha) * 6f), c(0xFF6C6C75), 2);
        y += 9 + 7;
        // short accent rule that grows out from the middle
        int rule = Math.round(34 * stage(2));
        g.fill(cx - rule / 2, y, cx + rule / 2 + (rule % 2), y + 1, Gfx.mulAlpha(Style.accent(), 0.8f));
        y += 7;

        // menu with a sliding highlight
        int mw = Math.min(176, this.width - 30);
        int mxL = cx - mw / 2;
        int hovered = -1;
        for (int i = 0; i < rows; i++) {
            if (over(mxL, y + i * rowH, mw, rowH)) hovered = i;
        }
        if (hovered >= 0) {
            float target = y + hovered * rowH;
            pillY = pillY < 0 ? target : pillY + (target - pillY) * (1f - (float) Math.exp(-dt * 16f));
        }
        pillA += ((hovered >= 0 ? 1f : 0f) - pillA) * (1f - (float) Math.exp(-dt * 12f));
        if (pillY >= 0 && pillA > 0.02f) {
            alpha = stage(3);
            int py = Math.round(pillY);
            Gfx.roundRect(g, mxL, py + 1, mw, rowH - 2, radius(), Gfx.mulAlpha(0xFFFFFFFF, 0.07f * pillA));
            if (Style.glass()) g.fill(mxL + radius(), py + 1, mxL + mw - radius(), py + 2, Gfx.mulAlpha(0xFFFFFFFF, 0.12f * pillA));
            g.fill(mxL + 3, py + 4, mxL + 5, py + rowH - 4, Gfx.mulAlpha(Style.accent(), pillA));
        }
        for (int i = 0; i < rows; i++) {
            alpha = stage(3 + i);
            float tgt = i == hovered ? 1f : 0f;
            rowHover[i] += (tgt - rowHover[i]) * (1f - (float) Math.exp(-dt * 14f));
            float hv = rowHover[i];
            int ry = y + i * rowH + Math.round((1f - alpha) * 6f);
            String label = menu.get(i).label();
            int sp = 2;
            int lw = Gfx.spacedWidth(this.font, label, sp);
            int col = Gfx.lerpColor(0xFF9A9AA4, 0xFFFFFFFF, hv);
            Gfx.spaced(g, this.font, label, cx - lw / 2 + Math.round(hv * 2f), ry + (rowH - 8) / 2, c(col), sp);
            if (hv > 0.05f) text(g, ">", mxL + mw - 12 - Math.round((1f - hv) * 4f), ry + (rowH - 8) / 2, Gfx.mulAlpha(Style.accent(), hv));
            final Runnable act = menu.get(i).action();
            hit(mxL, y + i * rowH, mw, rowH, act);
        }

        status(g, dt);
    }

    private void status(GuiGraphicsExtractor g, float dt) {
        int by = this.height - 14;
        alpha = stage(8);
        // left: clock and account
        String user = "Player";
        try {
            user = this.minecraft.getUser().getName();
        } catch (Throwable ignored) {
            // keep the fallback
        }
        text(g, LocalTime.now().format(CLOCK) + "  |  " + user, 10, by, 0xFF6C6C75);
        // top left tag and top right search
        Gfx.spaced(g, this.font, "CAT OS", 10, 8, c(0xFF55555E), 2);
        String search = "SEARCH";
        int sw = Gfx.spacedWidth(this.font, search, 2);
        boolean hovS = over(this.width - sw - 18, 2, sw + 16, 18);
        Gfx.spaced(g, this.font, search, this.width - sw - 10, 8, c(hovS ? 0xFFFFFFFF : 0xFF55555E), 2);
        hit(this.width - sw - 18, 2, sw + 16, 18, () -> go(new PaletteScreen()));

        // right: vanilla menu and quit
        String quit = "QUIT";
        String van = "VANILLA";
        int qw = Gfx.spacedWidth(this.font, quit, 1);
        int vw = Gfx.spacedWidth(this.font, van, 1);
        int qx = this.width - 10 - qw;
        int vx = qx - 16 - vw;
        boolean hq = over(qx - 4, by - 4, qw + 8, 16);
        boolean hv = over(vx - 4, by - 4, vw + 8, 16);
        quitHover += ((hq ? 1f : 0f) - quitHover) * (1f - (float) Math.exp(-dt * 14f));
        vanillaHover += ((hv ? 1f : 0f) - vanillaHover) * (1f - (float) Math.exp(-dt * 14f));
        Gfx.spaced(g, this.font, quit, qx, by, c(Gfx.lerpColor(0xFF6C6C75, 0xFFFF7A7A, quitHover)), 1);
        Gfx.spaced(g, this.font, van, vx, by, c(Gfx.lerpColor(0xFF6C6C75, 0xFFFFFFFF, vanillaHover)), 1);
        hit(qx - 4, by - 4, qw + 8, 16, () -> {
            if (this.minecraft != null) this.minecraft.stop();
        });
        hit(vx - 4, by - 4, vw + 8, 16, () -> {
            allowVanilla = true;
            go(new TitleScreen());
        });

        // centre: what is playing, and the current lyric line
        if (Music.status() != Music.Status.IDLE && !Music.title().isEmpty()) {
            String line = "";
            if (Music.status() == Music.Status.SYNCED) {
                int idx = Music.indexAt(Music.positionMs());
                if (idx >= 0) line = Music.lines().get(idx).text();
            }
            String s = "\u266A " + Music.title() + (line.isEmpty() ? "" : "  -  " + line);
            int maxW = Math.max(60, this.width - 2 * (Math.max(Gfx.width(this.font, "00:00  |  " + user) + 20, 90)));
            s = Gfx.fit(this.font, s, Math.min(maxW, 300));
            text(g, s, (this.width - Gfx.width(this.font, s)) / 2, by, 0xFF8C8C95);
        }
    }

    // ---------- input ----------

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.contains(mx, my)) {
                h.click().run();
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        return super.keyPressed(event);
    }
}
