package studio.blackcat.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;

/**
 * All saved settings: which modules are on, where each HUD element sits, the accent colour,
 * HUD opacity and the cat badge. Stored in config/blackcat.json.
 */
public final class Modules {
    private Modules() {}

    public enum Module {
        FPS("FPS Counter", "Current + average"),
        CPS("CPS", "Clicks per second"),
        KEYSTROKES("Keystrokes", "WASD + mouse"),
        COORDS("Coordinates", "Your position"),
        PING("Ping", "Latency"),
        ARMOR("Armor HUD", "Durability"),
        POTIONS("Potion HUD", "Effects + timers"),
        DIRECTION("Direction HUD", "N / E / S / W compass"),
        CLOCK("Clock", "Real-world time"),
        ITEM("Item HUD", "Held item + durability"),
        BIOME("Biome HUD", "Current biome"),
        CPS_GRAPH("CPS Graph", "Live click history"),
        PING_GRAPH("Ping Graph", "Latency history"),
        NAME("Name Tag", "Your name on screen"),
        LOGO("Logo", "Black Cat badge"),
        FREELOOK("Freelook", "Hold key to look around");

        public final String title;
        public final String description;

        Module(String title, String description) {
            this.title = title;
            this.description = description;
        }
    }

    // ---------- cosmetics ----------

    public static final String[] ACCENT_NAMES = {"White", "Ice", "Mint", "Amber", "Rose", "Violet"};
    public static final int[] ACCENT_COLORS = {
            0xFFF2F2F5, 0xFF8FD3FF, 0xFF7EE3B0, 0xFFE8B84A, 0xFFFF7A90, 0xFFB79CFF};

    public static final float MIN_OPACITY = 0.3f;

    // ---------- state ----------

    private static final Set<Module> ENABLED = EnumSet.of(
            Module.FPS, Module.CPS, Module.KEYSTROKES, Module.NAME, Module.FREELOOK);
    /** Moved HUD elements: module -> {x / screenWidth, y / screenHeight}. Missing = default spot. */
    private static final Map<Module, float[]> POS = new EnumMap<>(Module.class);
    private static int accent = 0;
    private static float opacity = 0.85f;
    private static boolean nameBadge = true;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("blackcat.json");
    }

    // ---------- modules ----------

    public static boolean isEnabled(Module m) {
        return ENABLED.contains(m);
    }

    public static void toggle(Module m) {
        if (!ENABLED.remove(m)) ENABLED.add(m);
        save();
    }

    // ---------- HUD positions ----------

    /** Saved position of an element as screen fractions, or null if it is still at its default spot. */
    public static float[] pos(Module m) {
        return POS.get(m);
    }

    /** Remembers a new position in memory; call save() when the drag ends. */
    public static void setPos(Module m, float fx, float fy) {
        POS.put(m, new float[]{fx, fy});
    }

    public static void resetPos(Module m) {
        POS.remove(m);
    }

    public static void resetAllPos() {
        POS.clear();
    }

    // ---------- cosmetics ----------

    public static int accentIndex() {
        return accent;
    }

    public static int accent() {
        return ACCENT_COLORS[accent];
    }

    public static void setAccent(int i) {
        accent = Math.max(0, Math.min(ACCENT_COLORS.length - 1, i));
        save();
    }

    public static float opacity() {
        return opacity;
    }

    /** Remembers the opacity in memory (clamped); call save() when the slider is released. */
    public static void setOpacity(float v) {
        opacity = Math.max(MIN_OPACITY, Math.min(1f, v));
    }

    public static boolean nameBadge() {
        return nameBadge;
    }

    public static void toggleNameBadge() {
        nameBadge = !nameBadge;
        save();
    }

    // ---------- file ----------

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f)) {
            JsonObject obj = JsonParser.parseReader(r).getAsJsonObject();
            int cfg = obj.has("cfg") ? obj.get("cfg").getAsInt() : 0;

            if (obj.has("enabled")) {
                ENABLED.clear();
                for (var el : obj.getAsJsonArray("enabled")) {
                    try {
                        ENABLED.add(Module.valueOf(el.getAsString()));
                    } catch (IllegalArgumentException ignored) {
                        // module removed in a newer/older version
                    }
                }
            }
            if (cfg < 3) ENABLED.add(Module.NAME); // the name tag is new: switch it on once

            if (obj.has("pos")) {
                POS.clear();
                for (var e : obj.getAsJsonObject("pos").entrySet()) {
                    try {
                        JsonArray a = e.getValue().getAsJsonArray();
                        POS.put(Module.valueOf(e.getKey()), new float[]{a.get(0).getAsFloat(), a.get(1).getAsFloat()});
                    } catch (Exception ignored) {
                        // bad entry: skip it
                    }
                }
            }
            if (obj.has("accent")) accent = Math.max(0, Math.min(ACCENT_COLORS.length - 1, obj.get("accent").getAsInt()));
            if (obj.has("opacity")) setOpacity(obj.get("opacity").getAsFloat());
            if (obj.has("badge")) nameBadge = obj.get("badge").getAsBoolean();
        } catch (Exception e) {
            System.err.println("[blackcat] could not read config, using defaults: " + e);
        }
    }

    public static void save() {
        JsonObject obj = new JsonObject();
        obj.addProperty("cfg", 3);

        JsonArray arr = new JsonArray();
        for (Module m : ENABLED) arr.add(m.name());
        obj.add("enabled", arr);

        JsonObject pos = new JsonObject();
        for (var e : POS.entrySet()) {
            JsonArray a = new JsonArray();
            a.add(e.getValue()[0]);
            a.add(e.getValue()[1]);
            pos.add(e.getKey().name(), a);
        }
        obj.add("pos", pos);

        obj.addProperty("accent", accent);
        obj.addProperty("opacity", opacity);
        obj.addProperty("badge", nameBadge);

        try (Writer w = Files.newBufferedWriter(file())) {
            w.write(obj.toString());
        } catch (IOException e) {
            System.err.println("[blackcat] could not save config: " + e);
        }
    }
}
