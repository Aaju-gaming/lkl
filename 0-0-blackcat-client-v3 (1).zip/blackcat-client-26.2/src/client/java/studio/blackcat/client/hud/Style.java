package studio.blackcat.client.hud;

import studio.blackcat.client.Modules;
import studio.blackcat.client.util.Gfx;

/** The matte black look: one palette shared by the HUD, the menu and the editor. */
public final class Style {
    private Style() {}

    public static final int EDGE = 0xFF25252B;
    public static final int TEXT = 0xFFEDEDED;
    public static final int DIM = 0xFF8C8C95;
    public static final int FAINT = 0xFF3A3A42;
    public static final int WHITE = 0xFFFFFFFF;
    public static final int AMBER = 0xFFE0B04A;
    public static final int RED = 0xFFD9534F;
    public static final int TRACK = 0xFF17171B;

    /** Panel background, follows the HUD opacity slider. */
    public static int bg() {
        return Gfx.argb(Math.round(255f * Modules.opacity()), 11, 11, 13);
    }

    public static int accent() {
        return Modules.accent();
    }
}
