package studio.blackcat.client.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.hud.HudCtx;
import studio.blackcat.client.hud.HudRenderer;
import studio.blackcat.client.hud.HudRenderer.Placed;
import studio.blackcat.client.hud.Style;
import studio.blackcat.client.util.Gfx;
import studio.blackcat.client.util.Smooth;

import java.util.ArrayList;
import java.util.List;

/**
 * The HUD editor. Every switched-on element is shown where it sits; press and drag to move it.
 * Elements snap to the screen edges, the centre lines and each other (a thin guide line shows what
 * they snapped to). Positions are saved as soon as you let go. Works with a mouse and with touch.
 */
public class HudEditorScreen extends Screen {
    private static final float SNAP = 4f;

    private static final String[] BUTTON_LABELS = {"Reset selected", "Reset all", "Done"};
    private static final int BTN_H = 16;
    private static final int BTN_GAP = 4;

    private final Smooth open = new Smooth(0f);
    private final Smooth[] glow = new Smooth[Module.values().length];
    private final Smooth[] btnHover = new Smooth[BUTTON_LABELS.length];

    private List<Placed> placed = new ArrayList<>();
    private Module selected;
    private Module dragging;
    private float dragX;
    private float dragY;
    private boolean moved;
    private float guideX = -1f;
    private float guideY = -1f;

    private int pressedButton = -1;
    private int lastMouseX = -1;
    private int lastMouseY = -1;
    private long lastNanos = System.nanoTime();

    // toolbar layout (set by layoutToolbar)
    private int barX;
    private int barY;
    private int barW;
    private int barH;
    private final int[] btnX = new int[BUTTON_LABELS.length];
    private final int[] btnW = new int[BUTTON_LABELS.length];
    private int btnY;

    public HudEditorScreen() {
        super(Component.literal("Edit HUD"));
        for (int i = 0; i < glow.length; i++) glow[i] = new Smooth(0f);
        for (int i = 0; i < btnHover.length; i++) btnHover[i] = new Smooth(0f);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** No blur here: you need to see the game to place things relative to it. */
    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float a) {
    }

    // ---------- toolbar ----------

    private void layoutToolbar() {
        Font f = this.font;
        int total = 0;
        for (int i = 0; i < BUTTON_LABELS.length; i++) {
            btnW[i] = Gfx.width(f, BUTTON_LABELS[i]) + 16;
            total += btnW[i];
        }
        total += BTN_GAP * (BUTTON_LABELS.length - 1);
        barW = total + 24;
        barH = 46;
        barX = (width - barW) / 2;
        barY = 30;
        btnY = barY + 24;
        int x = barX + 12;
        for (int i = 0; i < BUTTON_LABELS.length; i++) {
            btnX[i] = x;
            x += btnW[i] + BTN_GAP;
        }
    }

    private int buttonAt(double mx, double my) {
        layoutToolbar();
        if (my < btnY || my >= btnY + BTN_H) return -1;
        for (int i = 0; i < BUTTON_LABELS.length; i++) {
            if (mx >= btnX[i] && mx < btnX[i] + btnW[i]) return i;
        }
        return -1;
    }

    private boolean buttonEnabled(int i) {
        return i != 0 || (selected != null && Modules.pos(selected) != null);
    }

    private void press(int i) {
        switch (i) {
            case 0 -> {
                if (selected != null) {
                    Modules.resetPos(selected);
                    Modules.save();
                }
            }
            case 1 -> {
                Modules.resetAllPos();
                Modules.save();
            }
            default -> this.minecraft.gui.setScreen(new GlassMenuScreen());
        }
    }

    // ---------- drawing ----------

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        lastMouseX = mouseX;
        lastMouseY = mouseY;

        long now = System.nanoTime();
        float dt = Math.min((now - lastNanos) / 1_000_000_000f, 0.1f);
        lastNanos = now;
        open.update(1f, dt, 10f);
        float t = Gfx.easeOutCubic(open.value);
        Font font = this.font;
        int accent = Style.accent();

        // soft dim so the outlines read well
        g.fill(0, 0, width, height, Gfx.argb(Math.round(60 * t), 0, 0, 0));

        // faint centre lines while dragging
        if (dragging != null) {
            g.fill(width / 2, 0, width / 2 + 1, height, Gfx.argb(24, 255, 255, 255));
            g.fill(0, height / 2, width, height / 2 + 1, Gfx.argb(24, 255, 255, 255));
        }

        HudCtx ctx = new HudCtx(this.minecraft, dt, true);
        placed = HudRenderer.place(ctx, width, height);

        for (Placed p : placed) p.widget.draw(g, ctx, p.x, p.y);

        // outlines + names
        Placed top = null;
        for (int i = placed.size() - 1; i >= 0 && dragging == null; i--) {
            if (placed.get(i).contains(mouseX, mouseY)) {
                top = placed.get(i);
                break;
            }
        }
        for (Placed p : placed) {
            Module m = p.widget.module;
            boolean hot = m == dragging || m == selected || p == top;
            float k = glow[m.ordinal()].update(hot ? 1f : 0f, dt, 16f);
            int edge = Gfx.lerpColor(Gfx.argb(70, 255, 255, 255), accent, m == dragging ? 1f : k * 0.9f);
            Gfx.roundOutline(g, p.x - 2, p.y - 2, p.widget.w + 4, p.widget.h + 4, 5, Gfx.mulAlpha(edge, t));
            if (k > 0.05f) {
                String name = p.widget.title();
                int ly = p.y - 13 >= 1 ? p.y - 13 : p.y + p.widget.h + 5;
                Gfx.text(g, font, name, p.x, ly, Gfx.mulAlpha(Style.WHITE, k));
            }
        }

        // snap guides
        if (dragging != null) {
            int ga = Gfx.mulAlpha(accent, 0.8f);
            if (guideX >= 0f) g.fill(Math.round(guideX), 0, Math.round(guideX) + 1, height, ga);
            if (guideY >= 0f) g.fill(0, Math.round(guideY), width, Math.round(guideY) + 1, ga);
        }

        drawToolbar(g, font, mouseX, mouseY, dt, t);

        if (placed.isEmpty()) {
            String msg = "No HUD modules are switched on. Turn some on in the menu first.";
            Gfx.text(g, font, msg, (width - Gfx.width(font, msg)) / 2, height / 2, Style.DIM);
        }
    }

    private void drawToolbar(GuiGraphicsExtractor g, Font font, int mouseX, int mouseY, float dt, float t) {
        layoutToolbar();
        int accent = Style.accent();

        Gfx.roundRect(g, barX, barY, barW, barH, 6, Gfx.mulAlpha(0xF20B0B0D, t));
        Gfx.roundOutline(g, barX, barY, barW, barH, 6, Gfx.mulAlpha(Style.EDGE, t));

        String title = "EDIT HUD";
        String hint = "drag elements to move them";
        int tx = barX + 12;
        Gfx.text(g, font, title, tx, barY + 7, Gfx.mulAlpha(Style.WHITE, t));
        Gfx.text(g, font, hint, tx + Gfx.width(font, title) + 8, barY + 7, Gfx.mulAlpha(Style.DIM, t));

        for (int i = 0; i < BUTTON_LABELS.length; i++) {
            boolean enabled = buttonEnabled(i);
            boolean hov = enabled && mouseX >= btnX[i] && mouseX < btnX[i] + btnW[i]
                    && mouseY >= btnY && mouseY < btnY + BTN_H;
            float h = btnHover[i].update(hov ? 1f : 0f, dt, 16f);
            boolean primary = i == BUTTON_LABELS.length - 1;

            int bg = primary ? Gfx.lerpColor(accent, 0xFFFFFFFF, h * 0.35f) : Gfx.lerpColor(0xFF141418, 0xFF212127, h);
            int edge = primary ? bg : Gfx.lerpColor(Style.EDGE, 0xFF8C8C95, h * 0.7f);
            int fg = primary ? 0xFF0B0B0D : (enabled ? Style.WHITE : Style.FAINT);

            Gfx.roundRect(g, btnX[i], btnY, btnW[i], BTN_H, 4, Gfx.mulAlpha(bg, t));
            Gfx.roundOutline(g, btnX[i], btnY, btnW[i], BTN_H, 4, Gfx.mulAlpha(edge, t));
            String label = BUTTON_LABELS[i];
            Gfx.text(g, font, label, btnX[i] + (btnW[i] - Gfx.width(font, label)) / 2, btnY + 4, Gfx.mulAlpha(fg, t));
        }
    }

    // ---------- snapping ----------

    /** Finds the nearest snap target for one axis (top-left coordinate v of something `size` long). */
    private static final class Snap {
        final float v;
        float best = SNAP + 0.001f;
        float out;
        float line = -1f;

        Snap(float v) {
            this.v = v;
            this.out = v;
        }

        void target(float target, float lineAt) {
            float d = Math.abs(v - target);
            if (d < best) {
                best = d;
                out = target;
                line = lineAt;
            }
        }
    }

    // ---------- input ----------

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        moved = false;
        pressedButton = buttonAt(lastMouseX, lastMouseY);
        if (pressedButton >= 0) return true;

        for (int i = placed.size() - 1; i >= 0; i--) {
            Placed p = placed.get(i);
            if (p.contains(lastMouseX, lastMouseY)) {
                dragging = p.widget.module;
                selected = dragging;
                dragX = p.x;
                dragY = p.y;
                return true;
            }
        }
        selected = null;
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double deltaX, double deltaY) {
        if (dragging == null) return true;
        Placed me = null;
        for (Placed p : placed) {
            if (p.widget.module == dragging) {
                me = p;
                break;
            }
        }
        if (me == null) return true;

        dragX += (float) deltaX;
        dragY += (float) deltaY;
        moved = true;

        int w = me.widget.w;
        int h = me.widget.h;
        float nx = Math.max(0f, Math.min(Math.max(0, width - w), dragX));
        float ny = Math.max(0f, Math.min(Math.max(0, height - h), dragY));

        Snap sx = new Snap(nx);
        sx.target(HudRenderer.MARGIN, -1f);
        sx.target((width - w) / 2f, width / 2f);
        sx.target(width - w - HudRenderer.MARGIN, -1f);

        Snap sy = new Snap(ny);
        sy.target(HudRenderer.MARGIN, -1f);
        sy.target((height - h) / 2f, height / 2f);
        sy.target(height - h - HudRenderer.MARGIN, -1f);

        for (Placed o : placed) {
            if (o.widget.module == dragging) continue;
            sx.target(o.x, o.x);
            sx.target(o.x + o.widget.w - w, o.x + o.widget.w);
            sx.target(o.x + (o.widget.w - w) / 2f, o.x + o.widget.w / 2f);
            sx.target(o.x + o.widget.w + HudRenderer.GAP, -1f);
            sx.target(o.x - w - HudRenderer.GAP, -1f);

            sy.target(o.y, o.y);
            sy.target(o.y + o.widget.h - h, o.y + o.widget.h);
            sy.target(o.y + (o.widget.h - h) / 2f, o.y + o.widget.h / 2f);
            sy.target(o.y + o.widget.h + HudRenderer.GAP, -1f);
            sy.target(o.y - h - HudRenderer.GAP, -1f);
        }
        guideX = sx.line;
        guideY = sy.line;

        float fx = Math.max(0f, Math.min(Math.max(0, width - w), sx.out));
        float fy = Math.max(0f, Math.min(Math.max(0, height - h), sy.out));
        Modules.setPos(dragging, fx / width, fy / height);
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (pressedButton >= 0) {
            int b = pressedButton;
            pressedButton = -1;
            if (buttonAt(lastMouseX, lastMouseY) == b && buttonEnabled(b)) press(b);
            return true;
        }
        if (dragging != null) {
            dragging = null;
            guideX = -1f;
            guideY = -1f;
            if (moved) Modules.save();
        }
        return true;
    }
}
