package studio.blackcat.client.gui;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import studio.blackcat.client.hud.Style;
import studio.blackcat.client.util.Cat;
import studio.blackcat.client.util.Gfx;

/** The Black Cat logo on a small matte plate: blinking cat above the BLACK CAT lettering. */
public final class LogoBadge {
    private LogoBadge() {}

    public static final int CAT_W = 44;
    public static final int TEXT_W = 66;
    private static final int PAD = 5;
    private static final int GAP = 5;
    public static final int W = 84;
    private static final int CAT_H = Cat.heightFor(CAT_W);
    private static final int TEXT_H = Math.max(1, Math.round(TEXT_W * Cat.WORD_H / (float) Cat.WORD_W));
    public static final int H = PAD + CAT_H + GAP + TEXT_H + PAD;

    /** Draws the badge with its top-left at (x, y), scaled by `scale` (1 = normal size). */
    public static void draw(GuiGraphicsExtractor g, int x, int y, float scale, float time) {
        g.pose().pushMatrix();
        g.pose().translate((float) x, (float) y);
        g.pose().scale(scale, scale);

        Gfx.roundRect(g, 0, 0, W, H, 6, Style.bg());
        Gfx.roundOutline(g, 0, 0, W, H, 6, Style.EDGE);
        Cat.draw(g, (W - CAT_W) / 2, PAD, CAT_W, Cat.blink(time));
        Gfx.textureFit(g, Cat.WORD, (W - TEXT_W) / 2, PAD + CAT_H + GAP, TEXT_W, TEXT_H, Cat.WORD_W, Cat.WORD_H);

        g.pose().popMatrix();
    }
}
