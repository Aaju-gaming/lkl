package studio.blackcat.client.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.hud.HudCtx;
import studio.blackcat.client.hud.Style;
import studio.blackcat.client.hud.Widgets;
import studio.blackcat.client.util.Cat;
import studio.blackcat.client.util.Gfx;
import studio.blackcat.client.util.Smooth;

/**
 * The Black Cat menu: flat matte black, thin edges, smooth motion everywhere.
 *
 * Two pages (Modules, Cosmetics) and an Edit HUD button that opens the drag-to-move editor.
 * The panel eases in, cards stagger in and lift on hover, toggles slide, lists scroll smoothly
 * (mouse wheel or drag), and the whole thing fades out on close. Vanilla's background blur sits behind it.
 */
public class GlassMenuScreen extends Screen {
    private static final int PANEL_W = 384;
    private static final int PANEL_H = 232;
    private static final int PAD = 14;
    private static final int GAP = 8;
    private static final int COLS = 3;
    private static final int CARD_H = 54;
    private static final int HEADER_H = 46;
    private static final int TAB_H = 18;

    // matte palette
    private static final int PANEL_BG = 0xF20B0B0D;
    private static final int PANEL_EDGE = 0xFF26262C;
    private static final int DIVIDER = 0xFF1C1C21;
    private static final int CARD_BG = 0xFF121215;
    private static final int CARD_HOVER = 0xFF19191D;
    private static final int CARD_EDGE = 0xFF222228;
    private static final int TEXT = 0xFFEDEDED;
    private static final int DIM = 0xFF8C8C95;
    private static final int TRACK_OFF = 0xFF2A2A30;
    private static final int KNOB_OFF = 0xFF8C8C95;
    private static final int KNOB_ON = 0xFF0B0B0D;

    private static final String[] TAB_NAMES = {"Modules", "Cosmetics"};
    private static final String EDIT_LABEL = "Edit HUD";

    // cosmetics page: row tops and heights (relative to the top of the page)
    private static final int R_PREVIEW = 0;
    private static final int R_ACCENT = 1;
    private static final int R_OPACITY = 2;
    private static final int R_BADGE = 3;
    private static final int[] ROW_Y = {0, 62, 122, 182};
    private static final int[] ROW_H = {54, 52, 52, 40};
    private static final int COSMETICS_H = 222;
    private static final int SW_W = 24;
    private static final int SW_H = 14;

    /** Remembered between openings. */
    private static int lastTab = 0;

    private int tab = lastTab;
    private final Smooth open = new Smooth(0f);
    private final Smooth page = new Smooth(1f);
    private final Smooth scrollAnim = new Smooth(0f);
    private final Smooth[] hover = new Smooth[Module.values().length];
    private final Smooth[] on = new Smooth[Module.values().length];
    private final Smooth[] hdrHover = new Smooth[3];
    private final Smooth[] tabOn = new Smooth[2];
    private final Smooth[] swHover = new Smooth[Modules.ACCENT_COLORS.length];
    private final Smooth badgeOn = new Smooth(Modules.nameBadge() ? 1f : 0f);
    private final Smooth badgeHover = new Smooth(0f);
    private boolean closing;
    private long lastNanos = System.nanoTime();
    private int lastMouseX = -1;
    private int lastMouseY = -1;
    private float scrollTarget;
    private float dragTotal;
    private boolean dragging;
    private boolean sliding;

    public GlassMenuScreen() {
        super(Component.literal("Black Cat"));
        for (int i = 0; i < hover.length; i++) {
            hover[i] = new Smooth(0f);
            on[i] = new Smooth(Modules.isEnabled(Module.values()[i]) ? 1f : 0f);
        }
        for (int i = 0; i < hdrHover.length; i++) hdrHover[i] = new Smooth(0f);
        for (int i = 0; i < tabOn.length; i++) tabOn[i] = new Smooth(i == tab ? 1f : 0f);
        for (int i = 0; i < swHover.length; i++) swHover[i] = new Smooth(0f);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        closing = true; // fade out first, then really close
    }

    // ---------- layout ----------

    private int panelX() {
        return (width - PANEL_W) / 2;
    }

    private int panelY() {
        return (height - PANEL_H) / 2;
    }

    private int viewTop() {
        return panelY() + HEADER_H + 8;
    }

    private int viewBottom() {
        return panelY() + PANEL_H - PAD + 2;
    }

    private int cardW() {
        return (PANEL_W - PAD * 2 - GAP * (COLS - 1)) / COLS;
    }

    private int rows() {
        return (Module.values().length + COLS - 1) / COLS;
    }

    private float maxScroll() {
        float content = tab == 0 ? rows() * (CARD_H + GAP) - GAP : COSMETICS_H;
        return Math.max(0f, content - (viewBottom() - viewTop()));
    }

    private int scrollPx() {
        return Math.round(scrollAnim.value);
    }

    // header buttons: 0 = Modules tab, 1 = Cosmetics tab, 2 = Edit HUD

    private int hdrW(int i) {
        return Gfx.width(font, i == 2 ? EDIT_LABEL : TAB_NAMES[i]) + 18;
    }

    private int hdrX(int i) {
        if (i == 0) return panelX() + 122;
        if (i == 1) return panelX() + 122 + hdrW(0) + 4;
        return panelX() + PANEL_W - PAD - hdrW(2);
    }

    private int hdrY() {
        return panelY() + 14;
    }

    private boolean overHdr(int i, double mx, double my) {
        return mx >= hdrX(i) && mx < hdrX(i) + hdrW(i) && my >= hdrY() && my < hdrY() + TAB_H;
    }

    private boolean inView(double my) {
        return my >= viewTop() && my <= viewBottom();
    }

    // modules page

    private int cardX(int i) {
        return panelX() + PAD + (i % COLS) * (cardW() + GAP);
    }

    private int cardY(int i) {
        return viewTop() + (i / COLS) * (CARD_H + GAP) - scrollPx();
    }

    private boolean over(int i, double mx, double my) {
        if (!inView(my)) return false;
        return mx >= cardX(i) && mx < cardX(i) + cardW() && my >= cardY(i) && my < cardY(i) + CARD_H;
    }

    // cosmetics page

    private int rowX() {
        return panelX() + PAD;
    }

    private int rowW() {
        return PANEL_W - PAD * 2;
    }

    private int rowTop(int r) {
        return viewTop() + ROW_Y[r] - scrollPx();
    }

    private int swX(int i) {
        return rowX() + 10 + i * (SW_W + 8);
    }

    private int swY() {
        return rowTop(R_ACCENT) + 28;
    }

    private boolean overSwatch(int i, double mx, double my) {
        if (!inView(my)) return false;
        return mx >= swX(i) - 2 && mx < swX(i) + SW_W + 2 && my >= swY() - 3 && my < swY() + SW_H + 3;
    }

    private int sliderX0() {
        return rowX() + 10;
    }

    private int sliderX1() {
        return rowX() + rowW() - 10;
    }

    private int sliderY() {
        return rowTop(R_OPACITY) + 35;
    }

    private boolean overSlider(double mx, double my) {
        if (!inView(my)) return false;
        return mx >= sliderX0() - 6 && mx < sliderX1() + 6 && my >= sliderY() - 10 && my < sliderY() + 12;
    }

    private boolean overBadgeRow(double mx, double my) {
        if (!inView(my)) return false;
        int y = rowTop(R_BADGE);
        return mx >= rowX() && mx < rowX() + rowW() && my >= y && my < y + ROW_H[R_BADGE];
    }

    private void switchTab(int t) {
        if (t == tab) return;
        tab = t;
        lastTab = t;
        scrollTarget = 0f;
        scrollAnim.value = 0f;
        page.value = 0f;
    }

    // ---------- rendering ----------

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        lastMouseX = mouseX;
        lastMouseY = mouseY;

        long now = System.nanoTime();
        float dt = Math.min((now - lastNanos) / 1_000_000_000f, 0.1f);
        lastNanos = now;

        open.update(closing ? 0f : 1f, dt, closing ? 14f : 9f);
        if (closing && open.value <= 0.01f) {
            super.onClose(); // vanilla: leave the screen
            return;
        }
        page.update(1f, dt, 9f);
        float t = Gfx.easeOutCubic(open.value);
        Font font = this.font;
        int accent = Style.accent();

        scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget));
        scrollAnim.update(scrollTarget, dt, 16f);

        // opacity slider follows the pointer while it is held
        if (sliding) {
            float f = Gfx.clamp01((mouseX - sliderX0()) / (float) (sliderX1() - sliderX0()));
            Modules.setOpacity(Modules.MIN_OPACITY + f * (1f - Modules.MIN_OPACITY));
        }

        // soft dim on top of vanilla's blur
        g.fill(0, 0, width, height, Gfx.argb(Math.round(80 * t), 0, 0, 0));

        // panel rises and scales up slightly
        float scale = 0.95f + 0.05f * t;
        float rise = (1f - t) * 12f;
        g.pose().pushMatrix();
        g.pose().translate(width / 2f, height / 2f + rise);
        g.pose().scale(scale, scale);
        g.pose().translate(-width / 2f, -height / 2f);

        int px = panelX();
        int py = panelY();

        // matte body + hairline edge
        Gfx.roundRect(g, px, py, PANEL_W, PANEL_H, 8, Gfx.mulAlpha(PANEL_BG, t));
        Gfx.roundOutline(g, px, py, PANEL_W, PANEL_H, 8, Gfx.mulAlpha(PANEL_EDGE, t));

        // header: the logo cat (blinking) + title
        if (open.value > 0.35f) {
            Cat.draw(g, px + PAD, py + 15, 40, Cat.blink(Cat.time()));
        }
        Gfx.text(g, font, "BLACK CAT", px + PAD + 46, py + 13, Gfx.mulAlpha(TEXT, t));
        Gfx.text(g, font, "STUDIOS", px + PAD + 46, py + 25, Gfx.mulAlpha(DIM, t));

        // header buttons: two tabs + Edit HUD
        for (int i = 0; i < 3; i++) {
            boolean hov = !closing && overHdr(i, mouseX, mouseY);
            float h = hdrHover[i].update(hov ? 1f : 0f, dt, 14f);
            int x = hdrX(i);
            int y = hdrY() - Math.round(h);
            int w = hdrW(i);
            String label = i == 2 ? EDIT_LABEL : TAB_NAMES[i];

            if (i < 2) {
                float a = tabOn[i].update(tab == i ? 1f : 0f, dt, 14f);
                int bg = Gfx.lerpColor(Gfx.lerpColor(0x00000000, 0xFF17171B, h), 0xFF222228, a);
                int edge = Gfx.lerpColor(Gfx.lerpColor(0x00000000, Style.EDGE, h), accent, a * 0.8f);
                Gfx.roundRect(g, x, y, w, TAB_H, 5, Gfx.mulAlpha(bg, t));
                Gfx.roundOutline(g, x, y, w, TAB_H, 5, Gfx.mulAlpha(edge, t));
                Gfx.text(g, font, label, x + (w - Gfx.width(font, label)) / 2, y + 5,
                        Gfx.mulAlpha(Gfx.lerpColor(DIM, Style.WHITE, Math.max(a, h * 0.6f)), t));
            } else {
                int bg = Gfx.lerpColor(0xFF141418, accent, h * 0.9f);
                int edge = Gfx.lerpColor(accent, Style.WHITE, h * 0.3f);
                Gfx.roundRect(g, x, y, w, TAB_H, 5, Gfx.mulAlpha(bg, t));
                Gfx.roundOutline(g, x, y, w, TAB_H, 5, Gfx.mulAlpha(edge, t));
                Gfx.text(g, font, label, x + (w - Gfx.width(font, label)) / 2, y + 5,
                        Gfx.mulAlpha(Gfx.lerpColor(Style.WHITE, 0xFF0B0B0D, h), t));
            }
        }

        g.fill(px + PAD, py + HEADER_H, px + PANEL_W - PAD, py + HEADER_H + 1, Gfx.mulAlpha(DIVIDER, t));

        // ----- the page, clipped to the view -----
        float pageT = Math.min(open.value, page.value);
        g.enableScissor(px + 4, viewTop(), px + PANEL_W - 4, viewBottom());
        if (tab == 0) {
            renderModules(g, font, mouseX, mouseY, dt, pageT);
        } else {
            renderCosmetics(g, font, mouseX, mouseY, dt, pageT);
        }
        g.disableScissor();

        // thin scroll bar
        float max = maxScroll();
        if (max > 0f) {
            int trackTop = viewTop();
            int trackH = viewBottom() - viewTop();
            int thumbH = Math.max(18, Math.round(trackH * trackH / (trackH + max)));
            int thumbY = trackTop + Math.round((trackH - thumbH) * (scrollAnim.value / max));
            int bx = px + PANEL_W - 8;
            g.fill(bx, thumbY, bx + 2, thumbY + thumbH, Gfx.mulAlpha(0xFF3A3A42, t));
        }

        g.pose().popMatrix();
    }

    private void renderModules(GuiGraphicsExtractor g, Font font, int mouseX, int mouseY, float dt, float pageT) {
        Module[] mods = Module.values();
        int accent = Style.accent();
        for (int i = 0; i < mods.length; i++) {
            float cardT = Gfx.easeOutCubic(Gfx.clamp01((pageT - i * 0.04f) / 0.7f));

            boolean hov = !closing && over(i, mouseX, mouseY);
            float h = hover[i].update(hov ? 1f : 0f, dt, 14f);
            float s = on[i].update(Modules.isEnabled(mods[i]) ? 1f : 0f, dt, 12f);

            int cw = cardW();
            int cx = cardX(i);
            int cy = cardY(i) - Math.round(h * 1.5f) + Math.round((1f - cardT) * 8f);
            if (cy > viewBottom() || cy + CARD_H < viewTop()) continue;

            int bg = Gfx.lerpColor(CARD_BG, CARD_HOVER, h);
            int edge = Gfx.lerpColor(CARD_EDGE, Gfx.lerpColor(DIM, accent, s), Math.max(h * 0.5f, s * 0.7f));
            Gfx.roundRect(g, cx, cy, cw, CARD_H, 6, Gfx.mulAlpha(bg, cardT));
            Gfx.roundOutline(g, cx, cy, cw, CARD_H, 6, Gfx.mulAlpha(edge, cardT));

            Gfx.text(g, font, Gfx.fit(font, mods[i].title, cw - 18), cx + 9, cy + 8, Gfx.mulAlpha(TEXT, cardT));
            Gfx.text(g, font, Gfx.fit(font, mods[i].description, cw - 18), cx + 9, cy + 20, Gfx.mulAlpha(DIM, cardT));

            toggle(g, cx + 9, cy + CARD_H - 12 - 8, s, cardT);
        }
    }

    /** The sliding on/off switch (28 x 12). */
    private void toggle(GuiGraphicsExtractor g, int tx, int ty, float s, float alpha) {
        int tw = 28;
        int th = 12;
        Gfx.roundRect(g, tx, ty, tw, th, 6, Gfx.mulAlpha(Gfx.lerpColor(TRACK_OFF, Style.accent(), s), alpha));
        int knobX = tx + 2 + Math.round(s * (tw - th));
        Gfx.roundRect(g, knobX, ty + 2, th - 4, th - 4, 4,
                Gfx.mulAlpha(Gfx.lerpColor(KNOB_OFF, KNOB_ON, s), alpha));
    }

    private void renderCosmetics(GuiGraphicsExtractor g, Font font, int mouseX, int mouseY, float dt, float pageT) {
        int accent = Style.accent();
        int rx = rowX();
        int rw = rowW();

        for (int r = 0; r < ROW_Y.length; r++) {
            float rowT = Gfx.easeOutCubic(Gfx.clamp01((pageT - r * 0.08f) / 0.7f));
            int y = rowTop(r) + Math.round((1f - rowT) * 8f);
            if (y > viewBottom() || y + ROW_H[r] < viewTop()) continue;

            boolean hovBadge = r == R_BADGE && !closing && overBadgeRow(mouseX, mouseY);
            float hb = r == R_BADGE ? badgeHover.update(hovBadge ? 1f : 0f, dt, 14f) : 0f;
            Gfx.roundRect(g, rx, y, rw, ROW_H[r], 6, Gfx.mulAlpha(Gfx.lerpColor(CARD_BG, CARD_HOVER, hb), rowT));
            Gfx.roundOutline(g, rx, y, rw, ROW_H[r], 6, Gfx.mulAlpha(Gfx.lerpColor(CARD_EDGE, DIM, hb * 0.5f), rowT));

            switch (r) {
                case R_PREVIEW -> {
                    Gfx.text(g, font, "Preview", rx + 10, y + 8, Gfx.mulAlpha(TEXT, rowT));
                    String note = "changes show live";
                    Gfx.text(g, font, note, rx + rw - 10 - Gfx.width(font, note), y + 8, Gfx.mulAlpha(DIM, rowT));

                    // a mid-tone backdrop so the opacity setting is visible
                    int by = y + 22;
                    Gfx.roundRectV(g, rx + 8, by, rw - 16, 26, 5,
                            Gfx.mulAlpha(0xFF46505E, rowT), Gfx.mulAlpha(0xFF2B323C, rowT));
                    HudCtx ctx = new HudCtx(this.minecraft, dt, true);
                    Widgets.NAME.layout(ctx);
                    Widgets.FPS.layout(ctx);
                    int nx = rx + 16;
                    Widgets.NAME.draw(g, ctx, nx, by + (26 - Widgets.NAME.h) / 2);
                    Widgets.FPS.draw(g, ctx, nx + Widgets.NAME.w + 6, by + (26 - Widgets.FPS.h) / 2);
                }
                case R_ACCENT -> {
                    Gfx.text(g, font, "Accent color", rx + 10, y + 8, Gfx.mulAlpha(TEXT, rowT));
                    String name = Modules.ACCENT_NAMES[Modules.accentIndex()];
                    Gfx.text(g, font, name, rx + rw - 10 - Gfx.width(font, name), y + 8, Gfx.mulAlpha(DIM, rowT));
                    for (int i = 0; i < Modules.ACCENT_COLORS.length; i++) {
                        boolean hov = !closing && overSwatch(i, mouseX, mouseY);
                        float h = swHover[i].update(hov ? 1f : 0f, dt, 16f);
                        int sx = swX(i);
                        int sy = y + 28 - Math.round(h * 2f);
                        Gfx.roundRect(g, sx, sy, SW_W, SW_H, 5, Gfx.mulAlpha(Modules.ACCENT_COLORS[i], rowT));
                        if (i == Modules.accentIndex()) {
                            Gfx.roundOutline(g, sx - 3, sy - 3, SW_W + 6, SW_H + 6, 7, Gfx.mulAlpha(Style.WHITE, rowT));
                        }
                    }
                }
                case R_OPACITY -> {
                    Gfx.text(g, font, "HUD opacity", rx + 10, y + 8, Gfx.mulAlpha(TEXT, rowT));
                    String pct = Math.round(Modules.opacity() * 100f) + "%";
                    Gfx.text(g, font, pct, rx + rw - 10 - Gfx.width(font, pct), y + 8, Gfx.mulAlpha(DIM, rowT));

                    int x0 = sliderX0();
                    int x1 = sliderX1();
                    int ty = y + 35;
                    float f = (Modules.opacity() - Modules.MIN_OPACITY) / (1f - Modules.MIN_OPACITY);
                    int kx = x0 + Math.round(f * (x1 - x0));
                    Gfx.roundRect(g, x0, ty - 2, x1 - x0, 4, 2, Gfx.mulAlpha(TRACK_OFF, rowT));
                    if (kx > x0) Gfx.roundRect(g, x0, ty - 2, kx - x0, 4, 2, Gfx.mulAlpha(accent, rowT));
                    int kw = sliding ? 10 : 8;
                    Gfx.roundRect(g, kx - kw / 2, ty - 6, kw, 12, 4, Gfx.mulAlpha(Style.WHITE, rowT));
                }
                case R_BADGE -> {
                    Gfx.text(g, font, "Cat on name tag", rx + 10, y + 8, Gfx.mulAlpha(TEXT, rowT));
                    Gfx.text(g, font, "Blinking cat next to your name", rx + 10, y + 21, Gfx.mulAlpha(DIM, rowT));
                    float s = badgeOn.update(Modules.nameBadge() ? 1f : 0f, dt, 12f);
                    toggle(g, rx + rw - 10 - 28, y + (ROW_H[R_BADGE] - 12) / 2, s, rowT);
                }
                default -> {
                }
            }
        }
    }

    // ---------- input ----------

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scrollTarget -= (float) scrollY * 30f;
        scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget));
        return true;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        dragTotal = 0f;
        dragging = false;
        sliding = false;
        if (closing) return false;
        if (tab == 1 && overSlider(lastMouseX, lastMouseY)) {
            sliding = true; // grabbing the opacity slider, not scrolling the page
        }
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double deltaX, double deltaY) {
        if (sliding) return true;
        dragTotal += (float) Math.abs(deltaY);
        if (dragTotal > 4f) dragging = true;
        if (dragging) {
            scrollTarget -= (float) deltaY;
            scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget));
        }
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (sliding) {
            sliding = false;
            Modules.save();
            return true;
        }
        boolean wasDrag = dragging;
        dragging = false;
        if (closing || wasDrag) return true;

        // a clean tap/click: act on whatever is under the last known pointer position
        // (works for mouse and for touch taps on Pojav)
        for (int i = 0; i < 3; i++) {
            if (overHdr(i, lastMouseX, lastMouseY)) {
                if (i < 2) {
                    switchTab(i);
                } else {
                    this.minecraft.gui.setScreen(new HudEditorScreen());
                }
                return true;
            }
        }

        if (tab == 0) {
            Module[] mods = Module.values();
            for (int i = 0; i < mods.length; i++) {
                if (over(i, lastMouseX, lastMouseY)) {
                    Modules.toggle(mods[i]);
                    return true;
                }
            }
        } else {
            for (int i = 0; i < Modules.ACCENT_COLORS.length; i++) {
                if (overSwatch(i, lastMouseX, lastMouseY)) {
                    Modules.setAccent(i);
                    return true;
                }
            }
            if (overBadgeRow(lastMouseX, lastMouseY)) {
                Modules.toggleNameBadge();
                return true;
            }
        }
        return super.mouseReleased(event);
    }
}
