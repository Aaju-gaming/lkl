package studio.blackcat.client.hud;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.PlayerInfo;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.gui.HudEditorScreen;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/**
 * Runs the HUD: keeps the stats (FPS, CPS and ping history), works out where every element goes
 * (default spots, or where the player dragged it in the HUD editor) and draws them.
 */
public final class HudRenderer {
    private HudRenderer() {}

    public static final int MARGIN = 6;
    public static final int GAP = 4;

    // ---- stats ----
    private static long lastNanos = System.nanoTime();
    private static int frames;
    private static long fpsWindowStart = System.nanoTime();
    private static int fps;
    private static final ArrayDeque<Integer> FPS_HIST = new ArrayDeque<>();

    public static final ArrayDeque<Float> CPS_L = new ArrayDeque<>();
    public static final ArrayDeque<Float> CPS_R = new ArrayDeque<>();
    public static final ArrayDeque<Float> PING_HIST = new ArrayDeque<>();
    public static final ArrayDeque<Float> FPS_SAMPLES = new ArrayDeque<>();
    private static long nextCpsSample;
    private static long nextPingSample;
    private static final int GRAPH_SAMPLES = 46;

    public static int fps() {
        return fps;
    }

    public static int avgFps() {
        if (FPS_HIST.isEmpty()) return fps;
        long sum = 0;
        for (int v : FPS_HIST) sum += v;
        return Math.round((float) sum / FPS_HIST.size());
    }

    /** Ping in ms, or -1 if unknown (single player). */
    public static int ping(Minecraft mc) {
        if (mc.getConnection() == null || mc.player == null) return -1;
        PlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        return info == null ? -1 : info.getLatency();
    }

    // ---- placement ----

    /** One element with the spot it will be drawn at this frame. */
    public static final class Placed {
        public final HudWidget widget;
        public int x;
        public int y;

        Placed(HudWidget widget) {
            this.widget = widget;
        }

        /** Size on screen (the element's own size times its scale setting). */
        public int ew() {
            return Math.max(1, Math.round(widget.w * Modules.opts(widget.module).scale));
        }

        public int eh() {
            return Math.max(1, Math.round(widget.h * Modules.opts(widget.module).scale));
        }

        public boolean contains(double mx, double my) {
            return mx >= x && mx < x + ew() && my >= y && my < y + eh();
        }
    }

    /**
     * Measures every switched-on element and decides where it goes. Elements nobody has moved are
     * stacked in their default spots (and the stack closes up when one is moved away); moved elements
     * go exactly where the player put them.
     */
    public static List<Placed> place(HudCtx c, int sw, int sh) {
        List<Placed> list = new ArrayList<>();
        for (HudWidget w : Widgets.ALL) {
            if (!Modules.isEnabled(w.module)) continue;
            w.layout(c);
            if (!w.visible) continue;
            list.add(new Placed(w));
        }

        int leftY = MARGIN;
        int rightTopY = MARGIN;
        int rightMidY = -1;
        for (Placed p : list) {
            Module m = p.widget.module;
            if (Modules.pos(m) != null) continue;
            int w = p.ew();
            int h = p.eh();
            switch (m) {
                case NAME -> {
                    p.x = (sw - w) / 2;
                    p.y = MARGIN;
                }
                case POTIONS -> {
                    p.x = sw - MARGIN - w;
                    p.y = rightTopY;
                    rightTopY += h + GAP;
                }
                case ARMOR, ITEM -> {
                    if (rightMidY < 0) rightMidY = Math.max(rightTopY, (sh - 86) / 2);
                    p.x = sw - MARGIN - w;
                    p.y = rightMidY;
                    rightMidY += h + GAP;
                }
                case KEYSTROKES -> {
                    p.x = MARGIN;
                    p.y = sh - MARGIN - h;
                }
                case LOGO -> {
                    p.x = sw - MARGIN - w;
                    p.y = sh - MARGIN - h;
                }
                default -> {
                    p.x = MARGIN;
                    p.y = leftY;
                    leftY += h + GAP;
                }
            }
        }

        for (Placed p : list) {
            float[] o = Modules.pos(p.widget.module);
            if (o != null) {
                p.x = Math.round(o[0] * sw);
                p.y = Math.round(o[1] * sh);
            }
            p.x = Math.max(0, Math.min(Math.max(0, sw - p.ew()), p.x));
            p.y = Math.max(0, Math.min(Math.max(0, sh - p.eh()), p.y));
        }
        return list;
    }

    // ---- frame ----

    public static void render(GuiGraphicsExtractor g, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        long now = System.nanoTime();
        float dt = Math.min((now - lastNanos) / 1_000_000_000f, 0.1f);
        lastNanos = now;

        frames++;
        if (now - fpsWindowStart >= 1_000_000_000L) {
            fps = frames;
            frames = 0;
            fpsWindowStart = now;
            FPS_HIST.addLast(fps);
            while (FPS_HIST.size() > 30) FPS_HIST.removeFirst();
        }

        if (mc.player == null) return;
        Cps.poll(mc.options.keyAttack.isDown(), mc.options.keyUse.isDown());
        sample(mc, now);

        if (mc.gui.hud.isHidden()) return;
        if (!Modules.anyEnabled()) return;
        if (mc.gui.screen() instanceof HudEditorScreen) return; // the editor draws the elements itself

        HudCtx ctx = new HudCtx(mc, dt, false);
        for (Placed p : place(ctx, g.guiWidth(), g.guiHeight())) {
            drawPlaced(g, ctx, p);
        }
    }

    /** Draws one element with its own scale and style settings. */
    public static void drawPlaced(GuiGraphicsExtractor g, HudCtx ctx, Placed p) {
        float sc = Modules.opts(p.widget.module).scale;
        Style.begin(p.widget.module);
        try {
            if (sc == 1f) {
                p.widget.draw(g, ctx, p.x, p.y);
            } else {
                g.pose().pushMatrix();
                g.pose().translate((float) p.x, (float) p.y);
                g.pose().scale(sc, sc);
                p.widget.draw(g, ctx, 0, 0);
                g.pose().popMatrix();
            }
        } finally {
            Style.end();
        }
    }

    private static void sample(Minecraft mc, long nowNanos) {
        long ms = nowNanos / 1_000_000L;
        if (ms >= nextCpsSample) {
            nextCpsSample = ms + 200;
            push(CPS_L, Cps.left());
            push(CPS_R, Cps.right());
        }
        if (ms >= nextPingSample) {
            nextPingSample = ms + 500;
            int p = ping(mc);
            if (p >= 0) push(PING_HIST, p);
            push(FPS_SAMPLES, fps);
        }
    }

    /** Bumped whenever a graph gets a new sample, so graphs only recompute their numbers then. */
    public static int version;

    private static void push(ArrayDeque<Float> q, float v) {
        version++;
        q.addLast(v);
        while (q.size() > GRAPH_SAMPLES) q.removeFirst();
    }
}
