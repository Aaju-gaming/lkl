package studio.blackcat.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import studio.blackcat.client.Modules;
import studio.blackcat.client.hud.Style;
import studio.blackcat.client.util.Gfx;

/** Edit the text settings: Auto GG message, chat filter words, quick commands, waypoint, cat look. */
public class TextSettingsScreen extends Screen {
    private static final String[][] ROWS = {
            {"Auto GG message", "autogg"},
            {"Auto GG triggers (comma list)", "autogg_trigger"},
            {"Chat filter words (comma list)", "filter"},
            {"Quick commands (alias=/cmd;...)", "quick"},
            {"Waypoint X", "wp_x"},
            {"Waypoint Z", "wp_z"},
            {"Durability warning %", "durability_pct"},
            {"Cat size (24-80)", "cat_size"},
            {"Cat style (auto/awake/sleepy)", "cat_style"},
            {"Crosshair style (plus/dot/circle/cross)", "xh_style"},
            {"Crosshair colour (hex, e.g. 7EE3B0)", "xh_color"},
            {"Crosshair size (2-12)", "xh_size"},
            {"Crosshair gap (0-8, cross style)", "xh_gap"},
    };
    private static final int W = 320;
    private static final int ROW_H = 26;

    private int editing = -1;
    private String buffer = "";
    private int mx, my;

    public TextSettingsScreen() {
        super(Component.literal("Settings"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private void commit() {
        if (editing >= 0) Modules.setText(ROWS[editing][1], buffer);
        editing = -1;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        mx = mouseX;
        my = mouseY;
        g.fill(0, 0, this.width, this.height, 0x99000000);
        int x = (this.width - W) / 2;
        int h = 28 + ROWS.length * ROW_H + 18;
        int y = Math.max(4, (this.height - h) / 2);
        Gfx.roundRectV(g, x, y, W, h, 6, Style.panelTop(), Style.panelBottom());
        Gfx.roundOutline(g, x, y, W, h, 6, Style.panelEdge());
        Gfx.text(g, this.font, "Text settings", x + 12, y + 9, Style.WHITE);
        for (int i = 0; i < ROWS.length; i++) {
            int ry = y + 26 + i * ROW_H;
            Gfx.text(g, this.font, ROWS[i][0], x + 12, ry, Style.DIM);
            boolean on = editing == i;
            Gfx.roundRect(g, x + 10, ry + 10, W - 20, 13, 3, on ? 0xFF26262C : 0xFF1A1A1F);
            Gfx.roundOutline(g, x + 10, ry + 10, W - 20, 13, 3, on ? Style.accent() : 0xFF2A2A30);
            String v = on ? buffer + ((System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "") : Modules.text(ROWS[i][1]);
            String shownText = Gfx.fit(this.font, v.isEmpty() ? "(empty)" : v, W - 30);
            Gfx.text(g, this.font, shownText, x + 14, ry + 13, v.isEmpty() && !on ? Style.DIM : Style.WHITE);
        }
        Gfx.text(g, this.font, "Click a field, type, Enter to save. Esc to close.", x + 12, y + h - 13, Style.DIM);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        int x = (this.width - W) / 2;
        int h = 28 + ROWS.length * ROW_H + 18;
        int y = Math.max(4, (this.height - h) / 2);
        commit();
        for (int i = 0; i < ROWS.length; i++) {
            int ry = y + 26 + i * ROW_H;
            if (mx >= x + 10 && mx < x + W - 10 && my >= ry + 8 && my < ry + 24) {
                editing = i;
                buffer = Modules.text(ROWS[i][1]);
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (editing >= 0 && buffer.length() < 200) buffer += event.codepointAsString();
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int code = InputConstants.getKey(event).getValue();
        if (event.isEscape()) {
            if (editing >= 0) editing = -1;
            else if (this.minecraft != null) this.minecraft.gui.setScreen(null);
            return true;
        }
        if (editing >= 0) {
            if (code == GLFW.GLFW_KEY_BACKSPACE && !buffer.isEmpty()) buffer = buffer.substring(0, buffer.length() - 1);
            else if (code == GLFW.GLFW_KEY_ENTER || code == GLFW.GLFW_KEY_KP_ENTER) commit();
            return true;
        }
        return super.keyPressed(event);
    }
}
