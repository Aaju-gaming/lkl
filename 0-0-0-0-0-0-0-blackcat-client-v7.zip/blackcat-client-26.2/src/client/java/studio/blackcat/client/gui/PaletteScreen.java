package studio.blackcat.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.hud.Style;
import studio.blackcat.client.util.Gfx;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Command Palette: type to search every client feature, Up/Down + Enter (or tap) to run one. */
public class PaletteScreen extends Screen {
    private record Entry(String label, String hint, Runnable run) {}

    private static final int W = 260;
    private static final int ROW = 18;
    private static final int ROWS = 8;

    private final List<Entry> all = new ArrayList<>();
    private List<Entry> shown = new ArrayList<>();
    private String query = "";
    private int sel;
    private int mx, my;
    private float open;

    public PaletteScreen() {
        super(Component.literal("Command Palette"));
        all.add(new Entry("Open Black Cat menu", "page", () -> go(new GlassMenuScreen())));
        all.add(new Entry("Edit HUD layout", "page", () -> go(new HudEditorScreen())));
        all.add(new Entry("Edit text settings", "page", () -> go(new TextSettingsScreen())));
        all.add(new Entry("Reset all HUD positions", "action", () -> {
            Modules.resetAllPos();
            close();
        }));
        all.add(new Entry("Music: play / pause", "music", () -> {
            studio.blackcat.client.Music.toggle();
            close();
        }));
        all.add(new Entry("Music: restart song", "music", () -> {
            studio.blackcat.client.Music.restart();
            close();
        }));
        all.add(new Entry("Music: skip back 5s", "music", () -> {
            studio.blackcat.client.Music.seek(-5000);
            close();
        }));
        all.add(new Entry("Music: skip forward 5s", "music", () -> {
            studio.blackcat.client.Music.seek(5000);
            close();
        }));
        all.add(new Entry("Lyrics: show sooner (0.5s)", "music", () -> {
            studio.blackcat.client.Music.nudge(500);
            close();
        }));
        all.add(new Entry("Lyrics: show later (0.5s)", "music", () -> {
            studio.blackcat.client.Music.nudge(-500);
            close();
        }));
        all.add(new Entry("Music: clear song", "music", () -> {
            studio.blackcat.client.Music.clear();
            close();
        }));
        for (Module m : Module.values()) {
            all.add(new Entry("Toggle " + m.title, m.category.title, () -> {
                Modules.toggle(m);
                close();
            }));
        }
        for (int i = 0; i < Modules.PRESET_NAMES.length; i++) {
            final int pi = i;
            all.add(new Entry("Visual preset: " + Modules.PRESET_NAMES[i], "theme", () -> {
                Modules.applyPreset(pi);
                close();
            }));
        }
        for (String p : Modules.profileNames()) {
            all.add(new Entry("Load profile: " + p, "profile", () -> {
                Modules.loadProfile(p);
                close();
            }));
        }
        refilter();
    }

    private void go(Screen s) {
        if (this.minecraft != null) this.minecraft.gui.setScreen(s);
    }

    private void close() {
        if (this.minecraft != null) this.minecraft.gui.setScreen(null);
    }

    private void refilter() {
        String q = query.toLowerCase(Locale.ROOT).trim();
        shown = new ArrayList<>();
        for (Entry e : all) {
            if (q.isEmpty() || e.label.toLowerCase(Locale.ROOT).contains(q) || e.hint.toLowerCase(Locale.ROOT).contains(q)) shown.add(e);
        }
        sel = Math.max(0, Math.min(sel, shown.size() - 1));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private int px() {
        return (this.width - W) / 2;
    }

    private int py() {
        return Math.max(20, this.height / 5);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        mx = mouseX;
        my = mouseY;
        open = Math.min(1f, open + 0.12f);
        float t = Gfx.easeOutCubic(open);
        g.fill(0, 0, this.width, this.height, Gfx.mulAlpha(0xFF000000, 0.45f * t));
        int x = px();
        int y = py() + Math.round((1f - t) * -8f);
        int h = 30 + Math.min(ROWS, Math.max(1, shown.size())) * ROW + 6;
        Gfx.roundRectV(g, x, y, W, h, 6, Gfx.mulAlpha(Style.panelTop(), t), Gfx.mulAlpha(Style.panelBottom(), t));
        Gfx.roundOutline(g, x, y, W, h, 6, Gfx.mulAlpha(Style.panelEdge(), t));
        String q = query.isEmpty() ? "Search features..." : query;
        boolean caret = (System.currentTimeMillis() / 500) % 2 == 0;
        Gfx.text(g, this.font, q + (caret && !query.isEmpty() ? "_" : ""), x + 12, y + 11,
                Gfx.mulAlpha(query.isEmpty() ? Style.DIM : Style.WHITE, t));
        g.fill(x + 8, y + 26, x + W - 8, y + 27, Gfx.mulAlpha(0xFF2A2A30, t));

        int first = Math.max(0, Math.min(sel - ROWS + 1, Math.max(0, shown.size() - ROWS)));
        for (int i = 0; i < ROWS && first + i < shown.size(); i++) {
            Entry e = shown.get(first + i);
            int ry = y + 30 + i * ROW;
            boolean hov = mx >= x && mx < x + W && my >= ry && my < ry + ROW;
            boolean on = first + i == sel;
            if (on || hov) Gfx.roundRect(g, x + 6, ry, W - 12, ROW - 2, 4, Gfx.mulAlpha(on ? 0xFF26262C : 0xFF1C1C21, t));
            Gfx.text(g, this.font, Gfx.fit(this.font, e.label, W - 90), x + 12, ry + 5, Gfx.mulAlpha(on ? Style.WHITE : 0xFFC8C8CE, t));
            Gfx.text(g, this.font, e.hint, x + W - 12 - Gfx.width(this.font, e.hint), ry + 5, Gfx.mulAlpha(Style.DIM, t));
        }
        if (shown.isEmpty()) Gfx.text(g, this.font, "Nothing matches", x + 12, y + 35, Gfx.mulAlpha(Style.DIM, t));
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (query.length() < 40) {
            query += event.codepointAsString();
            sel = 0;
            refilter();
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int code = InputConstants.getKey(event).getValue();
        if (event.isEscape()) {
            close();
            return true;
        }
        if (code == GLFW.GLFW_KEY_BACKSPACE) {
            if (!query.isEmpty()) query = query.substring(0, query.length() - 1);
            sel = 0;
            refilter();
            return true;
        }
        if (code == GLFW.GLFW_KEY_DOWN) {
            if (!shown.isEmpty()) sel = (sel + 1) % shown.size();
            return true;
        }
        if (code == GLFW.GLFW_KEY_UP) {
            if (!shown.isEmpty()) sel = (sel - 1 + shown.size()) % shown.size();
            return true;
        }
        if (code == GLFW.GLFW_KEY_ENTER || code == GLFW.GLFW_KEY_KP_ENTER) {
            if (!shown.isEmpty()) shown.get(sel).run.run();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        int x = px();
        int y = py();
        int first = Math.max(0, Math.min(sel - ROWS + 1, Math.max(0, shown.size() - ROWS)));
        for (int i = 0; i < ROWS && first + i < shown.size(); i++) {
            int ry = y + 30 + i * ROW;
            if (mx >= x && mx < x + W && my >= ry && my < ry + ROW) {
                shown.get(first + i).run.run();
                return true;
            }
        }
        if (mx < x || mx > x + W) close();
        return true;
    }
}
