package studio.blackcat.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * All saved settings: which modules are on, where each HUD element sits, the accent colour,
 * HUD opacity and the cat badge. Stored in config/blackcat.json.
 */
public final class Modules {
    private Modules() {}

    /** Groups for the Module Manager filter row. */
    public enum Category {
        HUD("HUD"), COMBAT("Combat"), MOVEMENT("Move"), WORLD("World"), CHAT("Chat"), UTILITY("Utility");
        public final String title;
        Category(String t) { this.title = t; }
    }

    public enum Module {
        FPS("FPS Counter", "Current + average", Category.HUD),
        CPS("CPS", "Clicks per second", Category.COMBAT),
        KEYSTROKES("Keystrokes", "WASD + mouse", Category.HUD),
        COORDS("Coordinates", "Your position", Category.WORLD),
        PING("Ping", "Latency", Category.HUD),
        ARMOR("Armor HUD", "Durability", Category.COMBAT),
        POTIONS("Potion HUD", "Effects + timers", Category.COMBAT),
        DIRECTION("Direction HUD", "N / E / S / W compass", Category.WORLD),
        CLOCK("Clock", "Real-world time", Category.HUD),
        ITEM("Item HUD", "Held item + durability", Category.HUD),
        BIOME("Biome HUD", "Current biome", Category.WORLD),
        CPS_GRAPH("CPS Graph", "Live click history", Category.HUD),
        PING_GRAPH("Ping Graph", "Latency + min/avg/max", Category.HUD),
        FPS_GRAPH("FPS Graph", "Frame rate history", Category.HUD),
        TARGET("Target Info", "Name, health + armor of target", Category.COMBAT),
        NAME("Name Tag", "Your name on screen", Category.HUD),
        LOGO("Logo", "Black Cat badge", Category.HUD),
        FREELOOK("Freelook", "Press key to look around", Category.MOVEMENT),
        // ---- v0.6 ----
        PEARL("Pearl Tracker", "Ender pearl cooldown", Category.COMBAT),
        HITS("Hit Counter", "Hits landed this fight", Category.COMBAT),
        COMBO("Combo Counter", "Hits in a row", Category.COMBAT),
        REACH("Reach Display", "Distance of your last hit", Category.COMBAT),
        COMBAT_TIMER("Combat Timer", "Seconds since your last hit", Category.COMBAT),
        POTION_WARN("Potion Warning", "Effects about to run out", Category.COMBAT),
        TOTEM("Totem Alert", "Totems in your inventory", Category.COMBAT),
        SPEED("Speed", "Blocks per second", Category.MOVEMENT),
        JUMPS("Jump Counter", "Jumps this session", Category.MOVEMENT),
        SPRINT("Sprint Status", "Sprinting / walking / sneaking", Category.MOVEMENT),
        FALL("Fall Distance", "Blocks fallen so far", Category.MOVEMENT),
        GROUND("Ground Indicator", "On the ground or in the air", Category.MOVEMENT),
        MOTION("Motion Graph", "Speed history", Category.MOVEMENT),
        ELYTRA("Elytra HUD", "Flight speed + height", Category.MOVEMENT),
        WEATHER("Weather", "Rain or clear", Category.WORLD),
        TIME("Time HUD", "In-game time", Category.WORLD),
        WORLD_INFO("World Info", "Dimension + light", Category.WORLD),
        INV_PREVIEW("Inventory Preview", "Hotbar items at a glance", Category.UTILITY),
        ITEM_COUNT("Item Counter", "How many of the held item", Category.UTILITY),
        DURABILITY_WARN("Durability Warning", "Warns when gear is nearly broken", Category.UTILITY),
        SESSION("Session Stats", "Playtime, hits, jumps", Category.UTILITY),
        SERVER("Server Info", "Address + players", Category.UTILITY),
        WAYPOINT("Waypoint HUD", "Distance to your waypoint", Category.WORLD),
        CROSSHAIR("Crosshair", "Custom crosshair + hit colour", Category.COMBAT),
        AUTO_GG("Auto GG", "Sends a message when a game ends", Category.CHAT),
        QUICK_CMD("Quick Commands", "Short aliases for commands", Category.CHAT),
        TIMESTAMPS("Chat Timestamps", "[12:34] in front of chat", Category.CHAT),
        CHAT_FILTER("Chat Filter", "Hide messages with chosen words", Category.CHAT),
        CAT("Cat Companion", "Mascot that reacts to what you do", Category.HUD),
        NOTIFY("Notifications", "Small pop-ups from the client", Category.HUD),
        DASHBOARD("Dashboard", "Active modules + session", Category.UTILITY),
        MUSIC("Music + Lyrics", "Synced lyrics for the song you type in", Category.UTILITY);

        public final String title;
        public final String description;
        public final Category category;

        Module(String title, String description, Category category) {
            this.title = title;
            this.description = description;
            this.category = category;
        }
    }

    // ---------- cosmetics ----------

    public static final String[] ACCENT_NAMES = {"White", "Ice", "Mint", "Amber", "Rose", "Violet"};
    public static final int[] ACCENT_COLORS = {
            0xFFF2F2F5, 0xFF8FD3FF, 0xFF7EE3B0, 0xFFE8B84A, 0xFFFF7A90, 0xFFB79CFF};

    public static final float MIN_OPACITY = 0.3f;

    /** Settings of one HUD element. Defaults mean "follow the theme". */
    public static final class Opts {
        public float scale = 1f;
        public boolean bg = true;
        /** -1 = follow the global opacity. */
        public float opacity = -1f;
        /** 0 = follow the theme accent, otherwise an ARGB colour just for this element. */
        public int accent = 0;
        /** Gradient for this element: 0 = follow the theme, 1 = on, 2 = off. */
        public int grad = 0;
        /** Second gradient colour for this element; 0 = the theme's second colour. */
        public int accent2 = 0;

        boolean isDefault() {
            return scale == 1f && bg && opacity < 0f && accent == 0 && grad == 0 && accent2 == 0;
        }
    }

    /** A saved colour theme. */
    public static final class Theme {
        public String name;
        public int accentIdx;
        public int accentCustom;
        public boolean gradient;
        public int accent2;
        public float opacity;
        public int look;
    }

    // ---------- state ----------

    private static final Set<Module> ENABLED = EnumSet.of(
            Module.FPS, Module.CPS, Module.KEYSTROKES, Module.NAME, Module.FREELOOK);
    /** Moved HUD elements: module -> {x / screenWidth, y / screenHeight}. Missing = default spot. */
    private static final Map<Module, float[]> POS = new EnumMap<>(Module.class);
    private static final Map<Module, Opts> OPTS = new EnumMap<>(Module.class);
    private static final List<Theme> THEMES = new ArrayList<>();
    /** 0..5 = preset, -1 = custom colour. */
    private static int accent = 0;
    private static int accentCustom = 0xFFF2F2F5;
    private static boolean gradient = false;
    private static int accent2 = 0xFF8FD3FF;
    private static float opacity = 0.85f;
    private static boolean nameBadge = true;
    private static String profile = "Default";
    private static int look = 0;
    private static final Set<Module> FAV_MODULES = EnumSet.noneOf(Module.class);
    private static final Set<String> FAV_PROFILES = new java.util.HashSet<>();
    /** Free-text settings (Auto GG message, chat filter words, quick commands, waypoint). */
    private static final Map<String, String> TEXT = new java.util.LinkedHashMap<>();
    static {
        TEXT.put("groups", "");
        TEXT.put("music_query", "");
        TEXT.put("autogg", "gg");
        TEXT.put("autogg_trigger", "you won,victory,game over,winner");
        TEXT.put("filter", "");
        TEXT.put("quick", "gm=/gamemode creative;h=/home;s=/spawn");
        TEXT.put("wp_x", "0");
        TEXT.put("wp_z", "0");
        TEXT.put("durability_pct", "10");
        TEXT.put("cat_size", "40");
        TEXT.put("cat_style", "auto");
        TEXT.put("xh_style", "plus");
        TEXT.put("xh_color", "FFFFFF");
        TEXT.put("xh_size", "5");
        TEXT.put("xh_gap", "2");
    }

    public static String text(String key) {
        String v = TEXT.get(key);
        return v == null ? "" : v;
    }

    public static void setText(String key, String value) {
        if (value == null) value = "";
        TEXT.put(key, value.length() > 600 ? value.substring(0, 600) : value);
        save();
    }

    public static double textNum(String key, double def) {
        try {
            return Double.parseDouble(text(key).trim());
        } catch (Exception e) {
            return def;
        }
    }

    /** Built-in visual presets: name, look, accent, gradient on/off, second colour, opacity. */
    public static final String[] PRESET_NAMES = {"Noir", "Frost", "Ember", "Aurora", "Slate"};
    private static final Object[][] PRESETS = {
            {1, 0xFFF2F2F5, false, 0xFF8C8C95, 0.90f},
            {2, 0xFF8FD3FF, true, 0xFFB79CFF, 0.80f},
            {0, 0xFFE8B84A, true, 0xFFFF7A90, 0.88f},
            {2, 0xFF7EE3B0, true, 0xFFB79CFF, 0.75f},
            {0, 0xFFB8BCC8, false, 0xFF8C8C95, 0.92f},
    };

    public static void applyPreset(int i) {
        if (i < 0 || i >= PRESETS.length) return;
        Object[] p = PRESETS[i];
        look = (Integer) p[0];
        accent = -1;
        accentCustom = (Integer) p[1];
        gradient = (Boolean) p[2];
        accent2 = (Integer) p[3];
        setOpacity((Float) p[4]);
        save();
        try {
            studio.blackcat.client.hud.Notify.push("Preset: " + PRESET_NAMES[i]);
        } catch (Throwable ignored) {
            // ignore
        }
    }

    // ---- editor undo/redo + widget groups ----

    /** The whole layout/theme state as text, for undo/redo. */
    public static String snapshot() {
        return stateJson().toString();
    }

    public static void restoreSnapshot(String s) {
        try {
            readState(JsonParser.parseString(s).getAsJsonObject());
            save();
        } catch (Exception e) {
            logError("undo", e);
        }
    }

    /** Groups of widgets that move together: stored in the text setting "groups" as "FPS,CPS;PING,COORDS". */
    private static String groupsRaw;
    private static List<List<Module>> groupsCache = List.of();

    public static List<List<Module>> groups() {
        String raw = text("groups");
        if (raw.equals(groupsRaw)) return groupsCache; // called every frame by the editor: parse only when it changed
        List<List<Module>> out = new ArrayList<>();
        if (!raw.isBlank()) {
            for (String g : raw.split(";")) {
                List<Module> l = new ArrayList<>();
                for (String n : g.split(",")) {
                    n = n.trim();
                    if (n.isEmpty()) continue;
                    try {
                        l.add(Module.valueOf(n));
                    } catch (IllegalArgumentException ignored) {
                        // unknown module
                    }
                }
                if (l.size() >= 2) out.add(l);
            }
        }
        groupsRaw = raw;
        groupsCache = out;
        return out;
    }

    public static List<Module> groupOf(Module m) {
        for (List<Module> g : groups()) if (g.contains(m)) return g;
        return List.of();
    }

    public static void setGroups(List<List<Module>> groups) {
        StringBuilder sb = new StringBuilder();
        for (List<Module> g : groups) {
            if (g.size() < 2) continue;
            if (sb.length() > 0) sb.append(';');
            for (int i = 0; i < g.size(); i++) sb.append(i > 0 ? "," : "").append(g.get(i).name());
        }
        TEXT.put("groups", sb.toString());
        save();
    }

    /** Puts the given modules in one group (taking them out of any other group). */
    public static void group(List<Module> members) {
        List<List<Module>> all = new ArrayList<>();
        for (List<Module> g : groups()) {
            List<Module> rest = new ArrayList<>(g);
            rest.removeAll(members);
            if (rest.size() >= 2) all.add(rest);
        }
        all.add(new ArrayList<>(members));
        setGroups(all);
    }

    public static void ungroup(Module m) {
        List<List<Module>> all = new ArrayList<>();
        for (List<Module> g : groups()) {
            List<Module> rest = new ArrayList<>(g);
            rest.remove(m);
            if (rest.size() >= 2) all.add(rest);
        }
        setGroups(all);
    }

    private static final java.util.Set<String> LOGGED = new java.util.HashSet<>();

    /** Writes an error to config/blackcat/errors.log (once per kind per session) and tells the player. */
    public static void logError(String where, Throwable t) {
        if (!LOGGED.add(where + t.getClass().getName())) return;
        System.err.println("[blackcat] error in " + where + ": " + t);
        try {
            String line = java.time.LocalDateTime.now() + "  " + where + "  " + t + System.lineSeparator();
            Files.writeString(dir("logs").resolve("errors.log"), line,
                    java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
        } catch (Exception ignored) {
            // logging is best effort
        }
        try {
            studio.blackcat.client.hud.Notify.push("Error in " + where + " (see logs/errors.log)");
        } catch (Throwable ignored) {
            // ignore
        }
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("blackcat.json");
    }

    public static Path dir(String sub) {
        Path d = FabricLoader.getInstance().getConfigDir().resolve("blackcat").resolve(sub);
        try {
            Files.createDirectories(d);
        } catch (IOException ignored) {
            // reported when saving
        }
        return d;
    }

    // ---------- modules ----------

    public static boolean isEnabled(Module m) {
        return ENABLED.contains(m);
    }

    public static boolean anyEnabled() {
        return !ENABLED.isEmpty();
    }

    public static void toggle(Module m) {
        boolean on = !ENABLED.remove(m);
        if (on) ENABLED.add(m);
        save();
        try {
            studio.blackcat.client.hud.Notify.push(m.title + (on ? " on" : " off"));
        } catch (Throwable ignored) {
            // notifications must never break toggling
        }
    }

    // ---------- HUD positions ----------

    /** Saved position of an element as screen fractions, or null if it is still at its default spot. */
    public static float[] pos(Module m) {
        return POS.get(m);
    }

    /** Remembers a new position in memory; call save() when the drag ends. */
    public static void setPos(Module m, float fx, float fy) {
        POS.put(m, new float[]{fx, fy});
    }

    public static void resetPos(Module m) {
        POS.remove(m);
    }

    public static void resetAllPos() {
        POS.clear();
    }

    // ---------- per-element settings ----------

    /** The settings of one element (created on first use). Call save() after changing them. */
    public static Opts opts(Module m) {
        return OPTS.computeIfAbsent(m, k -> new Opts());
    }

    /** Puts one element back to its default spot and default look. */
    public static void resetModule(Module m) {
        POS.remove(m);
        OPTS.remove(m);
        save();
    }

    // ---------- theme ----------

    public static int accentIndex() {
        return accent;
    }

    /** The main accent colour (preset or custom). */
    public static int accent() {
        return accent < 0 ? accentCustom : ACCENT_COLORS[Math.min(accent, ACCENT_COLORS.length - 1)];
    }

    public static boolean gradient() {
        return gradient;
    }

    public static int accent2() {
        return accent2;
    }

    /** Accent along a gradient: f = 0 is the main colour, f = 1 the second one (if gradients are on). */
    public static int accentAt(float f) {
        if (!gradient) return accent();
        return studio.blackcat.client.util.Gfx.lerpColor(accent(), accent2, Math.max(0f, Math.min(1f, f)));
    }

    public static void setAccent(int i) {
        accent = Math.max(0, Math.min(ACCENT_COLORS.length - 1, i));
        save();
    }

    /** Custom colour from sliders; call save() when the slider is released. */
    public static void setCustomAccent(int r, int g, int b) {
        accentCustom = 0xFF000000 | (clamp255(r) << 16) | (clamp255(g) << 8) | clamp255(b);
        accent = -1;
    }

    public static int customAccent() {
        return accentCustom;
    }

    public static void setAccent2(int color) {
        accent2 = 0xFF000000 | (color & 0xFFFFFF);
        save();
    }

    public static void toggleGradient() {
        gradient = !gradient;
        save();
    }

    private static int clamp255(int v) {
        return Math.max(0, Math.min(255, v));
    }

    public static float opacity() {
        return opacity;
    }

    /** Remembers the opacity in memory (clamped); call save() when the slider is released. */
    public static void setOpacity(float v) {
        opacity = Math.max(MIN_OPACITY, Math.min(1f, v));
    }

    public static boolean nameBadge() {
        return nameBadge;
    }

    public static void toggleNameBadge() {
        nameBadge = !nameBadge;
        save();
    }

    // ---------- look: 0 matte, 1 monochrome, 2 frosted glass ----------

    public static int look() {
        return look;
    }

    public static void setLook(int l) {
        look = Math.max(0, Math.min(2, l));
        save();
    }

    // ---------- favourites ----------

    public static boolean isFavModule(Module m) {
        return FAV_MODULES.contains(m);
    }

    public static void toggleFavModule(Module m) {
        if (!FAV_MODULES.remove(m)) FAV_MODULES.add(m);
        save();
    }

    public static boolean isFavProfile(String name) {
        return FAV_PROFILES.contains(name);
    }

    public static void toggleFavProfile(String name) {
        if (!FAV_PROFILES.remove(name)) FAV_PROFILES.add(name);
        save();
    }

    // ---------- saved themes ----------

    public static List<Theme> themes() {
        return THEMES;
    }

    public static void saveTheme() {
        Theme t = new Theme();
        t.name = "Theme " + (THEMES.size() + 1);
        t.accentIdx = accent;
        t.accentCustom = accentCustom;
        t.gradient = gradient;
        t.accent2 = accent2;
        t.opacity = opacity;
        t.look = look;
        THEMES.add(t);
        save();
    }

    public static void applyTheme(Theme t) {
        accent = t.accentIdx;
        accentCustom = t.accentCustom;
        gradient = t.gradient;
        accent2 = t.accent2;
        setOpacity(t.opacity);
        look = t.look;
        save();
    }

    public static void deleteTheme(Theme t) {
        THEMES.remove(t);
        save();
    }

    // ---------- profiles ----------

    public static String profileName() {
        return profile;
    }

    /** What the Profiles page shows about a profile (cached, so the page never reads files while drawing). */
    public record ProfileInfo(String name, String server, int accent, int accent2, boolean gradient, int look,
                              int enabledCount, boolean favorite) {}

    private static List<ProfileInfo> infoCache;

    private static void invalidate() {
        infoCache = null;
    }

    /** All profiles, favourites first, then by name. */
    public static List<ProfileInfo> profileInfos() {
        if (infoCache != null) return infoCache;
        List<ProfileInfo> out = new ArrayList<>();
        try (var st = Files.list(dir("profiles"))) {
            st.forEach(p -> {
                String f = p.getFileName().toString();
                if (!f.endsWith(".json")) return;
                String name = f.substring(0, f.length() - 5);
                try { // one broken file must not hide the others
                JsonObject o = readJson(p);
                if (o == null) return;
                int acc = o.has("accent") ? o.get("accent").getAsInt() : 0;
                int c1 = acc < 0 ? (o.has("accentCustom") ? o.get("accentCustom").getAsInt() : 0xFFF2F2F5)
                        : ACCENT_COLORS[Math.min(acc, ACCENT_COLORS.length - 1)];
                int c2 = o.has("accent2") ? o.get("accent2").getAsInt() : c1;
                boolean grad = o.has("gradient") && o.get("gradient").getAsBoolean();
                int lk = o.has("look") ? o.get("look").getAsInt() : 0;
                int n = o.has("enabled") ? o.getAsJsonArray("enabled").size() : 0;
                String server = o.has("server") ? o.get("server").getAsString() : "";
                out.add(new ProfileInfo(name, server, c1, c2, grad, lk, n, FAV_PROFILES.contains(name)));
                } catch (Exception bad) {
                    System.err.println("[blackcat] skipping unreadable profile " + name + ": " + bad);
                }
            });
        } catch (Exception ignored) {
            // empty list
        }
        out.sort((x, y) -> x.favorite() != y.favorite() ? (x.favorite() ? -1 : 1) : x.name().compareToIgnoreCase(y.name()));
        infoCache = out;
        return out;
    }

    /** Names of the saved profiles (favourites first). */
    public static List<String> profileNames() {
        List<String> out = new ArrayList<>();
        for (ProfileInfo i : profileInfos()) out.add(i.name());
        return out;
    }

    /** Saves the current layout and theme as a profile (keeps its auto-switch server if it already existed). */
    public static void saveProfile(String name) {
        name = ProfileCodec.safeName(name);
        String server = profileServer(name);
        JsonObject o = stateJson();
        if (!server.isEmpty()) o.addProperty("server", server);
        writeJson(dir("profiles").resolve(name + ".json"), o);
        invalidate();
        profile = name;
        save();
    }

    public static String newProfileName() {
        return ProfileCodec.uniqueName("Profile", profileNames());
    }

    /** Reads a layout/theme file through the same checks as an import, so a hand-edited or damaged file cannot crash the game. */
    private static JsonObject readChecked(Path f) {
        try {
            if (!Files.exists(f) || Files.size(f) > ProfileCodec.MAX_BYTES) return null;
            ProfileCodec.Result r = ProfileCodec.validate(Files.readString(f), MODULE_NAMES);
            return r.ok() ? r.profile() : null;
        } catch (Exception e) {
            System.err.println("[blackcat] could not read " + f + ": " + e);
            return null;
        }
    }

    public static boolean loadProfile(String name) {
        JsonObject o = readChecked(dir("profiles").resolve(name + ".json"));
        if (o == null) return false;
        readState(o);
        profile = name;
        save();
        try {
            studio.blackcat.client.hud.Notify.push("Profile: " + name);
        } catch (Throwable ignored) {
            // ignore
        }
        return true;
    }

    public static void deleteProfile(String name) {
        try {
            Files.deleteIfExists(dir("profiles").resolve(name + ".json"));
        } catch (IOException ignored) {
            // nothing to do
        }
        FAV_PROFILES.remove(name);
        invalidate();
        save();
    }

    /** Copies a profile under a new name ("Name (2)"). Returns the new name or null. */
    public static String duplicateProfile(String name) {
        JsonObject o = readJson(dir("profiles").resolve(name + ".json"));
        if (o == null) return null;
        o.remove("server"); // the copy must not fight the original over the same server
        String copy = ProfileCodec.uniqueName(name, profileNames());
        writeJson(dir("profiles").resolve(copy + ".json"), o);
        invalidate();
        return copy;
    }

    public static String profileServer(String name) {
        for (ProfileInfo i : profileInfos()) if (i.name().equals(name)) return i.server();
        return "";
    }

    /** Makes a profile switch on automatically when you join this server ("" = off). */
    public static void setProfileServer(String name, String server) {
        JsonObject o = readJson(dir("profiles").resolve(name + ".json"));
        if (o == null) return;
        String host = normalizeHost(server);
        if (host.isEmpty()) {
            o.remove("server");
        } else {
            o.addProperty("server", host);
            // one server -> one profile: take the binding away from any other profile that has it
            for (ProfileInfo i : profileInfos()) {
                if (!i.name().equals(name) && normalizeHost(i.server()).equals(host)) {
                    JsonObject other = readJson(dir("profiles").resolve(i.name() + ".json"));
                    if (other != null) {
                        other.remove("server");
                        writeJson(dir("profiles").resolve(i.name() + ".json"), other);
                    }
                }
            }
        }
        writeJson(dir("profiles").resolve(name + ".json"), o);
        invalidate();
    }

    /** "Play.Example.com:25565." -> "play.example.com" (lower case, no port, no trailing dot). */
    public static String normalizeHost(String address) {
        if (address == null) return "";
        String h = address.trim().toLowerCase();
        int slash = h.indexOf('/');
        if (slash >= 0) h = h.substring(0, slash);
        if (h.startsWith("[")) { // [ipv6]:port
            int close = h.indexOf(']');
            return close > 0 ? h.substring(1, close) : h;
        }
        int colon = h.lastIndexOf(':');
        if (colon > 0 && h.indexOf(':') == colon) h = h.substring(0, colon); // single colon = host:port
        while (h.endsWith(".")) h = h.substring(0, h.length() - 1);
        return h;
    }

    /** True if joined host is the bound host or one of its subdomains (mc.example.com matches example.com, notexample.com does not). */
    static boolean hostMatches(String joined, String bound) {
        if (joined.isEmpty() || bound.isEmpty()) return false;
        return joined.equals(bound) || joined.endsWith("." + bound);
    }

    /**
     * Which profile (if any) should switch on for this address: the most specific binding wins
     * (longest host), then favourites, then name. Returns null if none match.
     */
    public static String profileForServer(String address) {
        String joined = normalizeHost(address);
        ProfileInfo best = null;
        String bestHost = "";
        for (ProfileInfo i : profileInfos()) { // already favourites first, then by name
            String bound = normalizeHost(i.server());
            if (!hostMatches(joined, bound)) continue;
            if (best == null || bound.length() > bestHost.length()) {
                best = i;
                bestHost = bound;
            }
        }
        return best == null ? null : best.name();
    }

    /** Loads the profile bound to this server address, if there is one. */
    public static void autoSwitch(String address) {
        String name = profileForServer(address);
        if (name != null && !name.equals(profile)) loadProfile(name);
    }

    /** Copies a profile to config/blackcat/export/ so it can be shared. */
    public static boolean exportProfile(String name) {
        JsonObject o = readJson(dir("profiles").resolve(name + ".json"));
        if (o == null) return false;
        o.remove("server");
        writeJson(dir("export").resolve(name + ".json"), o);
        return true;
    }

    private static final Set<String> MODULE_NAMES = new java.util.HashSet<>();

    static {
        for (Module m : Module.values()) MODULE_NAMES.add(m.name());
    }

    /** Brings in every .json from config/blackcat/import/ as a profile, after checking it. Returns a short report. */
    public static String importProfiles() {
        int ok = 0;
        List<String> problems = new ArrayList<>();
        try (var st = Files.list(dir("import"))) {
            for (Path p : (Iterable<Path>) st::iterator) {
                String f = p.getFileName().toString();
                if (!f.endsWith(".json")) continue;
                String text;
                try {
                    if (Files.size(p) > ProfileCodec.MAX_BYTES) {
                        problems.add(f + ": file is too big");
                        continue;
                    }
                    text = Files.readString(p);
                } catch (IOException e) {
                    problems.add(f + ": could not read");
                    continue;
                }
                ProfileCodec.Result r = ProfileCodec.validate(text, MODULE_NAMES);
                if (!r.ok()) {
                    problems.add(f + ": " + r.error());
                    continue;
                }
                String name = ProfileCodec.uniqueName(f.substring(0, f.length() - 5), profileNames());
                writeJson(dir("profiles").resolve(name + ".json"), r.profile());
                invalidate();
                ok++;
            }
        } catch (IOException ignored) {
            // nothing imported
        }
        if (ok == 0 && problems.isEmpty()) return "Nothing found in config/blackcat/import/";
        String msg = "Imported " + ok;
        if (!problems.isEmpty()) msg += ", skipped " + problems.size() + " (" + problems.get(0) + ")";
        return msg;
    }

    // ---------- backup & restore ----------

    /** Copies every profile and the main settings into config/blackcat/backups/<time>/. Returns the file count. */
    public static int backup() {
        String stamp = new java.text.SimpleDateFormat("yyyyMMdd-HHmmss").format(new java.util.Date());
        Path d = dir("backups").resolve(stamp);
        for (int i = 2; Files.exists(d); i++) d = dir("backups").resolve(stamp + "-" + i); // two backups in one second
        int n = 0;
        try {
            Files.createDirectories(d);
            if (Files.exists(file())) {
                Files.copy(file(), d.resolve("blackcat.json"));
                n++;
            }
            try (var st = Files.list(dir("profiles"))) {
                for (Path p : (Iterable<Path>) st::iterator) {
                    if (!p.getFileName().toString().endsWith(".json")) continue;
                    Files.copy(p, d.resolve("profile-" + p.getFileName()));
                    n++;
                }
            }
        } catch (IOException e) {
            System.err.println("[blackcat] backup failed: " + e);
        }
        return n;
    }

    /** Name of the newest backup folder, or null. */
    public static String latestBackup() {
        try (var st = Files.list(dir("backups"))) {
            return st.filter(Files::isDirectory).map(p -> p.getFileName().toString()).max(String::compareTo).orElse(null);
        } catch (IOException e) {
            return null;
        }
    }

    /** Puts the newest backup back (checked like an import). Returns a short report. */
    public static String restoreLatest() {
        String name = latestBackup();
        if (name == null) return "No backup yet";
        Path d = dir("backups").resolve(name);
        int ok = 0;
        int bad = 0;
        try (var st = Files.list(d)) {
            for (Path p : (Iterable<Path>) st::iterator) {
                String f = p.getFileName().toString();
                if (!f.endsWith(".json")) continue;
                ProfileCodec.Result r = ProfileCodec.validate(Files.readString(p), MODULE_NAMES);
                if (!r.ok()) {
                    bad++;
                    continue;
                }
                JsonObject o = r.profile();
                try { // keep the server binding of a backed-up profile
                    JsonObject raw = JsonParser.parseString(Files.readString(p)).getAsJsonObject();
                    if (raw.has("server")) o.add("server", raw.get("server"));
                } catch (Exception ignored) {
                    // no binding
                }
                if (f.equals("blackcat.json")) {
                    readState(o);
                    try { // themes, favourites and the active profile name come back too
                        readExtras(JsonParser.parseString(Files.readString(p)).getAsJsonObject());
                    } catch (Exception ignored) {
                        // state alone is fine
                    }
                    ok++;
                } else if (f.startsWith("profile-")) {
                    writeJson(dir("profiles").resolve(ProfileCodec.safeName(f.substring(8, f.length() - 5)) + ".json"), o);
                    ok++;
                }
            }
        } catch (IOException e) {
            return "Restore failed";
        }
        invalidate();
        save();
        return "Restored " + ok + " file(s) from " + name + (bad > 0 ? ", skipped " + bad : "");
    }

    /** Back to factory settings (themes and profiles are kept). */
    public static void resetEverything() {
        ENABLED.clear();
        ENABLED.addAll(EnumSet.of(Module.FPS, Module.CPS, Module.KEYSTROKES, Module.NAME, Module.FREELOOK));
        POS.clear();
        OPTS.clear();
        accent = 0;
        gradient = false;
        opacity = 0.85f;
        nameBadge = true;
        look = 0;
        save();
    }

    // ---------- json ----------

    private static JsonObject readJson(Path f) {
        if (!Files.exists(f)) return null;
        try (Reader r = Files.newBufferedReader(f)) {
            return JsonParser.parseReader(r).getAsJsonObject();
        } catch (Exception e) {
            System.err.println("[blackcat] could not read " + f + ": " + e);
            return null;
        }
    }

    private static void writeJson(Path f, JsonObject o) {
        try (Writer w = Files.newBufferedWriter(f)) {
            w.write(o.toString());
        } catch (IOException e) {
            System.err.println("[blackcat] could not save " + f + ": " + e);
        }
    }

    private static JsonObject stateJson() {
        JsonObject obj = new JsonObject();
        obj.addProperty("cfg", ProfileCodec.CURRENT_CFG);

        JsonArray arr = new JsonArray();
        for (Module m : ENABLED) arr.add(m.name());
        obj.add("enabled", arr);

        JsonObject pos = new JsonObject();
        for (var e : POS.entrySet()) {
            JsonArray a = new JsonArray();
            a.add(e.getValue()[0]);
            a.add(e.getValue()[1]);
            pos.add(e.getKey().name(), a);
        }
        obj.add("pos", pos);

        JsonObject opts = new JsonObject();
        for (var e : OPTS.entrySet()) {
            Opts o = e.getValue();
            if (o.isDefault()) continue;
            JsonObject j = new JsonObject();
            j.addProperty("scale", o.scale);
            j.addProperty("bg", o.bg);
            j.addProperty("opacity", o.opacity);
            j.addProperty("accent", o.accent);
            j.addProperty("grad", o.grad);
            j.addProperty("accent2", o.accent2);
            opts.add(e.getKey().name(), j);
        }
        obj.add("opts", opts);

        obj.addProperty("accent", accent);
        obj.addProperty("accentCustom", accentCustom);
        obj.addProperty("gradient", gradient);
        obj.addProperty("accent2", accent2);
        obj.addProperty("opacity", opacity);
        obj.addProperty("badge", nameBadge);
        obj.addProperty("look", look);
        return obj;
    }

    private static void readState(JsonObject obj) {
        int cfg = obj.has("cfg") ? obj.get("cfg").getAsInt() : 0;

        if (obj.has("enabled")) {
            ENABLED.clear();
            for (var el : obj.getAsJsonArray("enabled")) {
                try {
                    ENABLED.add(Module.valueOf(el.getAsString()));
                } catch (IllegalArgumentException ignored) {
                    // module removed in a newer/older version
                }
            }
        }
        if (cfg < 3) ENABLED.add(Module.NAME); // the name tag is new: switch it on once

        POS.clear();
        if (obj.has("pos")) {
            for (var e : obj.getAsJsonObject("pos").entrySet()) {
                try {
                    JsonArray a = e.getValue().getAsJsonArray();
                    POS.put(Module.valueOf(e.getKey()), new float[]{a.get(0).getAsFloat(), a.get(1).getAsFloat()});
                } catch (Exception ignored) {
                    // bad entry: skip it
                }
            }
        }

        OPTS.clear();
        if (obj.has("opts")) {
            for (var e : obj.getAsJsonObject("opts").entrySet()) {
                try {
                    JsonObject j = e.getValue().getAsJsonObject();
                    Opts o = new Opts();
                    o.scale = Math.max(0.5f, Math.min(2.5f, j.get("scale").getAsFloat()));
                    o.bg = j.get("bg").getAsBoolean();
                    o.opacity = j.get("opacity").getAsFloat();
                    o.accent = j.get("accent").getAsInt();
                    if (j.has("grad")) o.grad = Math.max(0, Math.min(2, j.get("grad").getAsInt()));
                    if (j.has("accent2")) o.accent2 = j.get("accent2").getAsInt();
                    OPTS.put(Module.valueOf(e.getKey()), o);
                } catch (Exception ignored) {
                    // bad entry: skip it
                }
            }
        }

        if (obj.has("accent")) accent = Math.max(-1, Math.min(ACCENT_COLORS.length - 1, obj.get("accent").getAsInt()));
        if (obj.has("accentCustom")) accentCustom = obj.get("accentCustom").getAsInt();
        if (obj.has("gradient")) gradient = obj.get("gradient").getAsBoolean();
        if (obj.has("accent2")) accent2 = obj.get("accent2").getAsInt();
        if (obj.has("opacity")) setOpacity(obj.get("opacity").getAsFloat());
        if (obj.has("badge")) nameBadge = obj.get("badge").getAsBoolean();
        if (obj.has("look")) look = Math.max(0, Math.min(2, obj.get("look").getAsInt()));
    }

    // ---------- file ----------

    public static void load() {
        JsonObject state = readChecked(file());
        if (state != null) readState(state); // damaged settings never stop the game: defaults are used instead
        JsonObject obj = readJson(file());
        if (obj == null) return;
        try {
            readExtras(obj);
        } catch (Exception e) {
            System.err.println("[blackcat] damaged themes/favourites ignored: " + e);
        }
    }

    /** Active profile name, favourites and saved themes (the parts of blackcat.json that are not layout/theme state). */
    private static void readExtras(JsonObject obj) {
        if (obj.has("profile")) profile = ProfileCodec.safeName(obj.get("profile").getAsString());
        FAV_MODULES.clear();
        FAV_PROFILES.clear();
        if (obj.has("favModules")) {
            for (var el : obj.getAsJsonArray("favModules")) {
                try {
                    FAV_MODULES.add(Module.valueOf(el.getAsString()));
                } catch (Exception ignored) {
                    // removed module
                }
            }
        }
        if (obj.has("favProfiles")) {
            for (var el : obj.getAsJsonArray("favProfiles")) FAV_PROFILES.add(el.getAsString());
        }
        if (obj.has("text") && obj.get("text").isJsonObject()) {
            for (var e : obj.getAsJsonObject("text").entrySet()) {
                try {
                    if (TEXT.containsKey(e.getKey())) TEXT.put(e.getKey(), e.getValue().getAsString());
                } catch (Exception ignored) {
                    // keep default
                }
            }
        }
        THEMES.clear();
        if (obj.has("themes")) {
            for (var el : obj.getAsJsonArray("themes")) {
                try {
                    JsonObject j = el.getAsJsonObject();
                    Theme t = new Theme();
                    t.name = j.get("name").getAsString();
                    t.accentIdx = j.get("accentIdx").getAsInt();
                    t.accentCustom = j.get("accentCustom").getAsInt();
                    t.gradient = j.get("gradient").getAsBoolean();
                    t.accent2 = j.get("accent2").getAsInt();
                    t.opacity = j.get("opacity").getAsFloat();
                    t.look = j.has("look") ? j.get("look").getAsInt() : 0;
                    THEMES.add(t);
                } catch (Exception ignored) {
                    // bad theme: skip it
                }
            }
        }
    }

    public static void save() {
        JsonObject obj = stateJson();
        obj.addProperty("profile", profile);
        JsonArray themes = new JsonArray();
        for (Theme t : THEMES) {
            JsonObject j = new JsonObject();
            j.addProperty("name", t.name);
            j.addProperty("accentIdx", t.accentIdx);
            j.addProperty("accentCustom", t.accentCustom);
            j.addProperty("gradient", t.gradient);
            j.addProperty("accent2", t.accent2);
            j.addProperty("opacity", t.opacity);
            j.addProperty("look", t.look);
            themes.add(j);
        }
        obj.add("themes", themes);
        JsonArray fm = new JsonArray();
        for (Module m : FAV_MODULES) fm.add(m.name());
        obj.add("favModules", fm);
        JsonArray fp = new JsonArray();
        for (String n : FAV_PROFILES) fp.add(n);
        obj.add("favProfiles", fp);
        JsonObject tx = new JsonObject();
        for (var e : TEXT.entrySet()) tx.addProperty(e.getKey(), e.getValue());
        obj.add("text", tx);
        writeJson(file(), obj);
    }
}
