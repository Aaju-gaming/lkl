package studio.blackcat.client.hud;

import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.util.Gfx;

/**
 * The matte black look: one palette shared by the HUD, the menu and the editor.
 * While an element is being drawn (begin/end) its own settings (opacity, background, accent) apply.
 */
public final class Style {
    private Style() {}

    public static final int EDGE = 0xFF25252B;
    public static final int TEXT = 0xFFEDEDED;
    public static final int DIM = 0xFF8C8C95;
    public static final int FAINT = 0xFF3A3A42;
    public static final int WHITE = 0xFFFFFFFF;
    public static final int AMBER = 0xFFE0B04A;
    public static final int RED = 0xFFD9534F;
    public static final int TRACK = 0xFF17171B;

    private static Module current;

    /** Everything drawn until end() uses this element's own settings. */
    public static void begin(Module m) {
        current = m;
    }

    public static void end() {
        current = null;
    }

    private static Modules.Opts opts() {
        return current == null ? null : Modules.opts(current);
    }

    public static final int LOOK_MATTE = 0;
    public static final int LOOK_MONO = 1;
    public static final int LOOK_FROSTED = 2;
    public static final String[] LOOK_NAMES = {"Matte", "Monochrome", "Frosted glass"};
    private static final int MONO_WHITE = 0xFFF2F2F5;
    private static final int MONO_GREY = 0xFF8C8C95;

    public static int look() {
        return Modules.look();
    }

    private static float alpha() {
        Modules.Opts o = opts();
        return o != null && o.opacity >= 0f ? o.opacity : Modules.opacity();
    }

    private static boolean noBg() {
        Modules.Opts o = opts();
        return o != null && !o.bg;
    }

    /** Panel background (bottom colour), follows the opacity setting (the element's own, else the global one). */
    public static int bg() {
        if (noBg()) return 0;
        float a = alpha();
        return switch (look()) {
            case LOOK_FROSTED -> Gfx.argb(Math.round(255f * a), 30, 38, 54);
            case LOOK_MONO -> Gfx.argb(Math.round(255f * a), 0, 0, 0);
            default -> Gfx.argb(Math.round(255f * a), 11, 11, 13);
        };
    }

    /** Top colour of a panel: lighter than the bottom for frosted glass, the same otherwise. */
    public static int bgTop() {
        if (noBg()) return 0;
        if (look() != LOOK_FROSTED) return bg();
        return Gfx.argb(Math.round(255f * alpha() * 0.7f), 84, 100, 128); // lighter and more see-through at the top
    }

    /** Panel outline; hidden together with the background. */
    public static int edge() {
        if (noBg()) return 0;
        return switch (look()) {
            case LOOK_FROSTED -> 0x5CFFFFFF;
            case LOOK_MONO -> 0xFF4A4A4F;
            default -> EDGE;
        };
    }

    /** Colour of the big menu/editor panels. */
    public static int panelTop() {
        return switch (look()) {
            case LOOK_FROSTED -> 0xB84C5C78;
            case LOOK_MONO -> 0xF2000000;
            default -> 0xF20B0B0D;
        };
    }

    public static int panelBottom() {
        return switch (look()) {
            case LOOK_FROSTED -> 0xCC1C2332;
            case LOOK_MONO -> 0xF2000000;
            default -> 0xF20B0B0D;
        };
    }

    public static int panelEdge() {
        return switch (look()) {
            case LOOK_FROSTED -> 0x66FFFFFF;
            case LOOK_MONO -> 0xFF4A4A4F;
            default -> 0xFF26262C;
        };
    }

    public static int accent() {
        if (look() == LOOK_MONO) return MONO_WHITE;
        Modules.Opts o = opts();
        return o != null && o.accent != 0 ? o.accent : Modules.accent();
    }

    /** Accent along the gradient (0..1); an element with its own colour is not graded. Monochrome grades white to grey. */
    public static int accentAt(float f) {
        if (look() == LOOK_MONO) return Gfx.lerpColor(MONO_WHITE, MONO_GREY, f * 0.8f);
        Modules.Opts o = opts();
        boolean grad = o != null && o.grad != 0 ? o.grad == 1 : Modules.gradient();
        if (!grad) return accent();
        int second = o != null && o.accent2 != 0 ? o.accent2 : Modules.accent2();
        return Gfx.lerpColor(accent(), second, Math.max(0f, Math.min(1f, f)));
    }
}
