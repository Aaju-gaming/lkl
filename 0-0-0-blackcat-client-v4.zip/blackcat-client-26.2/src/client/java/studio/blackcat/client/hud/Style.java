package studio.blackcat.client.hud;

import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.util.Gfx;

/**
 * The matte black look: one palette shared by the HUD, the menu and the editor.
 * While an element is being drawn (begin/end) its own settings (opacity, background, accent) apply.
 */
public final class Style {
    private Style() {}

    public static final int EDGE = 0xFF25252B;
    public static final int TEXT = 0xFFEDEDED;
    public static final int DIM = 0xFF8C8C95;
    public static final int FAINT = 0xFF3A3A42;
    public static final int WHITE = 0xFFFFFFFF;
    public static final int AMBER = 0xFFE0B04A;
    public static final int RED = 0xFFD9534F;
    public static final int TRACK = 0xFF17171B;

    private static Module current;

    /** Everything drawn until end() uses this element's own settings. */
    public static void begin(Module m) {
        current = m;
    }

    public static void end() {
        current = null;
    }

    private static Modules.Opts opts() {
        return current == null ? null : Modules.opts(current);
    }

    /** Panel background, follows the opacity setting (the element's own, else the global one). */
    public static int bg() {
        Modules.Opts o = opts();
        if (o != null && !o.bg) return 0;
        float a = o != null && o.opacity >= 0f ? o.opacity : Modules.opacity();
        return Gfx.argb(Math.round(255f * a), 11, 11, 13);
    }

    /** Panel outline; hidden together with the background. */
    public static int edge() {
        Modules.Opts o = opts();
        return o != null && !o.bg ? 0 : EDGE;
    }

    public static int accent() {
        Modules.Opts o = opts();
        return o != null && o.accent != 0 ? o.accent : Modules.accent();
    }

    /** Accent along the gradient (0..1); an element with its own colour is not graded. */
    public static int accentAt(float f) {
        Modules.Opts o = opts();
        return o != null && o.accent != 0 ? o.accent : Modules.accentAt(f);
    }
}
