package studio.blackcat.client.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.hud.HudCtx;
import studio.blackcat.client.hud.HudRenderer;
import studio.blackcat.client.hud.HudRenderer.Placed;
import studio.blackcat.client.hud.Style;
import studio.blackcat.client.util.Gfx;
import studio.blackcat.client.util.Smooth;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.input.KeyEvent;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * The HUD editor. Every switched-on element is shown where it sits; press and drag to move it, or select one
 * to change its size, background, opacity and colour, and to nudge it pixel by pixel (also with the arrow keys).
 * Elements snap to the screen edges, the centre lines and each other (a thin guide line shows what
 * they snapped to). Positions are saved as soon as you let go. Works with a mouse and with touch.
 */
public class HudEditorScreen extends Screen {
    private static final float SNAP = 4f;

    private static final int BTN_H = 16;
    private static final int BTN_GAP = 4;
    private static final int PROPS_H = 54;

    private final Smooth open = new Smooth(0f);
    private final Smooth[] glow = new Smooth[Module.values().length];

    private List<Placed> placed = new ArrayList<>();
    private Module selected;
    private Module dragging;
    private float dragX;
    private float dragY;
    private boolean moved;
    private float guideX = -1f;
    private float guideY = -1f;

    private int lastMouseX = -1;
    private int lastMouseY = -1;
    private long lastNanos = System.nanoTime();

    /** A clickable button, rebuilt every frame (immediate mode). */
    private record Btn(int x, int y, int w, int h, Runnable action) {
        boolean hit(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    private final List<Btn> buttons = new ArrayList<>();
    private Btn pressedBtn;

    public HudEditorScreen() {
        super(Component.literal("Edit HUD"));
        for (int i = 0; i < glow.length; i++) glow[i] = new Smooth(0f);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** No blur here: you need to see the game to place things relative to it. */
    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float a) {
    }

    // ---------- small UI helpers ----------

    private void button(GuiGraphicsExtractor g, int x, int y, int w, int h, String label, boolean primary,
                        boolean enabled, boolean active, float t, Runnable action) {
        boolean hov = enabled && lastMouseX >= x && lastMouseX < x + w && lastMouseY >= y && lastMouseY < y + h;
        int accent = Style.accent();
        int bg = primary ? Gfx.lerpColor(accent, 0xFFFFFFFF, hov ? 0.35f : 0f)
                : active ? 0xFF2A2A31 : (hov ? 0xFF212127 : 0xFF141418);
        int edge = primary ? bg : (active ? accent : (hov ? 0xFF8C8C95 : Style.EDGE));
        int fg = primary ? 0xFF0B0B0D : (enabled ? Style.WHITE : Style.FAINT);
        Gfx.roundRect(g, x, y, w, h, 4, Gfx.mulAlpha(bg, t));
        Gfx.roundOutline(g, x, y, w, h, 4, Gfx.mulAlpha(edge, t));
        Gfx.text(g, this.font, label, x + (w - Gfx.width(this.font, label)) / 2, y + (h - 8) / 2 + 1, Gfx.mulAlpha(fg, t));
        if (enabled && action != null) buttons.add(new Btn(x, y, w, h, action));
    }

    private int bw(String label) {
        return Gfx.width(this.font, label) + 12;
    }

    private Placed placedOf(Module m) {
        for (Placed p : placed) if (p.widget.module == m) return p;
        return null;
    }

    private void nudge(int dx, int dy) {
        Placed p = selected == null ? null : placedOf(selected);
        if (p == null) return;
        int nx = Math.max(0, Math.min(Math.max(0, width - p.ew()), p.x + dx));
        int ny = Math.max(0, Math.min(Math.max(0, height - p.eh()), p.y + dy));
        Modules.setPos(selected, nx / (float) width, ny / (float) height);
        Modules.save();
    }

    private void cycleLayout() {
        java.util.List<String> names = Modules.profileNames();
        if (names.isEmpty()) return;
        int i = names.indexOf(Modules.profileName());
        Modules.loadProfile(names.get((i + 1) % names.size()));
    }

    // ---------- drawing ----------

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        lastMouseX = mouseX;
        lastMouseY = mouseY;
        buttons.clear();

        long now = System.nanoTime();
        float dt = Math.min((now - lastNanos) / 1_000_000_000f, 0.1f);
        lastNanos = now;
        open.update(1f, dt, 10f);
        float t = Gfx.easeOutCubic(open.value);
        Font font = this.font;
        int accent = Modules.accent();

        // soft dim so the outlines read well
        g.fill(0, 0, width, height, Gfx.argb(Math.round(60 * t), 0, 0, 0));

        // faint centre lines while dragging
        if (dragging != null) {
            g.fill(width / 2, 0, width / 2 + 1, height, Gfx.argb(24, 255, 255, 255));
            g.fill(0, height / 2, width, height / 2 + 1, Gfx.argb(24, 255, 255, 255));
        }

        HudCtx ctx = new HudCtx(this.minecraft, dt, true);
        placed = HudRenderer.place(ctx, width, height);
        if (selected != null && placedOf(selected) == null) selected = null;

        for (Placed p : placed) HudRenderer.drawPlaced(g, ctx, p);

        // outlines + names
        Placed top = null;
        for (int i = placed.size() - 1; i >= 0 && dragging == null; i--) {
            if (placed.get(i).contains(mouseX, mouseY)) {
                top = placed.get(i);
                break;
            }
        }
        for (Placed p : placed) {
            Module m = p.widget.module;
            boolean hot = m == dragging || m == selected || p == top;
            float k = glow[m.ordinal()].update(hot ? 1f : 0f, dt, 16f);
            int edge = Gfx.lerpColor(Gfx.argb(70, 255, 255, 255), accent, m == dragging ? 1f : k * 0.9f);
            Gfx.roundOutline(g, p.x - 2, p.y - 2, p.ew() + 4, p.eh() + 4, 5, Gfx.mulAlpha(edge, t));
            if (k > 0.05f) {
                String name = p.widget.title();
                int ly = p.y - 13 >= 1 ? p.y - 13 : p.y + p.eh() + 5;
                Gfx.text(g, font, name, p.x, ly, Gfx.mulAlpha(Style.WHITE, k));
            }
        }

        // snap guides
        if (dragging != null) {
            int ga = Gfx.mulAlpha(accent, 0.8f);
            if (guideX >= 0f) g.fill(Math.round(guideX), 0, Math.round(guideX) + 1, height, ga);
            if (guideY >= 0f) g.fill(0, Math.round(guideY), width, Math.round(guideY) + 1, ga);
        }

        drawToolbar(g, font, t);
        if (selected != null) drawProps(g, font, t);

        if (placed.isEmpty()) {
            String msg = "No HUD modules are switched on. Turn some on in the menu first.";
            Gfx.text(g, font, msg, (width - Gfx.width(font, msg)) / 2, height / 2, Style.DIM);
        }
    }

    private void drawToolbar(GuiGraphicsExtractor g, Font font, float t) {
        String layout = "Layout: " + Gfx.fit(font, Modules.profileName(), 70);
        String[] labels = {layout, "Save", "Reset all", "Done"};
        int total = 0;
        for (String l : labels) total += bw(l);
        total += BTN_GAP * (labels.length - 1);
        int barW = total + 24;
        int barH = 46;
        int barX = (width - barW) / 2;
        int barY = 30;

        Gfx.roundRect(g, barX, barY, barW, barH, 6, Gfx.mulAlpha(0xF20B0B0D, t));
        Gfx.roundOutline(g, barX, barY, barW, barH, 6, Gfx.mulAlpha(Style.EDGE, t));
        String title = "EDIT HUD";
        Gfx.text(g, font, title, barX + 12, barY + 7, Gfx.mulAlpha(Style.WHITE, t));
        String hint = "drag to move, tap to select";
        Gfx.text(g, font, hint, barX + 12 + Gfx.width(font, title) + 8, barY + 7, Gfx.mulAlpha(Style.DIM, t));

        int x = barX + 12;
        int y = barY + 24;
        for (int i = 0; i < labels.length; i++) {
            int w = bw(labels[i]);
            final int idx = i;
            button(g, x, y, w, BTN_H, labels[i], i == labels.length - 1, true, false, t, () -> {
                switch (idx) {
                    case 0 -> cycleLayout();
                    case 1 -> Modules.saveProfile(Modules.profileName());
                    case 2 -> {
                        Modules.resetAllPos();
                        Modules.save();
                    }
                    default -> this.minecraft.gui.setScreen(new GlassMenuScreen());
                }
            });
            x += w + BTN_GAP;
        }
    }

    /** Settings of the selected element: size, background, opacity, colour, fine movement, reset. */
    private void drawProps(GuiGraphicsExtractor g, Font font, float t) {
        Module m = selected;
        Modules.Opts o = Modules.opts(m);
        int pw = Math.min(width - 8, 312);
        int px = (width - pw) / 2;
        int py = height - PROPS_H - 8;

        Gfx.roundRect(g, px, py, pw, PROPS_H, 6, Gfx.mulAlpha(0xF20B0B0D, t));
        Gfx.roundOutline(g, px, py, pw, PROPS_H, 6, Gfx.mulAlpha(Style.EDGE, t));

        // row 1
        int y1 = py + 6;
        int x = px + 8;
        Gfx.text(g, font, m.title, x, y1 + 4, Gfx.mulAlpha(Style.WHITE, t));
        x += Gfx.width(font, m.title) + 10;

        button(g, x, y1, 14, BTN_H, "-", false, true, false, t, () -> {
            o.scale = Math.max(0.5f, Math.round((o.scale - 0.1f) * 10f) / 10f);
            Modules.save();
        });
        String sc = String.format("%.1fx", o.scale);
        Gfx.text(g, font, sc, x + 14 + 4, y1 + 5, Gfx.mulAlpha(Style.TEXT, t));
        x += 14 + 4 + Gfx.width(font, "2.5x") + 4;
        button(g, x, y1, 14, BTN_H, "+", false, true, false, t, () -> {
            o.scale = Math.min(2.5f, Math.round((o.scale + 0.1f) * 10f) / 10f);
            Modules.save();
        });
        x += 14 + 8;

        button(g, x, y1, bw("BG ON"), BTN_H, o.bg ? "BG ON" : "BG OFF", false, true, o.bg, t, () -> {
            o.bg = !o.bg;
            Modules.save();
        });
        x += bw("BG OFF") + 6;

        final float cur = o.opacity >= 0f ? o.opacity : Modules.opacity();
        button(g, x, y1, 14, BTN_H, "-", false, true, false, t, () -> {
            o.opacity = Math.max(0.1f, Math.round((cur - 0.1f) * 10f) / 10f);
            Modules.save();
        });
        String op = o.opacity >= 0f ? Math.round(o.opacity * 100f) + "%" : "auto";
        int opW = Gfx.width(font, "100%") + 4;
        int opX = x + 14 + 2;
        Gfx.text(g, font, op, opX, y1 + 5, Gfx.mulAlpha(o.opacity >= 0f ? Style.TEXT : Style.DIM, t));
        buttons.add(new Btn(opX, y1, opW, BTN_H, () -> {
            o.opacity = -1f; // back to the global opacity
            Modules.save();
        }));
        x += 14 + 2 + opW + 2;
        button(g, x, y1, 14, BTN_H, "+", false, true, false, t, () -> {
            o.opacity = Math.min(1f, Math.round((cur + 0.1f) * 10f) / 10f);
            Modules.save();
        });

        // row 2
        int y2 = py + 30;
        x = px + 8;
        Gfx.text(g, font, "Color", x, y2 + 5, Gfx.mulAlpha(Style.DIM, t));
        x += Gfx.width(font, "Color") + 6;
        // "theme" swatch (follow the global accent) + the presets
        for (int i = -1; i < Modules.ACCENT_COLORS.length; i++) {
            final int idx = i;
            int col = i < 0 ? Modules.accent() : Modules.ACCENT_COLORS[i];
            boolean on = i < 0 ? o.accent == 0 : o.accent == Modules.ACCENT_COLORS[i];
            Gfx.roundRect(g, x, y2 + 1, 12, 12, 3, Gfx.mulAlpha(col, t));
            if (i < 0) Gfx.text(g, font, "T", x + 3, y2 + 3, Gfx.mulAlpha(0xFF0B0B0D, t));
            if (on) Gfx.roundOutline(g, x - 2, y2 - 1, 16, 16, 4, Gfx.mulAlpha(Style.WHITE, t));
            buttons.add(new Btn(x - 1, y2, 14, 14, () -> {
                o.accent = idx < 0 ? 0 : Modules.ACCENT_COLORS[idx];
                Modules.save();
            }));
            x += 16;
        }
        x += 6;
        Gfx.text(g, font, "Move", x, y2 + 5, Gfx.mulAlpha(Style.DIM, t));
        x += Gfx.width(font, "Move") + 6;
        String[] arrows = {"<", ">", "^", "v"};
        int[][] d = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        for (int i = 0; i < 4; i++) {
            final int[] dd = d[i];
            button(g, x, y2, 14, BTN_H, arrows[i], false, true, false, t, () -> nudge(dd[0], dd[1]));
            x += 16;
        }
        x += 6;
        button(g, x, y2, bw("Reset"), BTN_H, "Reset", false, true, false, t, () -> Modules.resetModule(m));
    }

    // ---------- snapping ----------

    /** Finds the nearest snap target for one axis (top-left coordinate v of something `size` long). */
    private static final class Snap {
        final float v;
        float best = SNAP + 0.001f;
        float out;
        float line = -1f;

        Snap(float v) {
            this.v = v;
            this.out = v;
        }

        void target(float target, float lineAt) {
            float d = Math.abs(v - target);
            if (d < best) {
                best = d;
                out = target;
                line = lineAt;
            }
        }
    }

    // ---------- input ----------

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        moved = false;
        pressedBtn = null;
        for (int i = buttons.size() - 1; i >= 0; i--) {
            Btn b = buttons.get(i);
            if (b.hit(lastMouseX, lastMouseY)) {
                pressedBtn = b;
                return true;
            }
        }
        for (int i = placed.size() - 1; i >= 0; i--) {
            Placed p = placed.get(i);
            if (p.contains(lastMouseX, lastMouseY)) {
                dragging = p.widget.module;
                selected = dragging;
                dragX = p.x;
                dragY = p.y;
                return true;
            }
        }
        selected = null;
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = InputConstants.getKey(event).getValue();
        if (selected != null) {
            if (key == GLFW.GLFW_KEY_LEFT) { nudge(-1, 0); return true; }
            if (key == GLFW.GLFW_KEY_RIGHT) { nudge(1, 0); return true; }
            if (key == GLFW.GLFW_KEY_UP) { nudge(0, -1); return true; }
            if (key == GLFW.GLFW_KEY_DOWN) { nudge(0, 1); return true; }
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double deltaX, double deltaY) {
        if (dragging == null) return true;
        Placed me = placedOf(dragging);
        if (me == null) return true;

        dragX += (float) deltaX;
        dragY += (float) deltaY;
        moved = true;

        int w = me.ew();
        int h = me.eh();
        float nx = Math.max(0f, Math.min(Math.max(0, width - w), dragX));
        float ny = Math.max(0f, Math.min(Math.max(0, height - h), dragY));

        Snap sx = new Snap(nx);
        sx.target(HudRenderer.MARGIN, -1f);
        sx.target((width - w) / 2f, width / 2f);
        sx.target(width - w - HudRenderer.MARGIN, -1f);

        Snap sy = new Snap(ny);
        sy.target(HudRenderer.MARGIN, -1f);
        sy.target((height - h) / 2f, height / 2f);
        sy.target(height - h - HudRenderer.MARGIN, -1f);

        for (Placed o : placed) {
            if (o.widget.module == dragging) continue;
            int ow = o.ew();
            int oh = o.eh();
            sx.target(o.x, o.x);
            sx.target(o.x + ow - w, o.x + ow);
            sx.target(o.x + (ow - w) / 2f, o.x + ow / 2f);
            sx.target(o.x + ow + HudRenderer.GAP, -1f);
            sx.target(o.x - w - HudRenderer.GAP, -1f);

            sy.target(o.y, o.y);
            sy.target(o.y + oh - h, o.y + oh);
            sy.target(o.y + (oh - h) / 2f, o.y + oh / 2f);
            sy.target(o.y + oh + HudRenderer.GAP, -1f);
            sy.target(o.y - h - HudRenderer.GAP, -1f);
        }
        guideX = sx.line;
        guideY = sy.line;

        float fx = Math.max(0f, Math.min(Math.max(0, width - w), sx.out));
        float fy = Math.max(0f, Math.min(Math.max(0, height - h), sy.out));
        Modules.setPos(dragging, fx / width, fy / height);
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (pressedBtn != null) {
            Btn b = pressedBtn;
            pressedBtn = null;
            if (b.hit(lastMouseX, lastMouseY)) b.action().run();
            return true;
        }
        if (dragging != null) {
            dragging = null;
            guideX = -1f;
            guideY = -1f;
            if (moved) Modules.save();
        }
        return true;
    }
}
