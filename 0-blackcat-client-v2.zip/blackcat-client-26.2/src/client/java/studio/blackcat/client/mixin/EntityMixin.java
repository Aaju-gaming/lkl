package studio.blackcat.client.mixin;

import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import studio.blackcat.client.hud.Freelook;

/**
 * Freelook: while active, mouse movement turns the camera, not the player.
 * Non-fatal (require = 0): if Mojang renames Entity.turn, only freelook stops working.
 */
@Mixin(targets = "net.minecraft.world.entity.Entity")
public abstract class EntityMixin {
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true, require = 0)
    private void blackcat$freelookTurn(double yRot, double xRot, CallbackInfo ci) {
        if (Freelook.active() && (Object) this == Minecraft.getInstance().player) {
            Freelook.turn(yRot, xRot);
            ci.cancel();
        }
    }
}
