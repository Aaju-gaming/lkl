package studio.blackcat.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import studio.blackcat.client.hud.Freelook;

/**
 * Freelook: while active, the camera uses the freelook angles instead of the player's.
 * Non-fatal (require = 0): if Mojang renames Camera.setRotation, only freelook stops working.
 */
@Mixin(targets = "net.minecraft.client.Camera")
public abstract class CameraMixin {
    @ModifyVariable(method = "setRotation", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private float blackcat$yaw(float yRot) {
        return Freelook.active() ? Freelook.yaw() : yRot;
    }

    @ModifyVariable(method = "setRotation", at = @At("HEAD"), argsOnly = true, ordinal = 1, require = 0)
    private float blackcat$pitch(float xRot) {
        return Freelook.active() ? Freelook.pitch() : xRot;
    }
}
