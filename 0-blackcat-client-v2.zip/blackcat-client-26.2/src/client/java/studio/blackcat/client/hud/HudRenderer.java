package studio.blackcat.client.hud;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.util.Gfx;
import studio.blackcat.client.util.Smooth;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** In-game overlay. Flat matte black panels, thin edges, white text. */
public final class HudRenderer {
    private HudRenderer() {}

    // ---- matte black palette ----
    private static final int BG = 0xD90B0B0D;
    private static final int EDGE = 0xFF25252B;
    private static final int TEXT = 0xFFEDEDED;
    private static final int DIM = 0xFF8C8C95;
    private static final int FAINT = 0xFF3A3A42;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int AMBER = 0xFFE0B04A;
    private static final int RED = 0xFFD9534F;

    private static final int GAP = 4;
    private static final int MARGIN = 6;
    private static final int GRAPH_SAMPLES = 46;

    // ---- timing / history ----
    private static long lastNanos = System.nanoTime();
    private static int frames;
    private static long fpsWindowStart = System.nanoTime();
    private static int fps;
    private static final ArrayDeque<Integer> FPS_HIST = new ArrayDeque<>();

    private static final ArrayDeque<Float> CPS_L = new ArrayDeque<>();
    private static final ArrayDeque<Float> CPS_R = new ArrayDeque<>();
    private static long nextCpsSample;
    private static final ArrayDeque<Float> PING_HIST = new ArrayDeque<>();
    private static long nextPingSample;

    private static final Smooth[] KEY_ANIM = new Smooth[7];
    static {
        for (int i = 0; i < KEY_ANIM.length; i++) KEY_ANIM[i] = new Smooth(0f);
    }

    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("h:mm a");
    private static final String[] ROMAN = {"", "", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final String[] ARMOR_LETTER = {"H", "C", "L", "B"};

    public static void render(GuiGraphicsExtractor g, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        long now = System.nanoTime();
        float dt = Math.min((now - lastNanos) / 1_000_000_000f, 0.1f);
        lastNanos = now;

        frames++;
        if (now - fpsWindowStart >= 1_000_000_000L) {
            fps = frames;
            frames = 0;
            fpsWindowStart = now;
            FPS_HIST.addLast(fps);
            while (FPS_HIST.size() > 30) FPS_HIST.removeFirst();
        }

        if (mc.player == null) return;
        Cps.poll(mc.options.keyAttack.isDown(), mc.options.keyUse.isDown());
        sample(mc, now);
        if (mc.gui.hud.isHidden()) return;

        Font font = mc.font;
        int sw = g.guiWidth();
        int sh = g.guiHeight();

        // ===== left column =====
        int y = MARGIN;
        if (on(Module.FPS)) {
            int avg = FPS_HIST.isEmpty() ? fps : Math.round((float) FPS_HIST.stream().mapToInt(Integer::intValue).sum() / FPS_HIST.size());
            y = pill(g, font, MARGIN, y, "FPS", fps + "  avg " + avg);
        }
        if (on(Module.CPS)) {
            y = pill(g, font, MARGIN, y, "CPS", Cps.left() + " | " + Cps.right());
        }
        if (on(Module.PING)) {
            y = pill(g, font, MARGIN, y, "PING", ping(mc) < 0 ? "--" : ping(mc) + " ms");
        }
        if (on(Module.COORDS)) {
            y = pill(g, font, MARGIN, y, "XYZ", Mth.floor(mc.player.getX()) + "  "
                    + Mth.floor(mc.player.getY()) + "  " + Mth.floor(mc.player.getZ()));
        }
        if (on(Module.CLOCK)) {
            y = pill(g, font, MARGIN, y, "TIME", LocalTime.now().format(CLOCK).toUpperCase());
        }
        if (on(Module.BIOME)) {
            y = pill(g, font, MARGIN, y, "BIOME", biome(mc));
        }
        if (on(Module.DIRECTION)) {
            y = compass(g, font, mc, MARGIN, y);
        }
        if (on(Module.CPS_GRAPH)) {
            y = graph(g, font, MARGIN, y, "CPS", Cps.left() + " | " + Cps.right(), CPS_L, CPS_R, 12f, false);
        }
        if (on(Module.PING_GRAPH)) {
            int p = ping(mc);
            y = graph(g, font, MARGIN, y, "PING", p < 0 ? "--" : p + " ms", PING_HIST, null, 100f, true);
        }

        // ===== keystrokes: bottom-left =====
        if (on(Module.KEYSTROKES)) {
            keystrokes(g, font, mc, MARGIN, sh - MARGIN - 85, dt);
        }

        // ===== right column =====
        int ry = MARGIN;
        if (on(Module.POTIONS)) {
            ry = potions(g, font, mc, sw, ry);
        }
        int armorH = 4 * 20 + 6;
        int rightY = Math.max(ry, (sh - armorH) / 2);
        if (on(Module.ARMOR)) {
            rightY = armor(g, font, mc, sw, rightY);
        }
        if (on(Module.ITEM)) {
            item(g, font, mc, sw, rightY);
        }
    }

    // ================= sampling =================

    private static void sample(Minecraft mc, long nowNanos) {
        long ms = nowNanos / 1_000_000L;
        if (ms >= nextCpsSample) {
            nextCpsSample = ms + 200;
            push(CPS_L, Cps.left());
            push(CPS_R, Cps.right());
        }
        if (ms >= nextPingSample) {
            nextPingSample = ms + 500;
            int p = ping(mc);
            if (p >= 0) push(PING_HIST, p);
        }
    }

    private static void push(ArrayDeque<Float> q, float v) {
        q.addLast(v);
        while (q.size() > GRAPH_SAMPLES) q.removeFirst();
    }

    private static int ping(Minecraft mc) {
        if (mc.getConnection() == null || mc.player == null) return -1;
        PlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        return info == null ? -1 : info.getLatency();
    }

    private static boolean on(Module m) {
        return Modules.isEnabled(m);
    }

    // ================= building blocks =================

    private static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h) {
        Gfx.roundRect(g, x, y, w, h, 4, BG);
        Gfx.roundOutline(g, x, y, w, h, 4, EDGE);
    }

    /** Small "LABEL value" pill. Returns the y for the next element. */
    private static int pill(GuiGraphicsExtractor g, Font font, int x, int y, String label, String value) {
        int lw = Gfx.width(font, label);
        int w = lw + 6 + Gfx.width(font, value) + 14;
        panel(g, x, y, w, 16);
        Gfx.text(g, font, label, x + 7, y + 4, DIM);
        Gfx.text(g, font, value, x + 7 + lw + 6, y + 4, WHITE);
        return y + 16 + GAP;
    }

    // ================= direction compass =================

    private static int compass(GuiGraphicsExtractor g, Font font, Minecraft mc, int x, int y) {
        int w = 132;
        int h = 20;
        panel(g, x, y, w, h);

        float yaw = Freelook.active() ? Freelook.yaw() : mc.player.getYRot();
        float heading = Mth.wrapDegrees(yaw + 180f); // 0 = north, 90 = east
        float cx = x + w / 2f;
        float pxPerDeg = 1.15f;
        String[] names = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

        for (int deg = 0; deg < 360; deg += 15) {
            float diff = Mth.wrapDegrees(deg - heading);
            float px = cx + diff * pxPerDeg;
            if (px < x + 6 || px > x + w - 6) continue;
            boolean label = deg % 45 == 0;
            if (!label) {
                g.fill(Math.round(px), y + h - 6, Math.round(px) + 1, y + h - 3, FAINT);
                continue;
            }
            String s = names[deg / 45];
            boolean cardinal = deg % 90 == 0;
            int tw = Gfx.width(font, s);
            int tx = Math.round(px - tw / 2f);
            if (tx < x + 4 || tx + tw > x + w - 4) continue;
            Gfx.text(g, font, s, tx, y + 4, cardinal ? WHITE : DIM);
        }
        // centre marker
        g.fill(Math.round(cx), y + h - 4, Math.round(cx) + 1, y + h - 1, WHITE);
        return y + h + GAP;
    }

    // ================= graphs =================

    private static int graph(GuiGraphicsExtractor g, Font font, int x, int y, String title, String value,
                             ArrayDeque<Float> a, ArrayDeque<Float> b, float minScale, boolean latency) {
        int w = 108;
        int h = 42;
        panel(g, x, y, w, h);
        Gfx.text(g, font, title, x + 7, y + 4, DIM);
        Gfx.text(g, font, value, x + w - 7 - Gfx.width(font, value), y + 4, WHITE);

        int baseY = y + h - 5;
        int areaH = 20;
        int left = x + 7;

        float max = minScale;
        for (float v : a) max = Math.max(max, v);
        if (b != null) for (float v : b) max = Math.max(max, v);

        // faint guide line
        g.fill(left, baseY - areaH / 2, left + GRAPH_SAMPLES * 2, baseY - areaH / 2 + 1, 0xFF17171B);

        if (b != null) {
            int i = 0;
            for (float v : b) {
                bar(g, left + i * 2, baseY, areaH, v / max, 0xFF55555D);
                i++;
            }
        }
        int i = 0;
        for (float v : a) {
            int col = WHITE;
            if (latency) col = v > 150 ? RED : (v > 80 ? AMBER : 0xFFE8E8EC);
            bar(g, left + i * 2, baseY, areaH, v / max, col);
            i++;
        }
        return y + h + GAP;
    }

    private static void bar(GuiGraphicsExtractor g, int x, int baseY, int areaH, float frac, int color) {
        if (frac <= 0f) return;
        int bh = Math.max(1, Math.round(Mth.clamp(frac, 0f, 1f) * areaH));
        g.fill(x, baseY - bh, x + 2, baseY, color);
    }

    // ================= keystrokes 2.0 =================

    private static void keystrokes(GuiGraphicsExtractor g, Font font, Minecraft mc, int x, int y, float dt) {
        var o = mc.options;
        key(g, font, 0, o.keyUp, "W", x + 23, y, 20, 20, null, dt);
        key(g, font, 1, o.keyLeft, "A", x, y + 23, 20, 20, null, dt);
        key(g, font, 2, o.keyDown, "S", x + 23, y + 23, 20, 20, null, dt);
        key(g, font, 3, o.keyRight, "D", x + 46, y + 23, 20, 20, null, dt);
        key(g, font, 4, o.keyAttack, "LMB", x, y + 46, 31, 24, String.valueOf(Cps.left()), dt);
        key(g, font, 5, o.keyUse, "RMB", x + 35, y + 46, 31, 24, String.valueOf(Cps.right()), dt);
        key(g, font, 6, o.keyJump, null, x, y + 73, 66, 12, null, dt);
    }

    private static void key(GuiGraphicsExtractor g, Font font, int i, KeyMapping binding, String label,
                            int x, int y, int w, int h, String sub, float dt) {
        float s = KEY_ANIM[i].update(binding.isDown() ? 1f : 0f, dt, 24f);
        int bg = Gfx.lerpColor(BG, 0xFFF2F2F5, s);
        int edge = Gfx.lerpColor(EDGE, 0xFFFFFFFF, s);
        int fg = Gfx.lerpColor(WHITE, 0xFF0B0B0D, s);
        int sub1 = Gfx.lerpColor(DIM, 0xFF55555D, s);

        float scale = 1f - 0.07f * s; // a tiny press-in
        float cx = x + w / 2f;
        float cy = y + h / 2f;
        g.pose().pushMatrix();
        g.pose().translate(cx, cy);
        g.pose().scale(scale, scale);
        g.pose().translate(-cx, -cy);

        Gfx.roundRect(g, x, y, w, h, 4, bg);
        Gfx.roundOutline(g, x, y, w, h, 4, edge);
        if (label != null) {
            int ty = sub != null ? y + 4 : y + (h - 8) / 2;
            Gfx.text(g, font, label, x + (w - Gfx.width(font, label)) / 2, ty, fg);
        } else {
            // space bar: a small line
            int lw = 20;
            g.fill(x + (w - lw) / 2, y + h / 2, x + (w + lw) / 2, y + h / 2 + 1, fg);
        }
        if (sub != null) {
            Gfx.text(g, font, sub, x + (w - Gfx.width(font, sub)) / 2, y + 14, sub1);
        }
        g.pose().popMatrix();
    }

    // ================= armor / item =================

    private static int armor(GuiGraphicsExtractor g, Font font, Minecraft mc, int sw, int y) {
        int w = 74;
        int h = 4 * 20 + 6;
        int x = sw - MARGIN - w;
        panel(g, x, y, w, h);
        for (int i = 0; i < 4; i++) {
            int ry = y + 3 + i * 20;
            ItemStack st = mc.player.getItemBySlot(ARMOR_SLOTS[i]);
            if (st.isEmpty()) {
                Gfx.text(g, font, ARMOR_LETTER[i], x + 9, ry + 6, FAINT);
                g.fill(x + 24, ry + 9, x + w - 8, ry + 10, 0xFF17171B);
                continue;
            }
            if (!Gfx.item(g, st, x + 4, ry + 1)) {
                Gfx.text(g, font, ARMOR_LETTER[i], x + 9, ry + 6, WHITE);
            }
            durability(g, font, st, x + 24, ry, w - 24 - 7);
        }
        return y + h + GAP;
    }

    private static void item(GuiGraphicsExtractor g, Font font, Minecraft mc, int sw, int y) {
        ItemStack st = mc.player.getMainHandItem();
        if (st.isEmpty()) return;
        String name = st.getHoverName().getString();
        if (st.getCount() > 1) name += "  x" + st.getCount();
        int w = 118;
        int h = 26;
        int x = sw - MARGIN - w;
        panel(g, x, y, w, h);
        if (!Gfx.item(g, st, x + 5, y + 5)) {
            Gfx.text(g, font, "I", x + 10, y + 9, WHITE);
        }
        Gfx.text(g, font, Gfx.fit(font, name, w - 32), x + 26, y + 4, WHITE);
        if (st.isDamageableItem()) {
            int left = st.getMaxDamage() - st.getDamageValue();
            Gfx.text(g, font, left + " / " + st.getMaxDamage(), x + 26, y + 14, DIM);
        } else {
            Gfx.text(g, font, "no durability", x + 26, y + 14, FAINT);
        }
    }

    /** Durability number + thin bar. */
    private static void durability(GuiGraphicsExtractor g, Font font, ItemStack st, int x, int y, int w) {
        if (!st.isDamageableItem()) {
            Gfx.text(g, font, "-", x, y + 3, DIM);
            g.fill(x, y + 13, x + w, y + 14, FAINT);
            return;
        }
        int max = st.getMaxDamage();
        int left = max - st.getDamageValue();
        float frac = Mth.clamp(left / (float) max, 0f, 1f);
        int col = frac > 0.5f ? 0xFFE8E8EC : (frac > 0.2f ? AMBER : RED);
        Gfx.text(g, font, String.valueOf(left), x, y + 2, col);
        g.fill(x, y + 13, x + w, y + 14, 0xFF17171B);
        g.fill(x, y + 13, x + Math.max(1, Math.round(w * frac)), y + 14, col);
    }

    // ================= potions =================

    private static int potions(GuiGraphicsExtractor g, Font font, Minecraft mc, int sw, int y) {
        List<MobEffectInstance> list = new ArrayList<>(mc.player.getActiveEffects());
        if (list.isEmpty()) return y;
        list.sort(Comparator.comparingInt(MobEffectInstance::getDuration).reversed());

        List<String> names = new ArrayList<>();
        List<String> times = new ArrayList<>();
        int w = 80;
        for (MobEffectInstance e : list) {
            String n = e.getEffect().value().getDisplayName().getString();
            int amp = e.getAmplifier() + 1;
            if (amp > 1) n += " " + (amp < ROMAN.length ? ROMAN[amp] : String.valueOf(amp));
            int d = e.getDuration();
            String t = d < 0 ? "inf" : (d / 20 / 60) + ":" + String.format("%02d", (d / 20) % 60);
            names.add(n);
            times.add(t);
            w = Math.max(w, Gfx.width(font, n) + Gfx.width(font, t) + 26);
        }
        int rowH = 15;
        int h = list.size() * rowH + 6;
        int x = sw - MARGIN - w;
        panel(g, x, y, w, h);
        for (int i = 0; i < list.size(); i++) {
            int ry = y + 3 + i * rowH;
            int d = list.get(i).getDuration();
            int col = (d >= 0 && d < 200) ? ((System.currentTimeMillis() / 300) % 2 == 0 ? RED : DIM) : WHITE;
            Gfx.text(g, font, names.get(i), x + 8, ry + 3, TEXT);
            Gfx.text(g, font, times.get(i), x + w - 8 - Gfx.width(font, times.get(i)), ry + 3, col);
        }
        return y + h + GAP;
    }

    // ================= biome =================

    private static String biome(Minecraft mc) {
        if (mc.level == null) return "--";
        try {
            String path = mc.level.getBiome(mc.player.blockPosition())
                    .unwrapKey().map(k -> k.identifier().getPath()).orElse("unknown");
            StringBuilder sb = new StringBuilder();
            for (String part : path.split("_")) {
                if (part.isEmpty()) continue;
                if (sb.length() > 0) sb.append(' ');
                sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
            }
            return sb.toString();
        } catch (Throwable t) {
            return "--";
        }
    }
}
