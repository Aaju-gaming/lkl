package studio.blackcat.client.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import studio.blackcat.client.BlackCatClient;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;
import studio.blackcat.client.util.Gfx;
import studio.blackcat.client.util.Smooth;

/**
 * The Black Cat menu: flat matte black, thin edges, smooth motion everywhere.
 * The panel eases in, cards stagger in and lift on hover, toggles slide, the list scrolls smoothly
 * (mouse wheel or drag), and the whole thing fades out on close. Vanilla's background blur sits behind it.
 */
public class GlassMenuScreen extends Screen {
    private static final int PANEL_W = 384;
    private static final int PANEL_H = 232;
    private static final int PAD = 14;
    private static final int GAP = 8;
    private static final int COLS = 3;
    private static final int CARD_H = 54;
    private static final int HEADER_H = 46;

    // matte palette
    private static final int PANEL_BG = 0xF20B0B0D;
    private static final int PANEL_EDGE = 0xFF26262C;
    private static final int DIVIDER = 0xFF1C1C21;
    private static final int CARD_BG = 0xFF121215;
    private static final int CARD_HOVER = 0xFF19191D;
    private static final int CARD_EDGE = 0xFF222228;
    private static final int TEXT = 0xFFEDEDED;
    private static final int DIM = 0xFF8C8C95;
    private static final int TRACK_OFF = 0xFF2A2A30;
    private static final int TRACK_ON = 0xFFF2F2F5;
    private static final int KNOB_OFF = 0xFF8C8C95;
    private static final int KNOB_ON = 0xFF0B0B0D;

    private final Smooth open = new Smooth(0f);
    private final Smooth scrollAnim = new Smooth(0f);
    private final Smooth[] hover = new Smooth[Module.values().length];
    private final Smooth[] on = new Smooth[Module.values().length];
    private boolean closing;
    private long lastNanos = System.nanoTime();
    private int lastMouseX = -1;
    private int lastMouseY = -1;
    private float scrollTarget;
    private float dragTotal;
    private boolean dragging;

    public GlassMenuScreen() {
        super(Component.literal("Black Cat"));
        for (int i = 0; i < hover.length; i++) {
            hover[i] = new Smooth(0f);
            on[i] = new Smooth(Modules.isEnabled(Module.values()[i]) ? 1f : 0f);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        closing = true; // fade out first, then really close
    }

    // ---------- layout ----------

    private int panelX() {
        return (width - PANEL_W) / 2;
    }

    private int panelY() {
        return (height - PANEL_H) / 2;
    }

    private int viewTop() {
        return panelY() + HEADER_H + 8;
    }

    private int viewBottom() {
        return panelY() + PANEL_H - PAD + 2;
    }

    private int cardW() {
        return (PANEL_W - PAD * 2 - GAP * (COLS - 1)) / COLS;
    }

    private int rows() {
        return (Module.values().length + COLS - 1) / COLS;
    }

    private float maxScroll() {
        float content = rows() * (CARD_H + GAP) - GAP;
        return Math.max(0f, content - (viewBottom() - viewTop()));
    }

    private int cardX(int i) {
        return panelX() + PAD + (i % COLS) * (cardW() + GAP);
    }

    private int cardY(int i) {
        return viewTop() + (i / COLS) * (CARD_H + GAP) - Math.round(scrollAnim.value);
    }

    private boolean over(int i, double mx, double my) {
        if (my < viewTop() || my > viewBottom()) return false;
        return mx >= cardX(i) && mx < cardX(i) + cardW() && my >= cardY(i) && my < cardY(i) + CARD_H;
    }

    // ---------- rendering ----------

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        lastMouseX = mouseX;
        lastMouseY = mouseY;

        long now = System.nanoTime();
        float dt = Math.min((now - lastNanos) / 1_000_000_000f, 0.1f);
        lastNanos = now;

        open.update(closing ? 0f : 1f, dt, closing ? 14f : 9f);
        if (closing && open.value <= 0.01f) {
            super.onClose(); // vanilla: leave the screen
            return;
        }
        float t = Gfx.easeOutCubic(open.value);
        Font font = this.font;

        scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget));
        scrollAnim.update(scrollTarget, dt, 16f);

        // soft dim on top of vanilla's blur
        g.fill(0, 0, width, height, Gfx.argb(Math.round(80 * t), 0, 0, 0));

        // panel rises and scales up slightly
        float scale = 0.95f + 0.05f * t;
        float rise = (1f - t) * 12f;
        g.pose().pushMatrix();
        g.pose().translate(width / 2f, height / 2f + rise);
        g.pose().scale(scale, scale);
        g.pose().translate(-width / 2f, -height / 2f);

        int px = panelX();
        int py = panelY();

        // matte body + hairline edge
        Gfx.roundRect(g, px, py, PANEL_W, PANEL_H, 8, Gfx.mulAlpha(PANEL_BG, t));
        Gfx.roundOutline(g, px, py, PANEL_W, PANEL_H, 8, Gfx.mulAlpha(PANEL_EDGE, t));

        // header
        if (open.value > 0.5f) {
            Gfx.textureFit(g, BlackCatClient.CAT_WHITE_96, px + PAD, py + 10, 26, 26, 96, 96);
        }
        Gfx.text(g, font, "BLACK CAT", px + PAD + 33, py + 12, Gfx.mulAlpha(TEXT, t));
        Gfx.text(g, font, "STUDIOS", px + PAD + 33, py + 24, Gfx.mulAlpha(DIM, t));

        int enabled = 0;
        for (Module m : Module.values()) if (Modules.isEnabled(m)) enabled++;
        String hint = enabled + " / " + Module.values().length + " on   -   scroll, Esc to close";
        Gfx.text(g, font, hint, px + PANEL_W - PAD - Gfx.width(font, hint), py + 19, Gfx.mulAlpha(DIM, t));

        g.fill(px + PAD, py + HEADER_H, px + PANEL_W - PAD, py + HEADER_H + 1, Gfx.mulAlpha(DIVIDER, t));

        // ----- scrolling card grid, clipped to the view -----
        g.enableScissor(px + 4, viewTop(), px + PANEL_W - 4, viewBottom());
        Module[] mods = Module.values();
        for (int i = 0; i < mods.length; i++) {
            float cardT = Gfx.easeOutCubic(Gfx.clamp01((open.value - i * 0.04f) / 0.7f));

            boolean hov = !closing && over(i, mouseX, mouseY);
            float h = hover[i].update(hov ? 1f : 0f, dt, 14f);
            float s = on[i].update(Modules.isEnabled(mods[i]) ? 1f : 0f, dt, 12f);

            int cw = cardW();
            int cx = cardX(i);
            int cy = cardY(i) - Math.round(h * 1.5f) + Math.round((1f - cardT) * 8f);
            if (cy > viewBottom() || cy + CARD_H < viewTop()) continue;

            int bg = Gfx.lerpColor(CARD_BG, CARD_HOVER, h);
            int edge = Gfx.lerpColor(CARD_EDGE, 0xFF8C8C95, Math.max(h * 0.5f, s * 0.7f));
            Gfx.roundRect(g, cx, cy, cw, CARD_H, 6, Gfx.mulAlpha(bg, cardT));
            Gfx.roundOutline(g, cx, cy, cw, CARD_H, 6, Gfx.mulAlpha(edge, cardT));

            Gfx.text(g, font, Gfx.fit(font, mods[i].title, cw - 18), cx + 9, cy + 8, Gfx.mulAlpha(TEXT, cardT));
            Gfx.text(g, font, Gfx.fit(font, mods[i].description, cw - 18), cx + 9, cy + 20, Gfx.mulAlpha(DIM, cardT));

            // sliding toggle
            int tw = 28;
            int th = 12;
            int tx = cx + 9;
            int ty = cy + CARD_H - th - 8;
            Gfx.roundRect(g, tx, ty, tw, th, 6, Gfx.mulAlpha(Gfx.lerpColor(TRACK_OFF, TRACK_ON, s), cardT));
            int knobX = tx + 2 + Math.round(s * (tw - th));
            Gfx.roundRect(g, knobX, ty + 2, th - 4, th - 4, 4,
                    Gfx.mulAlpha(Gfx.lerpColor(KNOB_OFF, KNOB_ON, s), cardT));
        }
        g.disableScissor();

        // thin scroll bar
        float max = maxScroll();
        if (max > 0f) {
            int trackTop = viewTop();
            int trackH = viewBottom() - viewTop();
            int thumbH = Math.max(18, Math.round(trackH * trackH / (trackH + max)));
            int thumbY = trackTop + Math.round((trackH - thumbH) * (scrollAnim.value / max));
            int bx = px + PANEL_W - 8;
            g.fill(bx, thumbY, bx + 2, thumbY + thumbH, Gfx.mulAlpha(0xFF3A3A42, t));
        }

        g.pose().popMatrix();
    }

    // ---------- input ----------

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scrollTarget -= (float) scrollY * 30f;
        scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget));
        return true;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        dragTotal = 0f;
        dragging = false;
        return !closing;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double deltaX, double deltaY) {
        dragTotal += (float) Math.abs(deltaY);
        if (dragTotal > 4f) dragging = true;
        if (dragging) {
            scrollTarget -= (float) deltaY;
            scrollTarget = Math.max(0f, Math.min(maxScroll(), scrollTarget));
        }
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        boolean wasDrag = dragging;
        dragging = false;
        if (closing || wasDrag) return true;
        // a clean tap/click: toggle the card under the last known pointer position
        // (works for mouse and for touch taps on Pojav)
        Module[] mods = Module.values();
        for (int i = 0; i < mods.length; i++) {
            if (over(i, lastMouseX, lastMouseY)) {
                Modules.toggle(mods[i]);
                return true;
            }
        }
        return super.mouseReleased(event);
    }
}
