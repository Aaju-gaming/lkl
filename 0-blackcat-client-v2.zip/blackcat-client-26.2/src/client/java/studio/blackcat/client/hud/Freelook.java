package studio.blackcat.client.hud;

import net.minecraft.client.Minecraft;
import studio.blackcat.client.Modules;
import studio.blackcat.client.Modules.Module;

/**
 * Freelook state. While the key is held, mouse movement turns the camera instead of the player
 * (see EntityMixin / CameraMixin). Releasing the key snaps the view back to where the player faces.
 */
public final class Freelook {
    private Freelook() {}

    private static boolean active;
    private static float yaw;
    private static float pitch;

    public static boolean active() {
        return active;
    }

    public static float yaw() {
        return yaw;
    }

    public static float pitch() {
        return pitch;
    }

    /** Called every client tick. */
    public static void update(Minecraft mc, boolean keyDown) {
        boolean want = keyDown
                && Modules.isEnabled(Module.FREELOOK)
                && mc.player != null
                && mc.gui.screen() == null;
        if (want && !active) {
            yaw = mc.player.getYRot();
            pitch = mc.player.getXRot();
        }
        active = want;
    }

    /** Applies a mouse delta (same units and 0.15 factor as vanilla's Entity.turn). */
    public static void turn(double yRot, double xRot) {
        yaw += (float) yRot * 0.15f;
        pitch = Math.max(-90f, Math.min(90f, pitch + (float) xRot * 0.15f));
    }
}
