package studio.blackcat.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.EnumSet;
import java.util.Set;

/** Which HUD modules are switched on. Saved to config/blackcat.json. */
public final class Modules {
    private Modules() {}

    public enum Module {
        FPS("FPS Counter", "Current + average"),
        CPS("CPS", "Clicks per second"),
        KEYSTROKES("Keystrokes", "WASD + mouse"),
        COORDS("Coordinates", "Your position"),
        PING("Ping", "Latency"),
        ARMOR("Armor HUD", "Durability"),
        POTIONS("Potion HUD", "Effects + timers"),
        DIRECTION("Direction HUD", "N / E / S / W compass"),
        CLOCK("Clock", "Real-world time"),
        ITEM("Item HUD", "Held item + durability"),
        BIOME("Biome HUD", "Current biome"),
        CPS_GRAPH("CPS Graph", "Live click history"),
        PING_GRAPH("Ping Graph", "Latency history"),
        FREELOOK("Freelook", "Hold key to look around");

        public final String title;
        public final String description;

        Module(String title, String description) {
            this.title = title;
            this.description = description;
        }
    }

    private static final Set<Module> ENABLED = EnumSet.of(Module.FPS, Module.CPS, Module.KEYSTROKES, Module.FREELOOK);

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("blackcat.json");
    }

    public static boolean isEnabled(Module m) {
        return ENABLED.contains(m);
    }

    public static void toggle(Module m) {
        if (!ENABLED.remove(m)) ENABLED.add(m);
        save();
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f)) {
            JsonObject obj = JsonParser.parseReader(r).getAsJsonObject();
            ENABLED.clear();
            for (var el : obj.getAsJsonArray("enabled")) {
                try {
                    ENABLED.add(Module.valueOf(el.getAsString()));
                } catch (IllegalArgumentException ignored) {
                    // module removed in a newer/older version
                }
            }
        } catch (Exception e) {
            System.err.println("[blackcat] could not read config, using defaults: " + e);
        }
    }

    public static void save() {
        JsonObject obj = new JsonObject();
        JsonArray arr = new JsonArray();
        for (Module m : ENABLED) arr.add(m.name());
        obj.add("enabled", arr);
        try (Writer w = Files.newBufferedWriter(file())) {
            w.write(obj.toString());
        } catch (IOException e) {
            System.err.println("[blackcat] could not save config: " + e);
        }
    }
}
